import { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Badge } from "@/components/ui/badge";
import { Settings2, Globe, Scale, Shield, Loader2 } from "lucide-react";
import { toast } from "sonner";

const JURISDICTIONS = [
  "United States",
  "European Union", 
  "United Kingdom",
  "Israel",
  "Brazil",
  "China",
  "India",
  "Australia",
  "Canada",
  "Germany",
  "Netherlands",
  "Global"
];

const DOMAINS = [
  "AI Law",
  "Privacy",
  "Antitrust",
  "Consumer Protection",
  "Platform Liability",
  "IP"
];

export default function UserPreferencesDialog({ user, onUpdate }) {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [preferences, setPreferences] = useState({
    preferred_jurisdictions: [],
    preferred_domains: [],
    dashboard_view: "all",
    risk_threshold: "all"
  });

  useEffect(() => {
    if (user) {
      setPreferences({
        preferred_jurisdictions: user.preferred_jurisdictions || [],
        preferred_domains: user.preferred_domains || [],
        dashboard_view: user.dashboard_view || "all",
        risk_threshold: user.risk_threshold || "all"
      });
    }
  }, [user]);

  const saveMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['current-user'] });
      toast.success("Preferences saved");
      setOpen(false);
      onUpdate?.();
    },
    onError: (error) => {
      toast.error("Failed to save preferences: " + error.message);
    }
  });

  const toggleJurisdiction = (jurisdiction) => {
    setPreferences(prev => ({
      ...prev,
      preferred_jurisdictions: prev.preferred_jurisdictions.includes(jurisdiction)
        ? prev.preferred_jurisdictions.filter(j => j !== jurisdiction)
        : [...prev.preferred_jurisdictions, jurisdiction]
    }));
  };

  const toggleDomain = (domain) => {
    setPreferences(prev => ({
      ...prev,
      preferred_domains: prev.preferred_domains.includes(domain)
        ? prev.preferred_domains.filter(d => d !== domain)
        : [...prev.preferred_domains, domain]
    }));
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <Settings2 className="h-4 w-4" />
          My Preferences
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings2 className="h-5 w-5 text-blue-600" />
            Personalization Settings
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          {/* Jurisdictions */}
          <div className="space-y-3">
            <Label className="flex items-center gap-2 text-sm font-medium">
              <Globe className="h-4 w-4 text-slate-500" />
              My Jurisdictions
            </Label>
            <p className="text-xs text-slate-500">Select the regions you want to monitor</p>
            <div className="flex flex-wrap gap-2">
              {JURISDICTIONS.map(jurisdiction => (
                <Badge
                  key={jurisdiction}
                  variant={preferences.preferred_jurisdictions.includes(jurisdiction) ? "default" : "outline"}
                  className="cursor-pointer hover:opacity-80 transition-opacity"
                  onClick={() => toggleJurisdiction(jurisdiction)}
                >
                  {jurisdiction}
                </Badge>
              ))}
            </div>
          </div>

          {/* Domains */}
          <div className="space-y-3">
            <Label className="flex items-center gap-2 text-sm font-medium">
              <Scale className="h-4 w-4 text-slate-500" />
              Focus Domains
            </Label>
            <p className="text-xs text-slate-500">Select your primary areas of interest</p>
            <div className="flex flex-wrap gap-2">
              {DOMAINS.map(domain => (
                <Badge
                  key={domain}
                  variant={preferences.preferred_domains.includes(domain) ? "default" : "outline"}
                  className="cursor-pointer hover:opacity-80 transition-opacity"
                  onClick={() => toggleDomain(domain)}
                >
                  {domain}
                </Badge>
              ))}
            </div>
          </div>

          {/* Dashboard View */}
          <div className="space-y-3">
            <Label className="flex items-center gap-2 text-sm font-medium">
              <Shield className="h-4 w-4 text-slate-500" />
              Dashboard View
            </Label>
            <RadioGroup
              value={preferences.dashboard_view}
              onValueChange={(value) => setPreferences(prev => ({ ...prev, dashboard_view: value }))}
              className="space-y-2"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="all" id="view-all" />
                <Label htmlFor="view-all" className="cursor-pointer">Show all updates</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="personalized" id="view-personalized" />
                <Label htmlFor="view-personalized" className="cursor-pointer">Show only my jurisdictions & domains</Label>
              </div>
            </RadioGroup>
          </div>

          {/* Risk Threshold */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Risk Level Filter</Label>
            <RadioGroup
              value={preferences.risk_threshold}
              onValueChange={(value) => setPreferences(prev => ({ ...prev, risk_threshold: value }))}
              className="space-y-2"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="all" id="risk-all" />
                <Label htmlFor="risk-all" className="cursor-pointer">All risk levels</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="medium_high" id="risk-medium" />
                <Label htmlFor="risk-medium" className="cursor-pointer">Medium & High only</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="high_only" id="risk-high" />
                <Label htmlFor="risk-high" className="cursor-pointer">High risk only</Label>
              </div>
            </RadioGroup>
          </div>
        </div>

        <div className="flex justify-end gap-3 mt-6 pt-4 border-t">
          <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
          <Button 
            onClick={() => saveMutation.mutate(preferences)}
            disabled={saveMutation.isPending}
          >
            {saveMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Save Preferences
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}