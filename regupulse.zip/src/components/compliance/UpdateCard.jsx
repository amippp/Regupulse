import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExternalLink, ChevronRight, Calendar, Building2, Trash2, EyeOff, Brain } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import DomainBadge from "./DomainBadge";
import JurisdictionBadge from "./JurisdictionBadge";
import UpdateTypeBadge from "./UpdateTypeBadge";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

export default function UpdateCard({ update, onClick, onDelete, onMarkRelevance }) {
  return (
    <Card 
      className="p-5 border hover:shadow-lg transition-all cursor-pointer group bg-white"
      onClick={onClick}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2 mb-3">
            <UpdateTypeBadge type={update.update_type} />
            <DomainBadge domain={update.domain} />
            <JurisdictionBadge jurisdiction={update.jurisdiction} />
          </div>
          
          <h3 className="font-semibold text-slate-900 group-hover:text-blue-600 transition-colors line-clamp-2 mb-2">
            {update.title}
          </h3>
          
          <p className="text-sm text-slate-600 line-clamp-2 mb-3">
            {update.summary}
          </p>
          
          <div className="flex items-center gap-4 text-xs text-slate-500">
            <span className="flex items-center gap-1">
              <Building2 className="h-3.5 w-3.5" />
              {update.source}
            </span>
            {(update.publish_date || update.scan_date) && (
                                <span className="flex items-center gap-1">
                                  <Calendar className="h-3.5 w-3.5" />
                                  {format(new Date(update.publish_date || update.scan_date), "MMM d, yyyy")}
                                </span>
                              )}
          </div>
        </div>
        
        <div className="flex items-center gap-1 shrink-0">
          {update.source_url && (
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8"
              onClick={(e) => {
                e.stopPropagation();
                window.open(update.source_url, '_blank');
              }}
            >
              <ExternalLink className="h-4 w-4" />
            </Button>
          )}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={(e) => e.stopPropagation()}
              >
                <EyeOff className="h-4 w-4 text-slate-400" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem 
                onClick={(e) => {
                  e.stopPropagation();
                  onMarkRelevance?.(update);
                }}
              >
                <Brain className="h-4 w-4 mr-2 text-violet-600" />
                Train AI relevance
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem 
                className="text-red-600 focus:text-red-600"
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete?.(update.id);
                }}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Remove from dashboard
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <ChevronRight className="h-5 w-5 text-slate-400 group-hover:text-blue-600 transition-colors" />
        </div>
      </div>
    </Card>
  );
}