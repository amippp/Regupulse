import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const flagData = [
  { jurisdiction: "United States", flag: "🇺🇸", abbr: "US" },
  { jurisdiction: "European Union", flag: "🇪🇺", abbr: "EU" },
  { jurisdiction: "United Kingdom", flag: "🇬🇧", abbr: "UK" },
  { jurisdiction: "Israel", flag: "🇮🇱", abbr: "IL" },
  { jurisdiction: "Brazil", flag: "🇧🇷", abbr: "BR" },
  { jurisdiction: "China", flag: "🇨🇳", abbr: "CN" },
  { jurisdiction: "India", flag: "🇮🇳", abbr: "IN" },
  { jurisdiction: "Australia", flag: "🇦🇺", abbr: "AU" },
  { jurisdiction: "Canada", flag: "🇨🇦", abbr: "CA" },
  { jurisdiction: "Global", flag: "🌍", abbr: "GLB" },
  { jurisdiction: "Germany", flag: "🇩🇪", abbr: "DE" }
];

export default function JurisdictionMap({ updates }) {
  const jurisdictionCounts = flagData.map(j => ({
    ...j,
    count: updates.filter(u => u.jurisdiction === j.jurisdiction).length,
    highRisk: updates.filter(u => u.jurisdiction === j.jurisdiction && u.risk_score === "High").length
  })).filter(j => j.count > 0).sort((a, b) => b.count - a.count);

  if (jurisdictionCounts.length === 0) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-semibold">By Jurisdiction</CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center h-48 text-slate-400">
          No data available
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-semibold">By Jurisdiction</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-3">
          {jurisdictionCounts.map(j => (
            <div 
              key={j.jurisdiction}
              className="flex items-center gap-3 p-3 rounded-lg bg-slate-50 hover:bg-slate-100 transition-colors"
            >
              <span className="text-2xl">{j.flag}</span>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-slate-900 truncate">{j.abbr}</p>
                <p className="text-xs text-slate-500">{j.count} update{j.count !== 1 ? 's' : ''}</p>
              </div>
              {j.highRisk > 0 && (
                <span className="text-xs font-medium text-red-600 bg-red-100 px-2 py-0.5 rounded-full">
                  {j.highRisk} high
                </span>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}