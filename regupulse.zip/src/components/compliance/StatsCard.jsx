import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export default function StatsCard({ title, value, icon: Icon, trend, color = "slate", subtitle, onClick }) {
  const colorStyles = {
    red: "bg-red-50 text-red-600 border-red-100",
    amber: "bg-amber-50 text-amber-600 border-amber-100",
    emerald: "bg-emerald-50 text-emerald-600 border-emerald-100",
    green: "bg-green-50 text-green-600 border-green-100",
    blue: "bg-blue-50 text-blue-600 border-blue-100",
    violet: "bg-violet-50 text-violet-600 border-violet-100",
    slate: "bg-slate-50 text-slate-600 border-slate-100"
  };

  const iconBg = {
    red: "bg-red-100",
    amber: "bg-amber-100",
    emerald: "bg-emerald-100",
    green: "bg-green-100",
    blue: "bg-blue-100",
    violet: "bg-violet-100",
    slate: "bg-slate-100"
  };

  return (
    <Card className={cn("p-5 border transition-all hover:shadow-md", colorStyles[color], onClick && "cursor-pointer")} onClick={onClick}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-medium uppercase tracking-wider opacity-70">{title}</p>
          <p className="text-3xl font-bold mt-1">{value}</p>
          {subtitle && (
            <p className="text-xs mt-1 opacity-70">{subtitle}</p>
          )}
          {trend && (
            <p className="text-xs mt-2 opacity-80">{trend}</p>
          )}
        </div>
        <div className={cn("p-3 rounded-xl", iconBg[color])}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </Card>
  );
}