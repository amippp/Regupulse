import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { UserPlus, X } from "lucide-react";
import { toast } from "sonner";

export default function TeamAssignment({ update, onUpdate }) {
  const queryClient = useQueryClient();
  
  const { data: users = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list()
  });

  const assignMutation = useMutation({
    mutationFn: ({ updateId, email }) => 
      base44.entities.RegulatoryUpdate.update(updateId, { assigned_to: email }),
    onSuccess: (_, { email }) => {
      queryClient.invalidateQueries({ queryKey: ['regulatory-updates'] });
      onUpdate?.({ ...update, assigned_to: email });
      toast.success(email ? "Update assigned" : "Assignment removed");
    }
  });

  const getInitials = (name) => {
    if (!name) return "?";
    return name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);
  };

  const assignedUser = users.find(u => u.email === update.assigned_to);

  return (
    <div className="space-y-2">
      <label className="text-sm font-medium text-slate-700">Assigned To</label>
      
      <div className="flex items-center gap-2">
        <Select 
          value={update.assigned_to || "unassigned"}
          onValueChange={(value) => assignMutation.mutate({ 
            updateId: update.id, 
            email: value === "unassigned" ? null : value 
          })}
        >
          <SelectTrigger className="w-full">
            <SelectValue>
              {assignedUser ? (
                <div className="flex items-center gap-2">
                  <Avatar className="h-5 w-5">
                    <AvatarFallback className="text-xs bg-blue-100 text-blue-700">
                      {getInitials(assignedUser.full_name)}
                    </AvatarFallback>
                  </Avatar>
                  <span>{assignedUser.full_name}</span>
                </div>
              ) : (
                <span className="text-slate-500">Unassigned</span>
              )}
            </SelectValue>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="unassigned">
              <span className="text-slate-500">Unassigned</span>
            </SelectItem>
            {users.map(user => (
              <SelectItem key={user.id} value={user.email}>
                <div className="flex items-center gap-2">
                  <Avatar className="h-5 w-5">
                    <AvatarFallback className="text-xs bg-blue-100 text-blue-700">
                      {getInitials(user.full_name)}
                    </AvatarFallback>
                  </Avatar>
                  <span>{user.full_name}</span>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}