import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Clock, ChevronRight, Calendar } from "lucide-react";
import { format, differenceInDays, parseISO } from "date-fns";
import { cn } from "@/lib/utils";

function parseDeadline(dateStr) {
  // Try to extract a date from various formats
  const patterns = [
    /(\d{1,2}\/\d{1,2}\/\d{4})/,
    /(\d{4}-\d{2}-\d{2})/,
    /(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s+\d{4}/i
  ];
  
  for (const pattern of patterns) {
    const match = dateStr.match(pattern);
    if (match) {
      try {
        return new Date(match[0]);
      } catch {
        continue;
      }
    }
  }
  return null;
}

function getUpcomingDeadline(keyDates) {
  if (!keyDates || keyDates.length === 0) return null;
  
  const now = new Date();
  let nearest = null;
  let nearestDate = null;
  
  for (const dateStr of keyDates) {
    const parsed = parseDeadline(dateStr);
    if (parsed && parsed > now) {
      if (!nearestDate || parsed < nearestDate) {
        nearestDate = parsed;
        nearest = { date: parsed, description: dateStr };
      }
    }
  }
  
  return nearest;
}

export default function PriorityInbox({ updates, onSelectUpdate }) {
  // Filter for action-required items with upcoming deadlines
  const priorityItems = updates
    .filter(u => u.risk_score === "High" || u.status === "Action Required")
    .map(u => {
      const deadline = getUpcomingDeadline(u.key_dates);
      return { ...u, upcomingDeadline: deadline };
    })
    .sort((a, b) => {
      // Sort by deadline first, then by risk
      if (a.upcomingDeadline && b.upcomingDeadline) {
        return a.upcomingDeadline.date - b.upcomingDeadline.date;
      }
      if (a.upcomingDeadline) return -1;
      if (b.upcomingDeadline) return 1;
      if (a.risk_score === "High" && b.risk_score !== "High") return -1;
      if (b.risk_score === "High" && a.risk_score !== "High") return 1;
      return 0;
    })
    .slice(0, 10);

  if (priorityItems.length === 0) {
    return (
      <Card className="p-6 text-center">
        <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-3">
          <AlertTriangle className="h-6 w-6 text-emerald-600" />
        </div>
        <h3 className="font-medium text-slate-900">All Clear</h3>
        <p className="text-sm text-slate-500 mt-1">No high-priority items requiring immediate attention</p>
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden">
      <div className="bg-gradient-to-r from-red-600 to-orange-600 px-4 py-3">
        <div className="flex items-center gap-2 text-white">
          <AlertTriangle className="h-5 w-5" />
          <h3 className="font-semibold">Priority Inbox</h3>
          <Badge variant="secondary" className="ml-auto bg-white/20 text-white hover:bg-white/30">
            {priorityItems.length} items
          </Badge>
        </div>
      </div>
      
      <div className="divide-y divide-slate-100">
        {priorityItems.map(item => {
          const daysUntil = item.upcomingDeadline 
            ? differenceInDays(item.upcomingDeadline.date, new Date())
            : null;
          
          return (
            <div 
              key={item.id}
              className="p-4 hover:bg-slate-50 cursor-pointer transition-colors"
              onClick={() => onSelectUpdate(item)}
            >
              <div className="flex items-start gap-3">
                <div className={cn(
                  "mt-1 p-1.5 rounded-full",
                  daysUntil !== null && daysUntil <= 7 ? "bg-red-100" : "bg-amber-100"
                )}>
                  {daysUntil !== null && daysUntil <= 7 ? (
                    <Clock className="h-4 w-4 text-red-600" />
                  ) : (
                    <AlertTriangle className="h-4 w-4 text-amber-600" />
                  )}
                </div>
                
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-slate-900 line-clamp-1">{item.title}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline" className="text-xs">
                      {item.domain}
                    </Badge>
                    <span className="text-xs text-slate-500">{item.jurisdiction}</span>
                  </div>
                  
                  {item.upcomingDeadline && (
                    <div className={cn(
                      "flex items-center gap-1.5 mt-2 text-xs font-medium",
                      daysUntil <= 7 ? "text-red-600" : daysUntil <= 30 ? "text-amber-600" : "text-slate-600"
                    )}>
                      <Calendar className="h-3.5 w-3.5" />
                      {daysUntil === 0 ? "Due today" : 
                       daysUntil === 1 ? "Due tomorrow" :
                       daysUntil < 0 ? "Overdue" :
                       `${daysUntil} days remaining`}
                    </div>
                  )}
                </div>
                
                <ChevronRight className="h-5 w-5 text-slate-400 shrink-0" />
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}