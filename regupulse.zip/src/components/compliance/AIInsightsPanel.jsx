import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Sparkles, List, HelpCircle, RefreshCw, ChevronDown, ChevronUp, AlertTriangle, Scale, Users, TrendingUp } from "lucide-react";
import { cn } from "@/lib/utils";

export default function AIInsightsPanel({ update }) {
  const [insights, setInsights] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [expanded, setExpanded] = useState(true);

  // Fetch company profile for personalized analysis
  const { data: companyProfiles = [] } = useQuery({
    queryKey: ['company-profile'],
    queryFn: () => base44.entities.CompanyProfile.list(),
    staleTime: 300000 // 5 minutes
  });

  const companyProfile = companyProfiles[0] || null;

  const generateInsights = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Build company context for personalized analysis
      let customPrompt = companyProfile?.custom_prompt || '';
      let companyContext = "";
      
      if (companyProfile) {
        companyContext = `
COMPANY CONTEXT:
- Operating Regions: ${companyProfile.operating_regions?.join(', ') || 'Not specified'}
- Key Risk Areas: ${companyProfile.key_risk_areas?.join(', ') || 'Not specified'}
- Regulatory Frameworks: ${companyProfile.regulatory_frameworks?.join(', ') || 'Not specified'}
- Data Types Processed: ${companyProfile.data_types_processed?.join(', ') || 'Not specified'}
- Uses AI/ML: ${companyProfile.uses_ai_ml ? 'Yes' : 'No'}
${companyProfile.additional_context ? `- Additional Context: ${companyProfile.additional_context}` : ''}
`;
      }

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `${customPrompt ? customPrompt + '\n\n' : ''}Analyze this regulatory update for a compliance team:
${companyContext}
REGULATORY UPDATE:
Title: ${update.title}
Domain: ${update.domain}
Jurisdiction: ${update.jurisdiction}
Risk Level: ${update.risk_score}
Summary: ${update.summary}
${update.full_analysis ? `Full Analysis: ${update.full_analysis}` : ''}
${update.compliance_actions?.length ? `Compliance Actions: ${update.compliance_actions.join(', ')}` : ''}

Provide:
1. Key Points: Extract 3-5 bullet points summarizing the most important takeaways${companyProfile ? ', tailored to the company context above' : ''}
2. Related Questions: Generate 3-4 thought-provoking questions to help understand and respond to this update

Keep responses concise and actionable.`,
        response_json_schema: {
          type: "object",
          properties: {
            key_points: {
              type: "array",
              items: { type: "string" },
              description: "3-5 key takeaways from the update"
            },
            related_questions: {
              type: "array",
              items: { type: "string" },
              description: "3-4 questions for better comprehension"
            }
          },
          required: ["key_points", "related_questions"]
        }
      });
      
      setInsights(result);
    } catch (err) {
      setError("Failed to generate insights. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (update?.id) {
      setInsights(null);
    }
  }, [update?.id]);

  if (!insights && !loading) {
    return (
      <div className="bg-gradient-to-br from-violet-50 to-indigo-50 border border-violet-200 rounded-lg p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-violet-100 rounded-lg">
              <Sparkles className="h-4 w-4 text-violet-600" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-violet-900">AI Insights</h4>
              <p className="text-xs text-violet-600">Get key points and related questions</p>
            </div>
          </div>
          <Button 
            onClick={generateInsights} 
            size="sm" 
            className="bg-violet-600 hover:bg-violet-700"
          >
            <Sparkles className="h-3.5 w-3.5 mr-1.5" />
            Generate
          </Button>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="bg-gradient-to-br from-violet-50 to-indigo-50 border border-violet-200 rounded-lg p-4 space-y-4">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-violet-100 rounded-lg animate-pulse">
            <Sparkles className="h-4 w-4 text-violet-600" />
          </div>
          <span className="text-sm font-medium text-violet-700">Generating insights...</span>
        </div>
        <div className="space-y-3">
          <Skeleton className="h-4 w-full bg-violet-100" />
          <Skeleton className="h-4 w-3/4 bg-violet-100" />
          <Skeleton className="h-4 w-5/6 bg-violet-100" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <div className="flex items-center justify-between">
          <p className="text-sm text-red-700">{error}</p>
          <Button variant="ghost" size="sm" onClick={generateInsights}>
            <RefreshCw className="h-4 w-4 mr-1" />
            Retry
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-br from-violet-50 to-indigo-50 border border-violet-200 rounded-lg overflow-hidden">
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center justify-between p-4 hover:bg-violet-100/50 transition-colors"
      >
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-violet-100 rounded-lg">
            <Sparkles className="h-4 w-4 text-violet-600" />
          </div>
          <h4 className="text-sm font-semibold text-violet-900">AI Insights</h4>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-7 w-7 text-violet-600 hover:text-violet-700 hover:bg-violet-100"
            onClick={(e) => {
              e.stopPropagation();
              generateInsights();
            }}
          >
            <RefreshCw className="h-3.5 w-3.5" />
          </Button>
          {expanded ? (
            <ChevronUp className="h-4 w-4 text-violet-600" />
          ) : (
            <ChevronDown className="h-4 w-4 text-violet-600" />
          )}
        </div>
      </button>

      <div className={cn(
        "overflow-hidden transition-all duration-300",
        expanded ? "max-h-[500px] opacity-100" : "max-h-0 opacity-0"
      )}>
        <div className="px-4 pb-4 space-y-4">
          {/* Key Points */}
          {insights?.key_points?.length > 0 && (
            <div>
              <div className="flex items-center gap-1.5 mb-2">
                <List className="h-3.5 w-3.5 text-violet-600" />
                <span className="text-xs font-medium text-violet-700 uppercase tracking-wide">Key Points</span>
              </div>
              <ul className="space-y-2">
                {insights.key_points.map((point, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-violet-900">
                    <span className="flex-shrink-0 w-5 h-5 rounded-full bg-violet-200 text-violet-700 flex items-center justify-center text-xs font-medium">
                      {i + 1}
                    </span>
                    <span>{point}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Related Questions */}
          {insights?.related_questions?.length > 0 && (
            <div className="pt-3 border-t border-violet-200">
              <div className="flex items-center gap-1.5 mb-2">
                <HelpCircle className="h-3.5 w-3.5 text-indigo-600" />
                <span className="text-xs font-medium text-indigo-700 uppercase tracking-wide">Questions to Consider</span>
              </div>
              <ul className="space-y-2">
                {insights.related_questions.map((question, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-indigo-900 bg-indigo-50/50 rounded-lg p-2.5">
                    <HelpCircle className="h-4 w-4 text-indigo-500 flex-shrink-0 mt-0.5" />
                    <span>{question}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Legal Event Analysis - only for rulings/enforcement */}
          {update.is_court_decision_or_enforcement && (
            <div className="pt-3 border-t border-violet-200">
              <div className="flex items-center gap-1.5 mb-3">
                <AlertTriangle className="h-3.5 w-3.5 text-amber-600" />
                <span className="text-xs font-medium text-amber-700 uppercase tracking-wide">Legal Event Analysis</span>
              </div>
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 space-y-3">
                {update.involved_parties?.length > 0 && (
                  <div className="flex items-start gap-2">
                    <Users className="h-4 w-4 text-amber-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <span className="text-xs font-medium text-amber-800">Involved Parties</span>
                      <p className="text-sm text-amber-900 mt-0.5">{update.involved_parties.join(', ')}</p>
                    </div>
                  </div>
                )}
                
                {update.enforcement_type && (
                  <div className="flex items-start gap-2">
                    <Scale className="h-4 w-4 text-amber-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <span className="text-xs font-medium text-amber-800">Enforcement Type</span>
                      <p className="text-sm text-amber-900 mt-0.5">{update.enforcement_type}</p>
                    </div>
                  </div>
                )}
                
                {update.legal_field && (
                  <div className="flex items-start gap-2">
                    <Scale className="h-4 w-4 text-amber-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <span className="text-xs font-medium text-amber-800">Legal Field</span>
                      <p className="text-sm text-amber-900 mt-0.5">{update.legal_field}</p>
                    </div>
                  </div>
                )}
                
                {update.possible_implications && (
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 text-amber-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <span className="text-xs font-medium text-amber-800">Implications for SaaS</span>
                      <p className="text-sm text-amber-900 mt-0.5">{update.possible_implications}</p>
                    </div>
                  </div>
                )}
                
                {update.trend_analysis && (
                  <div className="flex items-start gap-2">
                    <TrendingUp className="h-4 w-4 text-amber-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <span className="text-xs font-medium text-amber-800">Trend Analysis</span>
                      <p className="text-sm text-amber-900 mt-0.5">{update.trend_analysis}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}