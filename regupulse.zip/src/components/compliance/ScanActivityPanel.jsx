import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, Clock, CheckCircle2, AlertTriangle, Zap, TrendingUp } from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";

export default function ScanActivityPanel({ updates, lastScanInfo }) {
  // Calculate stats from updates
  const today = new Date();
  const last24h = new Date(today.getTime() - 24 * 60 * 60 * 1000);
  const last7d = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
  
  const newUpdatesLast24h = updates.filter(u => 
    u.created_date && new Date(u.created_date) >= last24h
  ).length;
  
  const newUpdatesLast7d = updates.filter(u => 
    u.created_date && new Date(u.created_date) >= last7d
  ).length;
  
  const highRiskCount = updates.filter(u => u.risk_score === "High").length;
  
  // Get the most recent scan date
  const mostRecentUpdate = updates.length > 0 
    ? updates.reduce((latest, u) => {
        const uDate = new Date(u.scan_date || u.created_date);
        return uDate > new Date(latest.scan_date || latest.created_date) ? u : latest;
      })
    : null;
  
  const lastScanDate = mostRecentUpdate?.scan_date || mostRecentUpdate?.created_date;

  return (
    <Card className="bg-white border border-slate-200 shadow-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium flex items-center gap-2 text-slate-600">
          <Activity className="h-4 w-4" />
          Scan Activity
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Last Scan Info */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-emerald-100">
              <CheckCircle2 className="h-4 w-4 text-emerald-600" />
            </div>
            <div>
              <p className="text-xs text-slate-500">Last Scan</p>
              <p className="text-sm font-medium text-slate-900">
                {lastScanDate 
                  ? formatDistanceToNow(new Date(lastScanDate), { addSuffix: true })
                  : "No scans yet"}
              </p>
            </div>
          </div>
          {lastScanInfo?.execution_time_ms && (
            <Badge variant="outline" className="bg-slate-50 text-slate-600 border-slate-200">
              <Zap className="h-3 w-3 mr-1" />
              {(lastScanInfo.execution_time_ms / 1000).toFixed(1)}s
            </Badge>
          )}
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-blue-50 rounded-lg p-3 text-center">
            <p className="text-2xl font-bold text-blue-600">{newUpdatesLast24h}</p>
            <p className="text-xs text-slate-500">Last 24h</p>
          </div>
          <div className="bg-violet-50 rounded-lg p-3 text-center">
            <p className="text-2xl font-bold text-violet-600">{newUpdatesLast7d}</p>
            <p className="text-xs text-slate-500">Last 7 days</p>
          </div>
          <div className="bg-red-50 rounded-lg p-3 text-center">
            <p className="text-2xl font-bold text-red-600">{highRiskCount}</p>
            <p className="text-xs text-slate-500">High Risk</p>
          </div>
        </div>

        {/* Quick Insights */}
        {lastScanInfo?.sources && (
          <div className="pt-2 border-t border-slate-100">
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <TrendingUp className="h-3 w-3" />
              <span>
                {lastScanInfo.sources.rss_feeds} RSS feeds, {lastScanInfo.sources.scraped_sites} websites
                {lastScanInfo.sources.duplicates_skipped > 0 && (
                  <span className="text-amber-600 ml-1">
                    ({lastScanInfo.sources.duplicates_skipped} duplicates skipped)
                  </span>
                )}
              </span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}