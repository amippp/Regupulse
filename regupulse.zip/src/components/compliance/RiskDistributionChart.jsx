import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";

const COLORS = {
  High: "#ef4444",
  Medium: "#f59e0b", 
  Low: "#10b981"
};

export default function RiskDistributionChart({ updates }) {
  const data = [
    { name: "High Risk", value: updates.filter(u => u.risk_score === "High").length, color: COLORS.High },
    { name: "Medium Risk", value: updates.filter(u => u.risk_score === "Medium").length, color: COLORS.Medium },
    { name: "Low Risk", value: updates.filter(u => u.risk_score === "Low").length, color: COLORS.Low }
  ].filter(d => d.value > 0);

  if (data.length === 0) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-semibold">Risk Distribution</CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center h-48 text-slate-400">
          No data available
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-semibold">Risk Distribution</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={200}>
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={50}
              outerRadius={80}
              paddingAngle={3}
              dataKey="value"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip 
              formatter={(value) => [value, "Updates"]}
              contentStyle={{ borderRadius: 8, border: "1px solid #e2e8f0" }}
            />
            <Legend 
              verticalAlign="bottom" 
              height={36}
              formatter={(value) => <span className="text-xs text-slate-600">{value}</span>}
            />
          </PieChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}