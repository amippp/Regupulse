import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link2, ChevronRight } from "lucide-react";
import RiskBadge from "./RiskBadge";

export default function RelatedUpdates({ currentUpdate, allUpdates, onSelectUpdate }) {
  if (!currentUpdate) return null;

  // Find related updates based on domain, jurisdiction, or keywords
  const findRelated = () => {
    const keywords = currentUpdate.title.toLowerCase().split(/\s+/)
      .filter(w => w.length > 4)
      .slice(0, 5);
    
    return allUpdates
      .filter(u => u.id !== currentUpdate.id)
      .map(u => {
        let score = 0;
        
        // Same domain = +3
        if (u.domain === currentUpdate.domain) score += 3;
        
        // Same jurisdiction = +2
        if (u.jurisdiction === currentUpdate.jurisdiction) score += 2;
        
        // Same update type = +1
        if (u.update_type === currentUpdate.update_type) score += 1;
        
        // Keyword matches in title
        const titleLower = u.title.toLowerCase();
        keywords.forEach(kw => {
          if (titleLower.includes(kw)) score += 1;
        });
        
        // Same source = +1
        if (u.source === currentUpdate.source) score += 1;
        
        return { ...u, relevanceScore: score };
      })
      .filter(u => u.relevanceScore >= 3)
      .sort((a, b) => b.relevanceScore - a.relevanceScore)
      .slice(0, 5);
  };

  const related = findRelated();

  if (related.length === 0) {
    return null;
  }

  return (
    <div className="mt-6">
      <div className="flex items-center gap-2 mb-3">
        <Link2 className="h-4 w-4 text-slate-500" />
        <h4 className="font-medium text-slate-900">Related Updates</h4>
      </div>
      
      <div className="space-y-2">
        {related.map(update => (
          <div
            key={update.id}
            className="flex items-center gap-3 p-3 rounded-lg bg-slate-50 hover:bg-slate-100 cursor-pointer transition-colors"
            onClick={() => onSelectUpdate(update)}
          >
            <RiskBadge risk={update.risk_score} size="sm" showIcon={false} />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-slate-900 line-clamp-1">{update.title}</p>
              <p className="text-xs text-slate-500">{update.source}</p>
            </div>
            <ChevronRight className="h-4 w-4 text-slate-400 shrink-0" />
          </div>
        ))}
      </div>
    </div>
  );
}