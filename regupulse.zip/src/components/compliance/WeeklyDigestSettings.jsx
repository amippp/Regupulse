import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Mail, X, Plus, Check } from "lucide-react";
import { toast } from "sonner";

export default function WeeklyDigestSettings() {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [newEmail, setNewEmail] = useState("");
  
  const { data: schedules = [] } = useQuery({
    queryKey: ['scan-schedule'],
    queryFn: () => base44.entities.ScanSchedule.list()
  });
  
  const schedule = schedules[0] || {
    frequency: "weekly",
    day_of_week: "monday",
    hour: 8,
    digest_enabled: false,
    digest_emails: []
  };
  
  const [settings, setSettings] = useState(schedule);
  
  useEffect(() => {
    if (schedules[0]) {
      setSettings(schedules[0]);
    }
  }, [schedules]);

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      if (schedule.id) {
        return base44.entities.ScanSchedule.update(schedule.id, data);
      } else {
        return base44.entities.ScanSchedule.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scan-schedule'] });
      toast.success("Digest settings saved");
      setOpen(false);
    }
  });

  const addEmail = () => {
    if (newEmail && newEmail.includes("@")) {
      setSettings(prev => ({
        ...prev,
        digest_emails: [...(prev.digest_emails || []), newEmail]
      }));
      setNewEmail("");
    }
  };

  const removeEmail = (email) => {
    setSettings(prev => ({
      ...prev,
      digest_emails: (prev.digest_emails || []).filter(e => e !== email)
    }));
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <Mail className="h-4 w-4" />
          Weekly Digest
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Weekly Digest Settings</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>Enable Weekly Digest</Label>
              <p className="text-sm text-slate-500">Receive a summary email every week</p>
            </div>
            <Switch 
              checked={settings.digest_enabled}
              onCheckedChange={(checked) => setSettings(prev => ({ ...prev, digest_enabled: checked }))}
            />
          </div>
          
          {settings.digest_enabled && (
            <>
              <div className="space-y-2">
                <Label>Send On</Label>
                <Select 
                  value={settings.day_of_week || "monday"}
                  onValueChange={(v) => setSettings(prev => ({ ...prev, day_of_week: v }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="monday">Monday</SelectItem>
                    <SelectItem value="tuesday">Tuesday</SelectItem>
                    <SelectItem value="wednesday">Wednesday</SelectItem>
                    <SelectItem value="thursday">Thursday</SelectItem>
                    <SelectItem value="friday">Friday</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Recipients</Label>
                <div className="flex gap-2">
                  <Input 
                    type="email"
                    placeholder="email@example.com"
                    value={newEmail}
                    onChange={(e) => setNewEmail(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && addEmail()}
                  />
                  <Button type="button" size="icon" onClick={addEmail}>
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
                
                <div className="flex flex-wrap gap-2 mt-2">
                  {(settings.digest_emails || []).map(email => (
                    <Badge key={email} variant="secondary" className="gap-1 pr-1">
                      {email}
                      <button 
                        onClick={() => removeEmail(email)}
                        className="ml-1 hover:bg-slate-300 rounded-full p-0.5"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
        
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={() => saveMutation.mutate(settings)} disabled={saveMutation.isPending}>
            <Check className="h-4 w-4 mr-2" />
            Save Settings
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}