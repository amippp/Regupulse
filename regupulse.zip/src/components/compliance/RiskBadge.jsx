import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { AlertTriangle, AlertCircle, Info } from "lucide-react";

export default function RiskBadge({ risk, showIcon = true, size = "default" }) {
  const config = {
    High: {
      className: "bg-red-100 text-red-700 border-red-200 hover:bg-red-100",
      icon: AlertTriangle
    },
    Medium: {
      className: "bg-amber-100 text-amber-700 border-amber-200 hover:bg-amber-100",
      icon: AlertCircle
    },
    Low: {
      className: "bg-emerald-100 text-emerald-700 border-emerald-200 hover:bg-emerald-100",
      icon: Info
    }
  };

  const { className, icon: Icon } = config[risk] || config.Low;

  return (
    <Badge 
      variant="outline" 
      className={cn(
        "font-medium gap-1",
        className,
        size === "sm" && "text-xs px-2 py-0.5"
      )}
    >
      {showIcon && <Icon className={cn("h-3 w-3", size === "sm" && "h-2.5 w-2.5")} />}
      {risk}
    </Badge>
  );
}