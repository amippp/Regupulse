import { Badge } from "@/components/ui/badge";
import { FileText, Gavel, Scale, Briefcase, Users } from "lucide-react";
import { cn } from "@/lib/utils";

const typeConfig = {
  "Regulatory": { icon: FileText, className: "bg-blue-100 text-blue-700 border-blue-200" },
  "Enforcement": { icon: Gavel, className: "bg-red-100 text-red-700 border-red-200" },
  "Ruling": { icon: Scale, className: "bg-purple-100 text-purple-700 border-purple-200" },
  "Court Filing": { icon: Briefcase, className: "bg-amber-100 text-amber-700 border-amber-200" },
  "Class Action": { icon: Users, className: "bg-orange-100 text-orange-700 border-orange-200" }
};

export default function UpdateTypeBadge({ type }) {
  const config = typeConfig[type] || { icon: FileText, className: "bg-slate-100 text-slate-700 border-slate-200" };
  const Icon = config.icon;

  return (
    <Badge variant="outline" className={cn("gap-1 text-xs font-medium", config.className)}>
      <Icon className="h-3 w-3" />
      {type || "Unknown"}
    </Badge>
  );
}