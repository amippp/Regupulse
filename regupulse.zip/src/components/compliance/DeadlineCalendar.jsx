import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Calendar, ChevronLeft, ChevronRight, AlertTriangle } from "lucide-react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, addMonths, subMonths, isToday, isBefore } from "date-fns";
import { cn } from "@/lib/utils";
import RiskBadge from "./RiskBadge";

function parseDeadlines(updates) {
  const deadlines = [];
  
  // Only include Regulatory and Ruling updates (effective dates)
  const relevantTypes = ["Regulatory", "Ruling"];
  
  updates.forEach(update => {
    if (!update.key_dates || update.key_dates.length === 0) return;
    if (!relevantTypes.includes(update.update_type)) return;
    
    update.key_dates.forEach(dateStr => {
      // Try to parse various date formats
      const patterns = [
        /(\d{1,2}\/\d{1,2}\/\d{4})/,
        /(\d{4}-\d{2}-\d{2})/,
        /(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s+\d{4}/i
      ];
      
      for (const pattern of patterns) {
        const match = dateStr.match(pattern);
        if (match) {
          try {
            const date = new Date(match[0]);
            if (!isNaN(date.getTime())) {
              deadlines.push({
                date,
                description: dateStr,
                update
              });
              break;
            }
          } catch {
            continue;
          }
        }
      }
    });
  });
  
  return deadlines.sort((a, b) => a.date - b.date);
}

export default function DeadlineCalendar({ updates, onSelectUpdate }) {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  
  const deadlines = parseDeadlines(updates);
  
  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });
  
  const getDeadlinesForDay = (day) => {
    return deadlines.filter(d => isSameDay(d.date, day));
  };

  const upcomingDeadlines = deadlines
    .filter(d => d.date >= new Date())
    .slice(0, 5);

  return (
    <TooltipProvider>
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-slate-900 flex items-center gap-2">
            <Calendar className="h-5 w-5 text-blue-600" />
            Compliance Calendar
          </h3>
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="text-sm font-medium w-32 text-center">
                {format(currentMonth, "MMMM yyyy")}
              </span>
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        <div className="flex flex-col lg:flex-row gap-6">
            {/* Mini Calendar */}
            <div className="lg:w-72 shrink-0">
              <div className="grid grid-cols-7 gap-1">
                {["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"].map(day => (
                  <div key={day} className="text-center text-xs font-medium text-slate-500 py-1">
                    {day}
                  </div>
                ))}
                
                {/* Empty cells for days before month start */}
                {Array.from({ length: monthStart.getDay() }).map((_, i) => (
                  <div key={`empty-${i}`} className="h-9" />
                ))}
                
                {days.map(day => {
                  const dayDeadlines = getDeadlinesForDay(day);
                  const hasDeadline = dayDeadlines.length > 0;
                  const isPast = isBefore(day, new Date()) && !isToday(day);
                  
                  const dayContent = (
                    <div
                      className={cn(
                        "h-9 w-9 flex items-center justify-center text-sm rounded-md relative",
                        isToday(day) && "bg-blue-100 font-semibold text-blue-700",
                        hasDeadline && !isPast && "bg-red-100 text-red-700 font-medium cursor-pointer hover:bg-red-200",
                        hasDeadline && isPast && "bg-slate-100 text-slate-500",
                        !hasDeadline && !isToday(day) && "text-slate-600 hover:bg-slate-50"
                      )}
                      onClick={hasDeadline ? () => onSelectUpdate(dayDeadlines[0].update) : undefined}
                    >
                      {format(day, "d")}
                      {hasDeadline && (
                        <span className="absolute bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-red-500" />
                      )}
                    </div>
                  );
                  
                  if (hasDeadline) {
                    return (
                      <Tooltip key={day.toISOString()}>
                        <TooltipTrigger asChild>
                          {dayContent}
                        </TooltipTrigger>
                        <TooltipContent side="top" className="max-w-xs p-0">
                          <div className="p-3 space-y-2">
                            <p className="text-xs font-medium text-slate-500">
                              {format(day, "MMMM d, yyyy")} • {dayDeadlines.length} event{dayDeadlines.length > 1 ? 's' : ''}
                            </p>
                            {dayDeadlines.map((dl, idx) => (
                              <div key={idx} className="border-t pt-2 first:border-0 first:pt-0">
                                <div className="flex items-start gap-2">
                                  <RiskBadge risk={dl.update.risk_score} size="sm" showIcon={false} />
                                  <div>
                                    <p className="font-medium text-sm line-clamp-2">{dl.update.title}</p>
                                    <p className="text-xs text-slate-500 mt-0.5">{dl.update.source}</p>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </TooltipContent>
                      </Tooltip>
                    );
                  }
                  
                  return <div key={day.toISOString()}>{dayContent}</div>;
                })}
              </div>
            </div>
            
            {/* Upcoming Deadlines List */}
            <div className="flex-1 lg:border-l lg:pl-6">
              <h4 className="text-xs font-medium text-slate-500 uppercase mb-3">Upcoming Events</h4>
              {upcomingDeadlines.length > 0 ? (
                <div className="space-y-3">
                  {upcomingDeadlines.map((deadline, idx) => (
                    <div 
                      key={idx}
                      className="flex items-start gap-3 p-3 rounded-lg bg-slate-50 hover:bg-slate-100 cursor-pointer transition-colors"
                      onClick={() => onSelectUpdate(deadline.update)}
                    >
                      <div className={cn(
                        "w-2 h-2 rounded-full mt-2 shrink-0",
                        deadline.update.risk_score === "High" ? "bg-red-500" : 
                        deadline.update.risk_score === "Medium" ? "bg-amber-500" : "bg-emerald-500"
                      )} />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-slate-900 line-clamp-2">{deadline.update.title}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-xs text-slate-500">{format(deadline.date, "MMM d, yyyy")}</span>
                          <span className="text-xs text-slate-400">•</span>
                          <span className="text-xs text-slate-500">{deadline.update.source}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-sm text-slate-500">
                  No upcoming events
                </div>
              )}
            </div>
          </div>
      </Card>
    </TooltipProvider>
  );
}