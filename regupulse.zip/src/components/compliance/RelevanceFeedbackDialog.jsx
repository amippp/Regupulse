import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ThumbsDown, ThumbsUp, Sparkles, Loader2, Brain, Plus, X } from "lucide-react";
import { toast } from "sonner";

const IRRELEVANCE_REASONS = [
  { value: "off_topic", label: "Off Topic", description: "Not related to SaaS/tech compliance" },
  { value: "too_general", label: "Too General", description: "Generic news without actionable insights" },
  { value: "wrong_jurisdiction", label: "Wrong Jurisdiction", description: "Not applicable to our operating regions" },
  { value: "outdated", label: "Outdated", description: "Old news or already addressed" },
  { value: "duplicate_topic", label: "Duplicate Topic", description: "Similar to other articles we've seen" },
  { value: "not_actionable", label: "Not Actionable", description: "No clear compliance implications" },
  { value: "other", label: "Other", description: "Different reason" }
];

const RELEVANCE_REASONS = [
  { value: "core_topic", label: "Core Topic", description: "Directly relevant to our compliance needs" },
  { value: "priority_regulation", label: "Priority Regulation", description: "Covers a key regulatory framework we track" },
  { value: "actionable", label: "Actionable", description: "Contains clear action items for our team" },
  { value: "precedent_setting", label: "Precedent Setting", description: "Could set important legal precedent" },
  { value: "other", label: "Other", description: "Different reason" }
];

export default function RelevanceFeedbackDialog({ update, open, onClose }) {
  const queryClient = useQueryClient();
  const [isRelevant, setIsRelevant] = useState(null);
  const [reason, setReason] = useState("");
  const [details, setDetails] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [suggestedPatterns, setSuggestedPatterns] = useState([]);
  const [includeKeywords, setIncludeKeywords] = useState([]);
  const [newKeyword, setNewKeyword] = useState("");

  const feedbackMutation = useMutation({
    mutationFn: async (feedbackData) => {
      // Save the feedback
      const feedback = await base44.entities.RelevanceFeedback.create(feedbackData);
      
      // Invoke AI to learn patterns (for both relevant and irrelevant)
      setIsAnalyzing(true);
      const result = await base44.functions.invoke('learnFromFeedback', {
        feedbackId: feedback.id,
        updateId: update.id,
        title: update.title,
        summary: update.summary,
        source: update.source,
        domain: update.domain,
        isRelevant: feedbackData.is_relevant,
        reason: feedbackData.is_relevant ? feedbackData.relevance_reason : feedbackData.irrelevance_reason,
        details: feedbackData.irrelevance_details,
        includeKeywords: feedbackData.include_keywords || []
      });
      setIsAnalyzing(false);
      return { feedback, learning: result.data };
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ['regulatory-updates'] });
      queryClient.invalidateQueries({ queryKey: ['relevance-rules'] });
      
      if (result.learning?.patterns_learned > 0) {
        toast.success(`Feedback saved! AI learned ${result.learning.patterns_learned} new filtering patterns.`);
      } else {
        toast.success(isRelevant ? "Marked as relevant" : "Marked as irrelevant - AI will learn from this");
      }
      handleClose();
    },
    onError: (error) => {
      toast.error("Failed to save feedback: " + error.message);
    }
  });

  const handleClose = () => {
    setIsRelevant(null);
    setReason("");
    setDetails("");
    setSuggestedPatterns([]);
    setIncludeKeywords([]);
    setNewKeyword("");
    onClose();
  };

  const addKeyword = () => {
    if (newKeyword.trim() && !includeKeywords.includes(newKeyword.trim().toLowerCase())) {
      setIncludeKeywords([...includeKeywords, newKeyword.trim().toLowerCase()]);
      setNewKeyword("");
    }
  };

  const removeKeyword = (keyword) => {
    setIncludeKeywords(includeKeywords.filter(k => k !== keyword));
  };

  const handleSubmit = () => {
    if (isRelevant === null) {
      toast.error("Please indicate if this article is relevant");
      return;
    }
    if (!isRelevant && !reason) {
      toast.error("Please select a reason for irrelevance");
      return;
    }
    if (isRelevant && !reason) {
      toast.error("Please select a reason for relevance");
      return;
    }

    feedbackMutation.mutate({
      update_id: update.id,
      update_title: update.title,
      source_name: update.source,
      source_url: update.source_url,
      domain: update.domain,
      is_relevant: isRelevant,
      relevance_reason: isRelevant ? reason : null,
      irrelevance_reason: isRelevant ? null : reason,
      irrelevance_details: details || null,
      include_keywords: isRelevant ? includeKeywords : []
    });
  };

  if (!update) return null;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-violet-600" />
            Train Relevance AI
          </DialogTitle>
          <DialogDescription>
            Help the system learn what's relevant to your compliance needs. Your feedback improves future scans.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 mt-2">
          {/* Article Preview */}
          <div className="bg-slate-50 rounded-lg p-3 border">
            <p className="font-medium text-slate-900 text-sm line-clamp-2">{update.title}</p>
            <div className="flex items-center gap-2 mt-2">
              <Badge variant="outline" className="text-xs">{update.source}</Badge>
              <Badge variant="secondary" className="text-xs">{update.domain}</Badge>
            </div>
          </div>

          {/* Relevance Selection */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Is this article relevant to your compliance needs?</Label>
            <div className="grid grid-cols-2 gap-3">
              <Button
                type="button"
                variant={isRelevant === true ? "default" : "outline"}
                className={`h-auto py-3 flex-col gap-1 ${isRelevant === true ? "bg-emerald-600 hover:bg-emerald-700" : ""}`}
                onClick={() => setIsRelevant(true)}
              >
                <ThumbsUp className="h-5 w-5" />
                <span>Relevant</span>
              </Button>
              <Button
                type="button"
                variant={isRelevant === false ? "default" : "outline"}
                className={`h-auto py-3 flex-col gap-1 ${isRelevant === false ? "bg-red-600 hover:bg-red-700" : ""}`}
                onClick={() => setIsRelevant(false)}
              >
                <ThumbsDown className="h-5 w-5" />
                <span>Not Relevant</span>
              </Button>
            </div>
          </div>

          {/* Relevance Reason */}
          {isRelevant === true && (
            <div className="space-y-3 animate-in fade-in slide-in-from-top-2">
              <Label className="text-sm font-medium">Why is this relevant?</Label>
              <RadioGroup value={reason} onValueChange={setReason} className="space-y-2 max-h-40 overflow-y-auto">
                {RELEVANCE_REASONS.map((r) => (
                  <div key={r.value} className="flex items-start space-x-3 p-2 rounded-lg hover:bg-slate-50 transition-colors">
                    <RadioGroupItem value={r.value} id={`rel-${r.value}`} className="mt-0.5" />
                    <Label htmlFor={`rel-${r.value}`} className="flex-1 cursor-pointer">
                      <span className="font-medium text-sm">{r.label}</span>
                      <p className="text-xs text-slate-500">{r.description}</p>
                    </Label>
                  </div>
                ))}
              </RadioGroup>

              <div className="space-y-2">
                <Label className="text-sm font-medium">Keywords to prioritize (optional)</Label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Add keyword..."
                    value={newKeyword}
                    onChange={(e) => setNewKeyword(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addKeyword())}
                    className="flex-1"
                  />
                  <Button type="button" size="sm" onClick={addKeyword} disabled={!newKeyword.trim()}>
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
                {includeKeywords.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {includeKeywords.map((kw) => (
                      <Badge key={kw} variant="secondary" className="gap-1 pr-1">
                        {kw}
                        <button onClick={() => removeKeyword(kw)} className="ml-1 hover:bg-slate-300 rounded-full p-0.5">
                          <X className="h-3 w-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                )}
                <p className="text-xs text-slate-500 flex items-center gap-1">
                  <Sparkles className="h-3 w-3" />
                  AI will learn to prioritize articles with these keywords
                </p>
              </div>
            </div>
          )}

          {/* Irrelevance Reason */}
          {isRelevant === false && (
            <div className="space-y-3 animate-in fade-in slide-in-from-top-2">
              <Label className="text-sm font-medium">Why is this not relevant?</Label>
              <RadioGroup value={reason} onValueChange={setReason} className="space-y-2 max-h-40 overflow-y-auto">
                {IRRELEVANCE_REASONS.map((r) => (
                  <div key={r.value} className="flex items-start space-x-3 p-2 rounded-lg hover:bg-slate-50 transition-colors">
                    <RadioGroupItem value={r.value} id={r.value} className="mt-0.5" />
                    <Label htmlFor={r.value} className="flex-1 cursor-pointer">
                      <span className="font-medium text-sm">{r.label}</span>
                      <p className="text-xs text-slate-500">{r.description}</p>
                    </Label>
                  </div>
                ))}
              </RadioGroup>

              <div className="space-y-2">
                <Label className="text-sm font-medium">Additional details (optional)</Label>
                <Textarea
                  placeholder="E.g., 'Articles about grocery store mergers aren't relevant to our SaaS business'"
                  value={details}
                  onChange={(e) => setDetails(e.target.value)}
                  className="h-20 resize-none"
                />
                <p className="text-xs text-slate-500 flex items-center gap-1">
                  <Sparkles className="h-3 w-3" />
                  AI will extract patterns from your feedback to filter similar articles
                </p>
              </div>
            </div>
          )}

          {/* Learning Indicator */}
          {isAnalyzing && (
            <div className="bg-violet-50 border border-violet-200 rounded-lg p-3 flex items-center gap-3">
              <Loader2 className="h-5 w-5 text-violet-600 animate-spin" />
              <div>
                <p className="text-sm font-medium text-violet-900">AI is learning...</p>
                <p className="text-xs text-violet-600">Extracting patterns to improve future filtering</p>
              </div>
            </div>
          )}

          {/* Submit Button */}
          <div className="flex gap-3 pt-2">
            <Button variant="outline" onClick={handleClose} className="flex-1">
              Cancel
            </Button>
            <Button 
              onClick={handleSubmit} 
              disabled={feedbackMutation.isPending || isRelevant === null}
              className="flex-1"
            >
              {feedbackMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : (
                "Submit Feedback"
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}