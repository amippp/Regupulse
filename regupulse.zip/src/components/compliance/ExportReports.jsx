import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Download, FileSpreadsheet, FileText } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function ExportReports({ updates, filters }) {
  const [open, setOpen] = useState(false);
  const [exportFormat, setExportFormat] = useState("csv");
  const [includeFields, setIncludeFields] = useState({
    title: true,
    source: true,
    domain: true,
    jurisdiction: true,
    risk_score: true,
    status: true,
    summary: true,
    compliance_actions: true,
    key_dates: true,
    scan_date: true
  });

  const toggleField = (field) => {
    setIncludeFields(prev => ({ ...prev, [field]: !prev[field] }));
  };

  const exportData = () => {
    const selectedFields = Object.entries(includeFields)
      .filter(([_, include]) => include)
      .map(([field]) => field);

    if (exportFormat === "csv") {
      exportCSV(selectedFields);
    } else {
      exportJSON(selectedFields);
    }
    
    setOpen(false);
    toast.success(`Exported ${updates.length} updates as ${exportFormat.toUpperCase()}`);
  };

  const exportCSV = (fields) => {
    const headers = fields.join(",");
    const rows = updates.map(update => {
      return fields.map(field => {
        let value = update[field];
        if (Array.isArray(value)) {
          value = value.join("; ");
        }
        // Escape quotes and wrap in quotes if contains comma
        if (typeof value === "string") {
          value = value.replace(/"/g, '""');
          if (value.includes(",") || value.includes("\n")) {
            value = `"${value}"`;
          }
        }
        return value || "";
      }).join(",");
    });

    const csv = [headers, ...rows].join("\n");
    downloadFile(csv, `compliance-report-${format(new Date(), "yyyy-MM-dd")}.csv`, "text/csv");
  };

  const exportJSON = (fields) => {
    const data = updates.map(update => {
      const filtered = {};
      fields.forEach(field => {
        filtered[field] = update[field];
      });
      return filtered;
    });

    const json = JSON.stringify(data, null, 2);
    downloadFile(json, `compliance-report-${format(new Date(), "yyyy-MM-dd")}.json`, "application/json");
  };

  const downloadFile = (content, filename, mimeType) => {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const fieldLabels = {
    title: "Title",
    source: "Source",
    domain: "Domain",
    jurisdiction: "Jurisdiction",
    risk_score: "Risk Score",
    status: "Status",
    summary: "Summary",
    compliance_actions: "Compliance Actions",
    key_dates: "Key Dates",
    scan_date: "Scan Date"
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <Download className="h-4 w-4" />
          Export
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Export Compliance Report</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          <div className="space-y-2">
            <Label>Format</Label>
            <Select value={exportFormat} onValueChange={setExportFormat}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="csv">
                  <div className="flex items-center gap-2">
                    <FileSpreadsheet className="h-4 w-4" />
                    CSV (Excel compatible)
                  </div>
                </SelectItem>
                <SelectItem value="json">
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    JSON
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-3">
            <Label>Include Fields</Label>
            <div className="grid grid-cols-2 gap-3">
              {Object.entries(fieldLabels).map(([field, label]) => (
                <div key={field} className="flex items-center gap-2">
                  <Checkbox 
                    id={field}
                    checked={includeFields[field]}
                    onCheckedChange={() => toggleField(field)}
                  />
                  <label htmlFor={field} className="text-sm cursor-pointer">{label}</label>
                </div>
              ))}
            </div>
          </div>
          
          <div className="bg-slate-50 rounded-lg p-3 text-sm text-slate-600">
            {updates.length} updates will be exported based on current filters
          </div>
        </div>
        
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={exportData}>
            <Download className="h-4 w-4 mr-2" />
            Export {exportFormat.toUpperCase()}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}