import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Gavel, Building2, TrendingUp, ChevronRight, Scale } from "lucide-react";
import DomainBadge from "./DomainBadge";
import JurisdictionBadge from "./JurisdictionBadge";
import { format } from "date-fns";

export default function LegalEventsSection({ updates, onSelectUpdate }) {
  // Show all legal event types: Enforcement, Ruling, Court Filing, Class Action
  const legalTypes = ["Enforcement", "Ruling", "Court Filing", "Class Action"];
  const legalEvents = updates
    .filter(u => legalTypes.includes(u.update_type))
    .filter((event, index, self) => {
      // Remove duplicates based on normalized title
      const normalizedTitle = event.title?.toLowerCase().trim();
      return index === self.findIndex(e => e.title?.toLowerCase().trim() === normalizedTitle);
    })
    .sort((a, b) => {
      // Prioritize those with deep analysis
      if (a.is_court_decision_or_enforcement && !b.is_court_decision_or_enforcement) return -1;
      if (!a.is_court_decision_or_enforcement && b.is_court_decision_or_enforcement) return 1;
      return new Date(b.created_date) - new Date(a.created_date);
    });

  if (legalEvents.length === 0) return null;

  return (
    <div className="mb-8">
      <div className="flex items-center gap-2 mb-4">
        <div className="p-2 rounded-lg bg-amber-100">
          <Gavel className="h-5 w-5 text-amber-700" />
        </div>
        <div>
          <h2 className="text-lg font-semibold text-slate-900">Legal Events</h2>
          <p className="text-sm text-slate-500">Court decisions, enforcement actions, filings & class actions</p>
        </div>
        <Badge className="ml-auto bg-amber-100 text-amber-700 hover:bg-amber-100">
          {legalEvents.length} {legalEvents.length === 1 ? 'event' : 'events'}
        </Badge>
      </div>

      <div className="grid gap-4">
        {legalEvents.map(event => (
          <Card 
            key={event.id}
            onClick={() => onSelectUpdate(event)}
            className="p-4 border-l-4 border-l-amber-500 hover:shadow-lg transition-all cursor-pointer group bg-gradient-to-r from-amber-50/50 to-white"
          >
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-center gap-2 mb-2">
                  <Badge variant="outline" className={
                    event.update_type === "Enforcement" ? "bg-red-100 text-red-700 border-red-200" :
                    event.update_type === "Ruling" ? "bg-amber-100 text-amber-700 border-amber-200" :
                    event.update_type === "Court Filing" ? "bg-purple-100 text-purple-700 border-purple-200" :
                    "bg-blue-100 text-blue-700 border-blue-200"
                  }>
                    <Scale className="h-3 w-3 mr-1" />
                    {event.update_type}
                  </Badge>
                  <DomainBadge domain={event.domain} />
                  <JurisdictionBadge jurisdiction={event.jurisdiction} />
                </div>

                <h3 className="font-semibold text-slate-900 group-hover:text-amber-700 transition-colors line-clamp-2 mb-2">
                  {event.title}
                </h3>

                {event.involved_parties?.length > 0 && (
                  <div className="flex items-center gap-2 text-sm text-slate-600 mb-2">
                    <Building2 className="h-4 w-4 text-slate-400" />
                    <span className="line-clamp-1">{event.involved_parties.join(', ')}</span>
                  </div>
                )}

                {event.enforcement_type && (
                  <Badge variant="outline" className="text-xs mr-2">
                    {event.enforcement_type}
                  </Badge>
                )}

                {event.legal_field && (
                  <Badge variant="outline" className="text-xs">
                    {event.legal_field}
                  </Badge>
                )}

                {event.possible_implications && (
                  <p className="text-sm text-slate-600 mt-2 line-clamp-2">
                    <span className="font-medium">SaaS Impact:</span> {event.possible_implications}
                  </p>
                )}

                {event.trend_analysis && (
                  <div className="flex items-start gap-2 mt-2 text-xs text-slate-500">
                    <TrendingUp className="h-3.5 w-3.5 mt-0.5 shrink-0" />
                    <span className="line-clamp-1">{event.trend_analysis}</span>
                  </div>
                )}

                <div className="flex items-center gap-3 mt-3 text-xs text-slate-500">
                  <span>{event.source}</span>
                  {event.publish_date && (
                    <span>{format(new Date(event.publish_date), "MMM d, yyyy")}</span>
                  )}
                </div>
              </div>

              <ChevronRight className="h-5 w-5 text-slate-400 group-hover:text-amber-600 transition-colors shrink-0" />
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}