import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ExternalLink, Calendar, Building2, AlertTriangle, CheckCircle2, Clock, FileText, Brain } from "lucide-react";
import RiskBadge from "./RiskBadge";
import DomainBadge from "./DomainBadge";
import JurisdictionBadge from "./JurisdictionBadge";
import TeamAssignment from "./TeamAssignment";
import RelatedUpdates from "./RelatedUpdates";
import AIInsightsPanel from "./AIInsightsPanel";
import RelevanceFeedbackDialog from "./RelevanceFeedbackDialog";
import { format } from "date-fns";

const statusConfig = {
  "New": { color: "bg-blue-100 text-blue-700", icon: Clock },
  "Under Review": { color: "bg-amber-100 text-amber-700", icon: FileText },
  "Action Required": { color: "bg-red-100 text-red-700", icon: AlertTriangle },
  "Resolved": { color: "bg-emerald-100 text-emerald-700", icon: CheckCircle2 },
  "Monitoring": { color: "bg-violet-100 text-violet-700", icon: Clock }
};

export default function UpdateDetailModal({ update, open, onClose, onStatusChange, allUpdates = [], onSelectUpdate }) {
  const [showRelevanceDialog, setShowRelevanceDialog] = useState(false);
  
  if (!update) return null;

  const StatusIcon = statusConfig[update.status]?.icon || Clock;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex flex-wrap items-center gap-2 mb-2">
            <RiskBadge risk={update.risk_score} />
            <DomainBadge domain={update.domain} />
            <JurisdictionBadge jurisdiction={update.jurisdiction} />
          </div>
          <DialogTitle className="text-xl leading-tight pr-8">{update.title}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          {/* Meta info */}
          <div className="flex flex-wrap items-center gap-4 text-sm text-slate-600 pb-4 border-b">
            <span className="flex items-center gap-1.5">
              <Building2 className="h-4 w-4" />
              {update.source}
            </span>
            {update.scan_date && (
              <span className="flex items-center gap-1.5">
                <Calendar className="h-4 w-4" />
                {format(new Date(update.scan_date), "MMMM d, yyyy")}
              </span>
            )}
            {update.source_url && (
              <a 
                href={update.source_url} 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 text-blue-600 hover:underline"
              >
                <ExternalLink className="h-4 w-4" />
                View Source
              </a>
            )}
          </div>

          {/* Status & Assignment */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <span className="text-sm font-medium text-slate-700">Status</span>
              <Select value={update.status} onValueChange={(v) => onStatusChange(update.id, v)}>
                <SelectTrigger>
                  <div className="flex items-center gap-2">
                    <StatusIcon className="h-4 w-4" />
                    <SelectValue />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  {Object.keys(statusConfig).map(s => (
                    <SelectItem key={s} value={s}>{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <TeamAssignment update={update} onUpdate={onSelectUpdate} />
          </div>

          {/* Summary */}
          <div>
            <h4 className="text-sm font-semibold text-slate-900 mb-2">Summary</h4>
            <p className="text-slate-600 leading-relaxed">{update.summary}</p>
          </div>

          {/* AI Insights */}
          <AIInsightsPanel update={update} />

          {/* Full Analysis - only show if different from summary (excluding "Update Type:" prefix) */}
          {update.full_analysis && (() => {
            const cleanedAnalysis = update.full_analysis.replace(/^Update Type:\s*\w+\s*/i, '').trim().toLowerCase();
            const cleanedSummary = update.summary?.trim().toLowerCase();
            return cleanedAnalysis !== cleanedSummary;
          })() && (
            <div className="bg-slate-50 rounded-lg p-4">
              <h4 className="text-sm font-semibold text-slate-900 mb-2">Detailed Analysis</h4>
              <p className="text-slate-600 leading-relaxed text-sm whitespace-pre-wrap">
                {update.full_analysis.replace(/^Update Type:\s*\w+\s*/i, '').trim()}
              </p>
            </div>
          )}

          {/* Compliance Actions */}
          {update.compliance_actions?.length > 0 && (
            <div>
              <h4 className="text-sm font-semibold text-slate-900 mb-3">Recommended Compliance Actions</h4>
              <ul className="space-y-2">
                {update.compliance_actions.map((action, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-slate-600">
                    <CheckCircle2 className="h-4 w-4 text-emerald-500 mt-0.5 shrink-0" />
                    {action}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Key Dates */}
          {update.key_dates?.length > 0 && (
            <div>
              <h4 className="text-sm font-semibold text-slate-900 mb-3">Key Dates & Deadlines</h4>
              <div className="flex flex-wrap gap-2">
                {update.key_dates.map((date, i) => (
                  <Badge key={i} variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                    <Calendar className="h-3 w-3 mr-1" />
                    {date}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Affected Areas */}
          {update.affected_areas?.length > 0 && (
            <div>
              <h4 className="text-sm font-semibold text-slate-900 mb-3">Affected Business Areas</h4>
              <div className="flex flex-wrap gap-2">
                {update.affected_areas.map((area, i) => (
                  <Badge key={i} variant="outline" className="bg-slate-100 text-slate-700">
                    {area}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Related Updates */}
          {allUpdates.length > 0 && (
            <RelatedUpdates 
              currentUpdate={update} 
              allUpdates={allUpdates} 
              onSelectUpdate={onSelectUpdate} 
            />
          )}

          {/* Train AI Button */}
          <div className="pt-4 border-t">
            <Button 
              variant="outline" 
              className="w-full gap-2"
              onClick={() => setShowRelevanceDialog(true)}
            >
              <Brain className="h-4 w-4 text-violet-600" />
              Train AI - Mark Relevance
            </Button>
            <p className="text-xs text-slate-500 text-center mt-2">
              Help improve future scans by marking this article as relevant or irrelevant
            </p>
          </div>
        </div>

        <RelevanceFeedbackDialog 
          update={update}
          open={showRelevanceDialog}
          onClose={() => setShowRelevanceDialog(false)}
        />
      </DialogContent>
    </Dialog>
  );
}