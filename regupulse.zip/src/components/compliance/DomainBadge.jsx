import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { Brain, Shield, Scale, Users, Globe } from "lucide-react";

export default function DomainBadge({ domain }) {
  const config = {
    "AI Law": {
      className: "bg-violet-50 text-violet-700 border-violet-200",
      icon: Brain
    },
    "Privacy": {
      className: "bg-blue-50 text-blue-700 border-blue-200",
      icon: Shield
    },
    "Antitrust": {
      className: "bg-orange-50 text-orange-700 border-orange-200",
      icon: Scale
    },
    "Consumer Protection": {
      className: "bg-emerald-50 text-emerald-700 border-emerald-200",
      icon: Users
    },
    "Platform Liability": {
      className: "bg-slate-100 text-slate-700 border-slate-200",
      icon: Globe
    }
  };

  const { className, icon: Icon } = config[domain] || { className: "bg-slate-100 text-slate-700", icon: Globe };

  return (
    <Badge variant="outline" className={cn("font-medium gap-1.5", className)}>
      <Icon className="h-3 w-3" />
      {domain}
    </Badge>
  );
}