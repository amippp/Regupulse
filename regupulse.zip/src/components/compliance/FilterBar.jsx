import { useState } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Search, X, SlidersHorizontal, Calendar as CalendarIcon, Sparkles } from "lucide-react";
import { format, subDays, subHours } from "date-fns";
import { cn } from "@/lib/utils";

const domains = ["All Domains", "AI Law", "Privacy", "Antitrust", "Consumer Protection", "Platform Liability", "IP"];
const jurisdictions = ["All Jurisdictions", "United States", "European Union", "United Kingdom", "Israel", "Brazil", "China", "India", "Australia", "Canada", "Global", "Germany", "Netherlands"];
const updateTypes = ["All Types", "Regulatory", "Enforcement", "Ruling", "Court Filing", "Class Action"];

const datePresets = [
  { label: "Last 24 hours", value: "24h", getDate: () => subHours(new Date(), 24) },
  { label: "Last 7 days", value: "7d", getDate: () => subDays(new Date(), 7) },
  { label: "Last 30 days", value: "30d", getDate: () => subDays(new Date(), 30) },
  { label: "All time", value: "all", getDate: () => null }
];

export default function FilterBar({ filters, setFilters }) {
  const [datePreset, setDatePreset] = useState("all");
  
  const hasFilters = filters.search || 
    filters.domain !== "All Domains" || 
    filters.jurisdiction !== "All Jurisdictions" || 
    filters.updateType !== "All Types" ||
    filters.dateFrom;

  const activeFilterCount = [
    filters.search,
    filters.domain !== "All Domains" && filters.domain,
    filters.jurisdiction !== "All Jurisdictions" && filters.jurisdiction,
    filters.updateType !== "All Types" && filters.updateType,
    filters.dateFrom
  ].filter(Boolean).length;

  const clearFilters = () => {
    setFilters({
      search: "",
      domain: "All Domains",
      jurisdiction: "All Jurisdictions",
      updateType: "All Types",
      dateFrom: null
    });
    setDatePreset("all");
  };

  const handleDatePreset = (preset) => {
    setDatePreset(preset.value);
    setFilters({ 
      ...filters, 
      dateFrom: preset.getDate()
    });
  };

  const removeFilter = (filterKey) => {
    const resetValues = {
      search: "",
      domain: "All Domains",
      jurisdiction: "All Jurisdictions",
      updateType: "All Types",
      dateFrom: null
    };
    setFilters({ ...filters, [filterKey]: resetValues[filterKey] });
    if (filterKey === "dateFrom") setDatePreset("all");
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700">
          <SlidersHorizontal className="h-4 w-4" />
          <span className="font-medium text-sm">Filters</span>
          {activeFilterCount > 0 && (
            <Badge variant="secondary" className="bg-blue-100 text-blue-700">
              {activeFilterCount} active
            </Badge>
          )}
        </div>
        {hasFilters && (
          <Button variant="ghost" size="sm" onClick={clearFilters} className="h-8 text-slate-500">
            <X className="h-3.5 w-3.5 mr-1" />
            Clear all
          </Button>
        )}
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        <div className="relative lg:col-span-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input
            placeholder="Search updates..."
            value={filters.search}
            onChange={(e) => setFilters({ ...filters, search: e.target.value })}
            className="pl-9 bg-slate-50 border-slate-200"
          />
        </div>
        
        <Select value={filters.domain} onValueChange={(v) => setFilters({ ...filters, domain: v })}>
          <SelectTrigger className="bg-slate-50 border-slate-200">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {domains.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
          </SelectContent>
        </Select>
        
        <Select value={filters.jurisdiction} onValueChange={(v) => setFilters({ ...filters, jurisdiction: v })}>
          <SelectTrigger className="bg-slate-50 border-slate-200">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {jurisdictions.map(j => <SelectItem key={j} value={j}>{j}</SelectItem>)}
          </SelectContent>
        </Select>
        
        <Select value={filters.updateType} onValueChange={(v) => setFilters({ ...filters, updateType: v })}>
          <SelectTrigger className="bg-slate-50 border-slate-200">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {updateTypes.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
          </SelectContent>
        </Select>

        {/* Date Range Filter */}
        <Popover>
          <PopoverTrigger asChild>
            <Button 
              variant="outline" 
              className={cn(
                "bg-slate-50 border-slate-200 justify-start text-left font-normal",
                filters.dateFrom && "text-blue-700 border-blue-200 bg-blue-50"
              )}
            >
              <CalendarIcon className="h-4 w-4 mr-2" />
              {datePreset !== "all" 
                ? datePresets.find(p => p.value === datePreset)?.label 
                : "Date Range"}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <div className="p-3 border-b space-y-2">
              <p className="text-sm font-medium text-slate-700">Quick Select</p>
              <div className="grid grid-cols-2 gap-2">
                {datePresets.map(preset => (
                  <Button
                    key={preset.value}
                    variant={datePreset === preset.value ? "default" : "outline"}
                    size="sm"
                    onClick={() => handleDatePreset(preset)}
                    className="justify-start"
                  >
                    {preset.label}
                  </Button>
                ))}
              </div>
            </div>
            <Calendar
              mode="single"
              selected={filters.dateFrom}
              onSelect={(date) => {
                setFilters({ ...filters, dateFrom: date });
                setDatePreset("custom");
              }}
              disabled={(date) => date > new Date()}
              initialFocus
            />
          </PopoverContent>
        </Popover>
      </div>

      {/* Active Filter Chips */}
      {hasFilters && (
        <div className="flex flex-wrap gap-2 pt-2 border-t border-slate-100">
          {filters.search && (
            <Badge variant="secondary" className="bg-slate-100 text-slate-700 gap-1">
              Search: "{filters.search}"
              <X className="h-3 w-3 cursor-pointer hover:text-red-500" onClick={() => removeFilter('search')} />
            </Badge>
          )}
          {filters.domain !== "All Domains" && (
            <Badge variant="secondary" className="bg-violet-100 text-violet-700 gap-1">
              {filters.domain}
              <X className="h-3 w-3 cursor-pointer hover:text-red-500" onClick={() => removeFilter('domain')} />
            </Badge>
          )}
          {filters.jurisdiction !== "All Jurisdictions" && (
            <Badge variant="secondary" className="bg-blue-100 text-blue-700 gap-1">
              {filters.jurisdiction}
              <X className="h-3 w-3 cursor-pointer hover:text-red-500" onClick={() => removeFilter('jurisdiction')} />
            </Badge>
          )}
          {filters.updateType !== "All Types" && (
            <Badge variant="secondary" className="bg-amber-100 text-amber-700 gap-1">
              {filters.updateType}
              <X className="h-3 w-3 cursor-pointer hover:text-red-500" onClick={() => removeFilter('updateType')} />
            </Badge>
          )}
          {filters.dateFrom && (
            <Badge variant="secondary" className="bg-emerald-100 text-emerald-700 gap-1">
              From: {format(filters.dateFrom, "MMM d, yyyy")}
              <X className="h-3 w-3 cursor-pointer hover:text-red-500" onClick={() => removeFilter('dateFrom')} />
            </Badge>
          )}
        </div>
      )}
    </div>
  );
}