import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { Clock, Check, Calendar } from "lucide-react";
import { format, addDays, nextMonday, setHours } from "date-fns";
import { toast } from "sonner";

export default function ScheduledScanSettings() {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  
  const { data: schedules = [] } = useQuery({
    queryKey: ['scan-schedule'],
    queryFn: () => base44.entities.ScanSchedule.list()
  });
  
  const schedule = schedules[0] || {
    frequency: "manual",
    day_of_week: "monday",
    hour: 8,
    is_active: false
  };
  
  const [settings, setSettings] = useState(schedule);
  
  useEffect(() => {
    if (schedules[0]) {
      setSettings(schedules[0]);
    }
  }, [schedules]);

  const calculateNextScan = () => {
    if (settings.frequency === "manual") return null;
    
    const now = new Date();
    let next;
    
    if (settings.frequency === "daily") {
      next = setHours(addDays(now, 1), settings.hour || 8);
    } else {
      // Weekly
      const days = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
      const targetDay = days.indexOf(settings.day_of_week || "monday");
      const currentDay = now.getDay();
      const daysUntil = (targetDay - currentDay + 7) % 7 || 7;
      next = setHours(addDays(now, daysUntil), settings.hour || 8);
    }
    
    return next;
  };

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      const nextScan = calculateNextScan();
      const payload = {
        ...data,
        next_scan: nextScan?.toISOString()
      };
      
      if (schedule.id) {
        return base44.entities.ScanSchedule.update(schedule.id, payload);
      } else {
        return base44.entities.ScanSchedule.create(payload);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scan-schedule'] });
      toast.success("Schedule settings saved");
      setOpen(false);
    }
  });

  const nextScan = calculateNextScan();

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <Clock className="h-4 w-4" />
          Schedule
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Automatic Scan Schedule
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>Enable Automatic Scans</Label>
              <p className="text-sm text-slate-500">Run compliance scans on a schedule</p>
            </div>
            <Switch 
              checked={settings.is_active}
              onCheckedChange={(checked) => setSettings(prev => ({ 
                ...prev, 
                is_active: checked,
                frequency: checked ? (prev.frequency === "manual" ? "weekly" : prev.frequency) : "manual"
              }))}
            />
          </div>
          
          {settings.is_active && (
            <>
              <div className="space-y-2">
                <Label>Frequency</Label>
                <Select 
                  value={settings.frequency}
                  onValueChange={(v) => setSettings(prev => ({ ...prev, frequency: v }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              {settings.frequency === "weekly" && (
                <div className="space-y-2">
                  <Label>Day of Week</Label>
                  <Select 
                    value={settings.day_of_week || "monday"}
                    onValueChange={(v) => setSettings(prev => ({ ...prev, day_of_week: v }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="monday">Monday</SelectItem>
                      <SelectItem value="tuesday">Tuesday</SelectItem>
                      <SelectItem value="wednesday">Wednesday</SelectItem>
                      <SelectItem value="thursday">Thursday</SelectItem>
                      <SelectItem value="friday">Friday</SelectItem>
                      <SelectItem value="saturday">Saturday</SelectItem>
                      <SelectItem value="sunday">Sunday</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
              
              <div className="space-y-2">
                <Label>Time (Hour)</Label>
                <Select 
                  value={String(settings.hour || 8)}
                  onValueChange={(v) => setSettings(prev => ({ ...prev, hour: parseInt(v) }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: 24 }, (_, i) => (
                      <SelectItem key={i} value={String(i)}>
                        {i.toString().padStart(2, "0")}:00
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              {nextScan && (
                <Card className="p-3 bg-blue-50 border-blue-200">
                  <div className="flex items-center gap-2 text-blue-700">
                    <Calendar className="h-4 w-4" />
                    <span className="text-sm font-medium">Next scan:</span>
                    <span className="text-sm">{format(nextScan, "EEEE, MMM d 'at' h:00 a")}</span>
                  </div>
                </Card>
              )}
            </>
          )}
        </div>
        
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={() => saveMutation.mutate(settings)} disabled={saveMutation.isPending}>
            <Check className="h-4 w-4 mr-2" />
            Save Schedule
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}