import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Activity, CheckCircle2, AlertTriangle, XCircle, RefreshCw, Rss, Globe, RotateCcw, Zap } from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export default function SourceHealthDashboard() {
  const [open, setOpen] = useState(false);
  const [retryingSource, setRetryingSource] = useState(null);
  const queryClient = useQueryClient();

  const { data: sources = [], isLoading, refetch } = useQuery({
    queryKey: ['source-health'],
    queryFn: () => base44.entities.SourceHealth.list('-last_check')
  });

  const healthyCount = sources.filter(s => s.status === "healthy").length;
  const degradedCount = sources.filter(s => s.status === "degraded").length;
  const failingCount = sources.filter(s => s.status === "failing").length;

  const statusConfig = {
    healthy: { icon: CheckCircle2, color: "text-emerald-600", bg: "bg-emerald-100", label: "Healthy" },
    degraded: { icon: AlertTriangle, color: "text-amber-600", bg: "bg-amber-100", label: "Degraded" },
    failing: { icon: XCircle, color: "text-red-600", bg: "bg-red-100", label: "Failing" }
  };

  const handleRetrySource = async (source) => {
    setRetryingSource(source.id);
    try {
      // Trigger a full scan - in a more advanced implementation, 
      // you could have a dedicated endpoint for single-source retry
      const response = await base44.functions.invoke('scanRssFeeds');
      const result = response.data;
      
      if (result.success) {
        toast.success("Source re-scanned successfully");
        queryClient.invalidateQueries({ queryKey: ['source-health'] });
        queryClient.invalidateQueries({ queryKey: ['regulatory-updates'] });
      } else {
        toast.error("Retry failed: " + result.error);
      }
    } catch (error) {
      toast.error("Failed to retry: " + error.message);
    } finally {
      setRetryingSource(null);
    }
  };

  return (
    <TooltipProvider>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <Button variant="outline" size="sm" className="gap-2">
            <Activity className="h-4 w-4" />
            Sources
            {failingCount > 0 && (
              <Badge variant="destructive" className="ml-1 h-5 px-1.5">
                {failingCount}
              </Badge>
            )}
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-2xl max-h-[80vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Source Health Dashboard
            </DialogTitle>
          </DialogHeader>
          
          <div className="grid grid-cols-3 gap-3 py-4">
            <Card className="p-3 bg-emerald-50 border-emerald-200">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-emerald-600" />
                <div>
                  <p className="text-2xl font-bold text-emerald-700">{healthyCount}</p>
                  <p className="text-xs text-emerald-600">Healthy</p>
                </div>
              </div>
            </Card>
            <Card className="p-3 bg-amber-50 border-amber-200">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-amber-600" />
                <div>
                  <p className="text-2xl font-bold text-amber-700">{degradedCount}</p>
                  <p className="text-xs text-amber-600">Degraded</p>
                </div>
              </div>
            </Card>
            <Card className="p-3 bg-red-50 border-red-200">
              <div className="flex items-center gap-2">
                <XCircle className="h-5 w-5 text-red-600" />
                <div>
                  <p className="text-2xl font-bold text-red-700">{failingCount}</p>
                  <p className="text-xs text-red-600">Failing</p>
                </div>
              </div>
            </Card>
          </div>
          
          <div className="flex-1 overflow-y-auto space-y-2">
            {sources.length === 0 ? (
              <div className="text-center py-8 text-slate-500">
                <Activity className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No source health data yet</p>
                <p className="text-sm">Run a scan to populate source health</p>
              </div>
            ) : (
              sources.map(source => {
                const config = statusConfig[source.status] || statusConfig.healthy;
                const Icon = config.icon;
                const isRetrying = retryingSource === source.id;
                
                return (
                  <div 
                    key={source.id}
                    className={cn(
                      "flex items-center gap-3 p-3 rounded-lg border transition-all",
                      source.status === "failing" && "bg-red-50 border-red-200",
                      source.status === "degraded" && "bg-amber-50 border-amber-200",
                      source.status === "healthy" && "bg-white border-slate-200 hover:bg-slate-50"
                    )}
                  >
                    <div className={cn("p-2 rounded-full", config.bg)}>
                      {source.source_type === "rss" ? (
                        <Rss className={cn("h-4 w-4", config.color)} />
                      ) : (
                        <Globe className={cn("h-4 w-4", config.color)} />
                      )}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-slate-900">{source.source_name}</p>
                      <p className="text-xs text-slate-500 truncate">{source.source_url}</p>
                      
                      {/* Error details with retry info */}
                      {source.error_message && (
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <p className="text-xs text-red-600 mt-1 cursor-help truncate">
                              {source.error_message}
                            </p>
                          </TooltipTrigger>
                          <TooltipContent side="bottom" className="max-w-sm">
                            <p className="font-medium">Error Details</p>
                            <p className="text-sm">{source.error_message}</p>
                            {source.consecutive_failures > 0 && (
                              <p className="text-sm mt-1 text-amber-500">
                                Failed {source.consecutive_failures} consecutive time{source.consecutive_failures > 1 ? 's' : ''}
                              </p>
                            )}
                            {source.retries_used > 1 && (
                              <p className="text-xs text-slate-400 mt-1">
                                Used {source.retries_used} retries before failing
                              </p>
                            )}
                          </TooltipContent>
                        </Tooltip>
                      )}
                      
                      {/* Consecutive failures badge */}
                      {source.consecutive_failures > 0 && (
                        <Badge variant="outline" className="mt-1 text-xs bg-red-100 text-red-700 border-red-200">
                          {source.consecutive_failures} consecutive failure{source.consecutive_failures > 1 ? 's' : ''}
                        </Badge>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {/* Retry button for failing/degraded sources */}
                      {(source.status === "failing" || source.status === "degraded") && (
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => handleRetrySource(source)}
                              disabled={isRetrying}
                            >
                              <RotateCcw className={cn("h-4 w-4", isRetrying && "animate-spin")} />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Retry this source</TooltipContent>
                        </Tooltip>
                      )}
                      
                      <div className="text-right shrink-0">
                        <Badge variant="outline" className={cn(config.color, "border-current")}>
                          {config.label}
                        </Badge>
                        {source.last_check && (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <p className="text-xs text-slate-500 mt-1 cursor-help">
                                {formatDistanceToNow(new Date(source.last_check), { addSuffix: true })}
                              </p>
                            </TooltipTrigger>
                            <TooltipContent>
                              Last checked: {format(new Date(source.last_check), "PPpp")}
                              {source.items_fetched > 0 && (
                                <span className="block text-xs text-slate-400">
                                  {source.items_fetched} items fetched
                                </span>
                              )}
                            </TooltipContent>
                          </Tooltip>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
          
          <div className="flex justify-between items-center pt-4 border-t">
            <div className="text-xs text-slate-500 flex items-center gap-1">
              <Zap className="h-3 w-3" />
              Auto-retry with exponential backoff enabled
            </div>
            <Button variant="outline" onClick={() => refetch()} disabled={isLoading}>
              <RefreshCw className={cn("h-4 w-4 mr-2", isLoading && "animate-spin")} />
              Refresh
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </TooltipProvider>
  );
}