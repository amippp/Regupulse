import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, Cell } from "recharts";

const COLORS = {
  "AI Law": "#8b5cf6",
  "Privacy": "#3b82f6",
  "Antitrust": "#f97316",
  "Consumer Protection": "#10b981",
  "Platform Liability": "#64748b"
};

export default function DomainChart({ updates }) {
  const domains = ["AI Law", "Privacy", "Antitrust", "Consumer Protection", "Platform Liability"];
  
  const data = domains.map(domain => ({
    name: domain,
    count: updates.filter(u => u.domain === domain).length,
    color: COLORS[domain]
  })).filter(d => d.count > 0);

  if (data.length === 0) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-semibold">Updates by Domain</CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center h-48 text-slate-400">
          No data available
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-semibold">Updates by Domain</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={data} layout="vertical" margin={{ left: 20, right: 20 }}>
            <XAxis type="number" hide />
            <YAxis 
              type="category" 
              dataKey="name" 
              width={100}
              tick={{ fontSize: 11, fill: "#64748b" }}
            />
            <Tooltip 
              formatter={(value) => [value, "Updates"]}
              contentStyle={{ borderRadius: 8, border: "1px solid #e2e8f0" }}
            />
            <Bar dataKey="count" radius={[0, 4, 4, 0]}>
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}