import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Radar, CheckCircle2, Sparkles, AlertTriangle, Zap, Calendar } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

// Static built-in sources with unique IDs matching the backend
const staticSources = [
  // US Government
  { id: "ftc", name: "FTC Press Releases", region: "US", type: "rss" },
  { id: "ftc_consumer", name: "FTC Consumer Protection", region: "US", type: "rss" },
  { id: "ftc_competition", name: "FTC Competition", region: "US", type: "rss" },
  { id: "occ_news", name: "OCC News Releases", region: "US", type: "rss" },
  { id: "occ_bulletins", name: "OCC Bulletins", region: "US", type: "rss" },
  { id: "cfpb", name: "CFPB Newsroom", region: "US", type: "scrape" },
  { id: "fdic", name: "FDIC Press Releases", region: "US", type: "scrape" },
  // EU
  { id: "eu_competition", name: "EU Competition News", region: "EU", type: "rss" },
  // Legal Blogs
  { id: "scotusblog", name: "SCOTUSblog", region: "US", type: "rss" },
  { id: "ipkat", name: "IPKat", region: "Global", type: "rss" },
  { id: "lawworkplace", name: "Law and the Workplace", region: "US", type: "rss" },
  { id: "cfs_monitor", name: "Consumer Financial Services Law Monitor", region: "US", type: "rss" },

  // Fintech
  { id: "fintech_weekly", name: "Fintech Business Weekly", region: "US", type: "rss" },
  // Law Firms
  { id: "skadden", name: "Skadden Insights", region: "US", type: "scrape" },
  { id: "ebglaw", name: "EBG Law Insights", region: "US", type: "scrape" },
  { id: "jacksonlewis", name: "Jackson Lewis", region: "US", type: "scrape" },
  // Legal News
  { id: "law360", name: "Law360", region: "US", type: "rss" },
  { id: "law360_pulse", name: "Law360 Pulse Legal Tech", region: "US", type: "rss" }
];

const dateRangeOptions = [
  { value: "7", label: "Last 7 days" },
  { value: "14", label: "Last 14 days" },
  { value: "30", label: "Last 30 days" },
  { value: "45", label: "Last 45 days" },
  { value: "60", label: "Last 60 days" }
];

export default function ScanButton({ onScanComplete, autoOpen = false }) {
  const [open, setOpen] = useState(autoOpen);
  const [scanning, setScanning] = useState(false);
  const [selectedSources, setSelectedSources] = useState([]);
  const [scanPhase, setScanPhase] = useState("");
  const [scanProgress, setScanProgress] = useState(0);
  const [scanResult, setScanResult] = useState(null);
  const [dateRange, setDateRange] = useState("14");

  // Fetch dynamic compliance sources from database and combine with static sources
  const { data: sources = staticSources, isLoading: loadingSources } = useQuery({
    queryKey: ['scan-sources'],
    queryFn: async () => {
      const dynamicSources = await base44.entities.ComplianceSource.filter({ is_active: true });
      const mappedDynamic = dynamicSources.map(s => ({
        id: s.id, // Database ID for dynamic sources
        name: s.name,
        region: s.region || "Global",
        type: s.type,
        isDynamic: true
      }));
      // Combine static and dynamic sources
      return [...staticSources, ...mappedDynamic];
    }
  });

  // Initialize selected sources when dialog opens, reset on close
  useEffect(() => {
    if (open && sources.length > 0) {
      // Select all sources by default when opening
      setSelectedSources(sources.map(s => s.id));
    } else if (!open) {
      // Reset state when closing
      setScanResult(null);
      setScanProgress(0);
      setScanPhase("");
    }
  }, [open, sources]);

  const handleScan = async () => {
    setScanning(true);
    setScanResult(null);
    setScanProgress(0);
    
    // Simulate progress phases
    const phases = [
      { text: "Fetching RSS feeds in parallel...", progress: 20 },
      { text: "Scraping regulatory websites...", progress: 40 },
      { text: "Deduplicating against existing records...", progress: 60 },
      { text: "AI analyzing relevance...", progress: 80 },
      { text: "Saving new updates...", progress: 95 }
    ];
    
    let phaseIndex = 0;
    const progressInterval = setInterval(() => {
      if (phaseIndex < phases.length) {
        setScanPhase(phases[phaseIndex].text);
        setScanProgress(phases[phaseIndex].progress);
        phaseIndex++;
      }
    }, 2000);
    
    try {
      // Pass selected source IDs to the backend
      const response = await base44.functions.invoke('scanRssFeeds', { 
        dateRangeDays: parseInt(dateRange),
        selectedSourceIds: selectedSources
      });
      const result = response.data;
      
      clearInterval(progressInterval);
      setScanProgress(100);
      setScanPhase("Complete!");
      setScanResult(result);

      if (result.success) {
        if (result.updates_saved > 0) {
          toast.success(`Found ${result.updates_saved} new regulatory updates`, {
            description: `Scanned ${result.sources?.rss_feeds || 0} feeds in ${(result.execution_time_ms / 1000).toFixed(1)}s`
          });
        } else {
          toast.info("No new relevant updates found", {
            description: result.sources?.duplicates_skipped > 0 
              ? `${result.sources.duplicates_skipped} duplicates were skipped`
              : "All sources are up to date"
          });
        }
        onScanComplete?.(result);
      } else {
        toast.error(result.error || "Scan failed");
      }

      // Keep dialog open to show results - don't auto-close so user can review
      
    } catch (error) {
      clearInterval(progressInterval);
      console.error("Scan error:", error);
      toast.error("Failed to complete scan: " + (error.message || "Unknown error"));
      setScanResult({ success: false, error: error.message });
    } finally {
      setScanning(false);
      setScanProgress(0);
      setScanPhase("");
    }
  };

  const toggleSource = (id) => {
    setSelectedSources(prev => 
      prev.includes(id) 
        ? prev.filter(s => s !== id)
        : [...prev, id]
    );
  };

  return (
    <>
      <Button 
        onClick={() => setOpen(true)}
        className="bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-700 hover:to-violet-700 shadow-lg shadow-blue-500/25"
      >
        <Radar className="h-4 w-4 mr-2" />
        Run Compliance Scan
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
                <DialogContent className="max-w-lg w-full max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-violet-600" />
              AI Compliance Scanner
            </DialogTitle>
            <DialogDescription>
              Select regulatory sources to scan for the latest updates affecting your SaaS business.
            </DialogDescription>
          </DialogHeader>

          {!scanning && !scanResult ? (
            <div className="space-y-4 mt-4">
              {/* Date Range Selector */}
              <div className="space-y-2">
                <Label className="flex items-center gap-2 text-sm font-medium">
                  <Calendar className="h-4 w-4 text-slate-500" />
                  Scan Date Range
                </Label>
                <Select value={dateRange} onValueChange={setDateRange}>
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {dateRangeOptions.map(opt => (
                      <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-slate-500">
                  Fetch articles published within the selected time range
                </p>
              </div>

              <div className="space-y-3 max-h-48 overflow-y-auto border-t pt-3">
                {loadingSources ? (
                  <p className="text-sm text-slate-500 text-center py-4">Loading sources...</p>
                ) : sources.length === 0 ? (
                  <p className="text-sm text-slate-500 text-center py-4">No active sources found</p>
                ) : (
                  <>
                    {/* Select All Checkbox */}
                    <div className="flex items-center space-x-3 pb-2 border-b">
                      <Checkbox 
                        id="select-all"
                        checked={selectedSources.length === sources.length}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setSelectedSources(sources.map(s => s.id));
                          } else {
                            setSelectedSources([]);
                          }
                        }}
                      />
                      <Label htmlFor="select-all" className="flex-1 cursor-pointer font-medium">
                        Select All
                        <span className="text-xs text-slate-500 ml-2">
                          ({selectedSources.length}/{sources.length} selected)
                        </span>
                      </Label>
                    </div>
                    {sources.map(source => (
                    <div key={source.id} className="flex items-center space-x-3">
                      <Checkbox 
                        id={source.id}
                        checked={selectedSources.includes(source.id)}
                        onCheckedChange={() => toggleSource(source.id)}
                      />
                      <Label htmlFor={source.id} className="flex-1 cursor-pointer">
                        <span className="font-medium">{source.name}</span>
                        <span className="text-xs text-slate-500 ml-2">({source.region} • {source.type})</span>
                      </Label>
                    </div>
                    ))}
                  </>
                )}
              </div>

              <Button 
                onClick={handleScan} 
                className="w-full"
                disabled={selectedSources.length === 0}
              >
                <Radar className="h-4 w-4 mr-2" />
                Start Scan ({selectedSources.length} sources)
              </Button>
            </div>
          ) : scanning ? (
            <div className="py-8 space-y-6">
              <div className="relative mx-auto w-20 h-20">
                <div className="absolute inset-0 rounded-full border-4 border-violet-200"></div>
                <div className="absolute inset-0 rounded-full border-4 border-violet-600 border-t-transparent animate-spin"></div>
                <Radar className="absolute inset-0 m-auto h-8 w-8 text-violet-600" />
              </div>
              
              <div className="space-y-3">
                <Progress value={scanProgress} className="h-2" />
                <div className="text-center">
                  <p className="font-medium text-slate-900">{scanPhase || "Initializing..."}</p>
                  <p className="text-sm text-slate-500 mt-1">{scanProgress}% complete</p>
                </div>
              </div>
              
              <div className="flex items-center justify-center gap-2 text-xs text-slate-500">
                <Zap className="h-3 w-3" />
                <span>Parallel processing enabled for faster scans</span>
              </div>
            </div>
          ) : scanResult ? (
            <div className="py-4 space-y-4">
              <div className="text-center">
                {scanResult.success ? (
                  <>
                    <div className="mx-auto w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center mb-3">
                      <CheckCircle2 className="h-6 w-6 text-emerald-600" />
                    </div>
                    <p className="font-semibold text-slate-900">Scan Complete!</p>
                    <p className="text-sm text-slate-600">
                      {scanResult.updates_saved > 0 
                        ? `${scanResult.updates_saved} new updates saved`
                        : "No new updates found"}
                    </p>
                  </>
                ) : (
                  <>
                    <div className="mx-auto w-12 h-12 rounded-full bg-red-100 flex items-center justify-center mb-3">
                      <AlertTriangle className="h-6 w-6 text-red-600" />
                    </div>
                    <p className="font-semibold text-slate-900">Scan Failed</p>
                    <p className="text-sm text-red-600">{scanResult.error}</p>
                  </>
                )}
              </div>
              
              {scanResult.success && scanResult.sources && (
                <div className="space-y-3">
                  <div className="bg-slate-50 rounded-lg p-4 space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-slate-600">Sources scanned</span>
                      <span className="font-medium">{scanResult.sources.rss_feeds + scanResult.sources.scraped_sites}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-600">Items processed</span>
                      <span className="font-medium">{scanResult.sources.rss_items + scanResult.sources.scraped_items}</span>
                    </div>
                    {scanResult.sources.duplicates_skipped > 0 && (
                      <div className="flex justify-between text-amber-600">
                        <span>Duplicates skipped</span>
                        <span className="font-medium">{scanResult.sources.duplicates_skipped}</span>
                      </div>
                    )}
                    <div className="flex justify-between pt-2 border-t">
                      <span className="text-slate-600">Execution time</span>
                      <span className="font-medium">{(scanResult.execution_time_ms / 1000).toFixed(1)}s</span>
                    </div>
                  </div>

                  {/* New Articles Found */}
                  {scanResult.saved_updates && scanResult.saved_updates.length > 0 && (
                    <div className="border rounded-lg overflow-hidden">
                      <div className="bg-emerald-50 px-3 py-2 border-b border-emerald-100">
                        <span className="text-sm font-medium text-emerald-800">
                          New Articles ({scanResult.saved_updates.length})
                        </span>
                      </div>
                      <div className="max-h-48 overflow-y-auto divide-y">
                        {scanResult.saved_updates.map((update, idx) => (
                          <div key={idx} className="px-3 py-2.5 hover:bg-slate-50">
                            <p className="text-sm font-medium text-slate-900 line-clamp-2 break-words">{update.title}</p>
                            <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                              <span className="truncate max-w-[120px]">{update.source}</span>
                              {update.source_url && (
                                <a 
                                  href={update.source_url} 
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="text-blue-600 hover:underline flex-shrink-0"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  View →
                                </a>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Errors */}
                  {scanResult.feed_errors && scanResult.feed_errors.length > 0 && (
                    <div className="border border-red-200 rounded-lg overflow-hidden">
                      <div className="bg-red-50 px-3 py-2 border-b border-red-100">
                        <span className="text-sm font-medium text-red-800">
                          Errors ({scanResult.feed_errors.length})
                        </span>
                      </div>
                      <div className="max-h-32 overflow-y-auto divide-y divide-red-100">
                        {scanResult.feed_errors.map((error, idx) => (
                          <div key={idx} className="px-3 py-2 text-xs text-red-700 break-words">
                            {error}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              <Button 
              variant="outline" 
              className="w-full mt-2"
              onClick={() => {
                setOpen(false);
                setScanResult(null);
              }}
              >
              Close
              </Button>
              </div>
              ) : null}
        </DialogContent>
      </Dialog>
    </>
  );
}