import { Badge } from "@/components/ui/badge";

const flagEmojis = {
  "United States": "🇺🇸",
  "European Union": "🇪🇺",
  "United Kingdom": "🇬🇧",
  "Israel": "🇮🇱",
  "Brazil": "🇧🇷",
  "China": "🇨🇳",
  "India": "🇮🇳",
  "Australia": "🇦🇺",
  "Canada": "🇨🇦",
  "Global": "🌍",
  "Germany": "🇩🇪"
};

export default function JurisdictionBadge({ jurisdiction }) {
  const flag = flagEmojis[jurisdiction] || "🌍";
  
  return (
    <Badge variant="outline" className="bg-white font-medium gap-1.5 text-slate-700 border-slate-200">
      <span className="text-sm">{flag}</span>
      {jurisdiction}
    </Badge>
  );
}