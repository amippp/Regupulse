import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Library, 
  Search, 
  Plus, 
  CheckCircle2, 
  Globe, 
  Scale, 
  Building2, 
  Newspaper,
  Shield,
  Loader2
} from "lucide-react";
import { toast } from "sonner";

// Pre-defined source library
const SOURCE_LIBRARY = {
  government: [
    { name: "SEC Press Releases", url: "https://www.sec.gov/rss/news/press.xml", region: "US", type: "rss", category: "government" },
    { name: "DOJ Press Releases", url: "https://www.justice.gov/feeds/opa/justice-news.xml", region: "US", type: "rss", category: "government" },
    { name: "FTC News", url: "https://www.ftc.gov/feeds/press-release-consumer-protection.xml", region: "US", type: "rss", category: "government" },
    { name: "CISA Alerts", url: "https://www.cisa.gov/uscert/ncas/alerts.xml", region: "US", type: "rss", category: "government" },
    { name: "EU Commission Press", url: "https://ec.europa.eu/commission/presscorner/api/rss", region: "EU", type: "rss", category: "government" },
    { name: "UK ICO News", url: "https://ico.org.uk/about-the-ico/media-centre/news-and-blogs/?type=rss", region: "UK", type: "rss", category: "government" },
    { name: "GDPR Enforcement Tracker", url: "https://www.enforcementtracker.com/rss.xml", region: "EU", type: "rss", category: "government" },
    { name: "NIST Cybersecurity", url: "https://www.nist.gov/news-events/cybersecurity/rss.xml", region: "US", type: "rss", category: "government" },
    { name: "Federal Reserve Press", url: "https://www.federalreserve.gov/feeds/press_releases.xml", region: "US", type: "rss", category: "government" },
    { name: "HHS Press Releases", url: "https://www.hhs.gov/rss/news/press-releases.xml", region: "US", type: "rss", category: "government" },
    { name: "Israel Privacy Authority (PPA)", url: "https://www.gov.il/he/departments/israel_privacy_authority/govil-landing-page", region: "Israel", type: "scrape", category: "government" },
    { name: "Israel Competition Authority", url: "https://www.gov.il/he/departments/competition/govil-landing-page", region: "Israel", type: "scrape", category: "government" },
    { name: "Israel Securities Authority (ISA)", url: "https://www.isa.gov.il/sites/ISAEng/Pages/default.aspx", region: "Israel", type: "scrape", category: "government" },
    { name: "Israel National Cyber Directorate", url: "https://www.gov.il/en/departments/israel_national_cyber_directorate/govil-landing-page", region: "Israel", type: "scrape", category: "government" }
  ],
  legal_news: [
    { name: "Law360 Tech", url: "https://www.law360.com/rss/technology", region: "US", type: "rss", category: "legal_news" },
    { name: "Law360 Pulse Legal Tech", url: "https://www.law360.com/pulse/legal-tech/rss", region: "US", type: "rss", category: "legal_news" },
    { name: "Reuters Legal", url: "https://www.reuters.com/legal/legalindustry/rss", region: "Global", type: "rss", category: "legal_news" },
    { name: "Bloomberg Law", url: "https://news.bloomberglaw.com/rss", region: "US", type: "rss", category: "legal_news" },
    { name: "JD Supra Privacy", url: "https://www.jdsupra.com/resources/syndication/privacy-law.aspx", region: "US", type: "rss", category: "legal_news" },
    { name: "Lexology", url: "https://www.lexology.com/rss/feed.ashx", region: "Global", type: "rss", category: "legal_news" },
    { name: "The National Law Review", url: "https://www.natlawreview.com/rss.xml", region: "US", type: "rss", category: "legal_news" },
    { name: "Globes Legal (Israel)", url: "https://www.globes.co.il/news/rss/rss.law.xml", region: "Israel", type: "rss", category: "legal_news" },
    { name: "Calcalist Tech & Law", url: "https://www.calcalist.co.il/internet/home/0,7340,L-4789,00.html", region: "Israel", type: "scrape", category: "legal_news" },
    { name: "Pearl Cohen Tech Law Blog", url: "https://www.pearlcohen.com/insights/", region: "Israel", type: "scrape", category: "legal_news" },
    { name: "Herzog Fox & Neeman Tech", url: "https://www.herzoglaw.co.il/eng/insights/", region: "Israel", type: "scrape", category: "legal_news" },
    { name: "Barnea Jaffa Lande Tech Law", url: "https://www.barlaw.co.il/publications/", region: "Israel", type: "scrape", category: "legal_news" }
  ],
  industry: [

    { name: "TechCrunch Policy", url: "https://techcrunch.com/tag/policy/feed/", region: "Global", type: "rss", category: "industry" },
    { name: "Wired Security", url: "https://www.wired.com/feed/category/security/latest/rss", region: "Global", type: "rss", category: "industry" },
    { name: "Krebs on Security", url: "https://krebsonsecurity.com/feed/", region: "Global", type: "rss", category: "industry" },
    { name: "Dark Reading", url: "https://www.darkreading.com/rss_simple.asp", region: "Global", type: "rss", category: "industry" },
    { name: "Finextra Regtech", url: "https://www.finextra.com/rss/rss.aspx?channel=regtech", region: "Global", type: "rss", category: "industry" },
    { name: "Geektime Israel Tech", url: "https://www.geektime.co.il/feed/", region: "Israel", type: "rss", category: "industry" },
    { name: "CTech by Calcalist", url: "https://www.calcalistech.com/", region: "Israel", type: "scrape", category: "industry" },
    { name: "Start-Up Nation Central", url: "https://www.startupnationcentral.org/news/", region: "Israel", type: "scrape", category: "industry" },
    { name: "Israel Innovation Authority", url: "https://innovationisrael.org.il/en/news", region: "Israel", type: "scrape", category: "industry" }
  ],
  court: [
    { name: "PACER RSS", url: "https://ecf.cand.uscourts.gov/cgi-bin/rss_outside.pl", region: "US", type: "rss", category: "court" },
    { name: "SCOTUSblog", url: "https://www.scotusblog.com/feed/", region: "US", type: "rss", category: "court" },
    { name: "CJEU Press Releases", url: "https://curia.europa.eu/jcms/jcms/Jo2_16799", region: "EU", type: "scrape", category: "court" },
    { name: "UK Supreme Court", url: "https://www.supremecourt.uk/rss/news.xml", region: "UK", type: "rss", category: "court" },
    { name: "Israel Supreme Court Rulings", url: "https://supremecourt.gov.il/Pages/default.aspx", region: "Israel", type: "scrape", category: "court" },
    { name: "Israel District Courts - Tech Cases", url: "https://www.court.gov.il/NGCS.Web.Site/HomePage.aspx", region: "Israel", type: "scrape", category: "court" }
  ],
  enforcement: [
    { name: "OCC Enforcement Actions", url: "https://www.occ.treas.gov/news-issuances/news-releases/rss/index.html", region: "US", type: "rss", category: "enforcement" },
    { name: "CFPB Enforcement", url: "https://www.consumerfinance.gov/about-us/newsroom/rss/", region: "US", type: "rss", category: "enforcement" },
    { name: "NY AG Press Releases", url: "https://ag.ny.gov/press-releases/feed", region: "US", type: "rss", category: "enforcement" },
    { name: "CA AG News", url: "https://oag.ca.gov/news/feed", region: "US", type: "rss", category: "enforcement" },
    { name: "FCA UK Enforcement", url: "https://www.fca.org.uk/news/rss.xml", region: "UK", type: "rss", category: "enforcement" },
    { name: "FINRA News & Events", url: "http://feeds.finra.org/news-and-events/feed", region: "US", type: "rss", category: "enforcement" },
    { name: "Israel Consumer Protection Authority", url: "https://www.gov.il/he/departments/consumer_protection_and_fair_trade_authority/govil-landing-page", region: "Israel", type: "scrape", category: "enforcement" },
    { name: "Israel Antitrust Authority Decisions", url: "https://www.gov.il/he/departments/competition/govil-landing-page", region: "Israel", type: "scrape", category: "enforcement" },
    { name: "Israel PPA Enforcement Actions", url: "https://www.gov.il/he/departments/policies/database_registration_conditions", region: "Israel", type: "scrape", category: "enforcement" }
  ]
};

const CATEGORY_CONFIG = {
  government: { icon: Building2, label: "Government Agencies", color: "text-blue-600" },
  legal_news: { icon: Newspaper, label: "Legal News", color: "text-violet-600" },
  industry: { icon: Globe, label: "Industry Publications", color: "text-emerald-600" },
  court: { icon: Scale, label: "Court Databases", color: "text-amber-600" },
  enforcement: { icon: Shield, label: "Enforcement Agencies", color: "text-red-600" }
};

export default function SourceLibrary({ existingSources = [], onSourcesAdded }) {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [selectedSources, setSelectedSources] = useState([]);
  const [activeCategory, setActiveCategory] = useState("government");

  const existingUrls = existingSources.map(s => s.url?.toLowerCase());

  const createMutation = useMutation({
    mutationFn: async (sources) => {
      return base44.entities.ComplianceSource.bulkCreate(sources);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['compliance-sources'] });
      toast.success(`Added ${selectedSources.length} sources`);
      setOpen(false);
      setSelectedSources([]);
      onSourcesAdded?.();
    },
    onError: (error) => {
      toast.error("Failed to add sources: " + error.message);
    }
  });

  const [validationErrors, setValidationErrors] = useState({});
  
  const validateSourceUrl = async (source) => {
    try {
      const parsed = new URL(source.url);
      if (!['http:', 'https:'].includes(parsed.protocol)) {
        return { valid: false, error: "Invalid URL protocol" };
      }
      return { valid: true };
    } catch {
      return { valid: false, error: "Invalid URL format" };
    }
  };

  const toggleSource = async (source) => {
    const key = source.url;
    const isCurrentlySelected = selectedSources.find(s => s.url === key);
    
    if (!isCurrentlySelected) {
      // Validate URL before selecting
      const validation = await validateSourceUrl(source);
      if (!validation.valid) {
        setValidationErrors(prev => ({ ...prev, [key]: validation.error }));
        toast.error(`Cannot add "${source.name}": ${validation.error}`);
        return;
      }
      setValidationErrors(prev => {
        const copy = { ...prev };
        delete copy[key];
        return copy;
      });
    }
    
    setSelectedSources(prev => 
      isCurrentlySelected 
        ? prev.filter(s => s.url !== key)
        : [...prev, source]
    );
  };

  const isSelected = (source) => selectedSources.find(s => s.url === source.url);
  const isExisting = (source) => existingUrls.includes(source.url?.toLowerCase());
  const hasError = (source) => validationErrors[source.url];

  const filteredSources = SOURCE_LIBRARY[activeCategory]?.filter(s => 
    s.name.toLowerCase().includes(search.toLowerCase())
  ) || [];

  const handleAddSelected = () => {
    if (selectedSources.length === 0) return;
    
    // Validate all selected sources before adding
    const invalidSources = selectedSources.filter(s => {
      try {
        const url = new URL(s.url);
        return !['http:', 'https:'].includes(url.protocol);
      } catch {
        return true;
      }
    });
    
    if (invalidSources.length > 0) {
      toast.error(`${invalidSources.length} source(s) have invalid URLs`);
      return;
    }
    
    createMutation.mutate(selectedSources.map(s => ({ ...s, is_active: true })));
  };
  
  // Reset state when dialog closes
  const handleOpenChange = (newOpen) => {
    setOpen(newOpen);
    if (!newOpen) {
      setSelectedSources([]);
      setValidationErrors({});
      setSearch("");
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Library className="h-4 w-4" />
          Source Library
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Library className="h-5 w-5 text-blue-600" />
            Compliance Source Library
          </DialogTitle>
        </DialogHeader>

        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input
            placeholder="Search sources..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>

        <Tabs value={activeCategory} onValueChange={setActiveCategory}>
          <TabsList className="grid grid-cols-5 w-full">
            {Object.entries(CATEGORY_CONFIG).map(([key, config]) => {
              const Icon = config.icon;
              return (
                <TabsTrigger key={key} value={key} className="text-xs gap-1">
                  <Icon className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">{config.label.split(' ')[0]}</span>
                </TabsTrigger>
              );
            })}
          </TabsList>

          <ScrollArea className="h-[350px] mt-4">
            {Object.entries(SOURCE_LIBRARY).map(([category, sources]) => (
              <TabsContent key={category} value={category} className="mt-0 space-y-2">
                {filteredSources.length === 0 ? (
                  <p className="text-center text-slate-500 py-8">No sources found</p>
                ) : (
                  filteredSources.map((source, i) => {
                    const existing = isExisting(source);
                    const selected = isSelected(source);
                    const error = hasError(source);
                    return (
                      <Card 
                        key={i}
                        className={`p-3 cursor-pointer transition-all ${
                          existing ? 'opacity-50 cursor-not-allowed bg-slate-50' :
                          error ? 'border-red-300 bg-red-50' :
                          selected ? 'border-blue-500 bg-blue-50' : 'hover:border-slate-300'
                        }`}
                        onClick={() => !existing && toggleSource(source)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="font-medium text-slate-900">{source.name}</span>
                              <Badge variant="outline" className="text-xs">{source.region}</Badge>
                              <Badge variant="secondary" className="text-xs">{source.type}</Badge>
                            </div>
                            <p className="text-xs text-slate-500 truncate mt-1">{source.url}</p>
                            {error && (
                              <p className="text-xs text-red-600 mt-1">{error}</p>
                            )}
                          </div>
                          {existing ? (
                            <Badge className="bg-slate-100 text-slate-600">Already Added</Badge>
                          ) : selected ? (
                            <CheckCircle2 className="h-5 w-5 text-blue-600" />
                          ) : (
                            <Plus className="h-5 w-5 text-slate-400" />
                          )}
                        </div>
                      </Card>
                    );
                  })
                )}
              </TabsContent>
            ))}
          </ScrollArea>
        </Tabs>

        <div className="flex items-center justify-between pt-4 border-t">
          <span className="text-sm text-slate-500">
            {selectedSources.length} source{selectedSources.length !== 1 ? 's' : ''} selected
          </span>
          <div className="flex gap-3">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button 
              onClick={handleAddSelected}
              disabled={selectedSources.length === 0 || createMutation.isPending}
            >
              {createMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Add Selected
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}