import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Calendar, FileText } from "lucide-react";
import { format } from "date-fns";

export default function SourceItemsModal({ sourceName, open, onClose }) {
  const { data: updates = [], isLoading } = useQuery({
    queryKey: ['source-updates', sourceName],
    queryFn: async () => {
      if (!sourceName) return [];
      // Filter updates by source name, sort by publish date desc
      // Try exact match first
      let items = await base44.entities.RegulatoryUpdate.filter({ source: sourceName });
      
      // If no items found, try searching by title-cased or simplified version as fallback
      if (items.length === 0) {
        // This is a client-side fallback since we can't do complex OR queries easily
        // We'll fetch recent updates and filter manually if the direct lookup failed
        // This helps if there was a historical mismatch in source names
        try {
          const recentUpdates = await base44.entities.RegulatoryUpdate.list('-created_date', 100);
          const looseMatches = recentUpdates.filter(u => 
            u.source?.toLowerCase().includes(sourceName.toLowerCase()) || 
            sourceName.toLowerCase().includes(u.source?.toLowerCase())
          );
          if (looseMatches.length > 0) items = looseMatches;
        } catch (e) {
          console.warn("Fallback search failed", e);
        }
      }
      
      return items.sort((a, b) => new Date(b.publish_date || 0) - new Date(a.publish_date || 0));
    },
    enabled: !!sourceName && open
  });

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-blue-600" />
            Fetched Items from "{sourceName}"
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 min-h-0 mt-4">
          {isLoading ? (
            <div className="space-y-3">
              {Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-24 rounded-lg" />)}
            </div>
          ) : updates.length === 0 ? (
            <div className="text-center py-12 text-slate-500">
              <p>No items found from this source.</p>
            </div>
          ) : (
            <ScrollArea className="h-[500px] pr-4">
              <div className="space-y-3">
                {updates.map(update => (
                  <div key={update.id} className="p-4 rounded-lg border bg-slate-50 hover:bg-white hover:shadow-sm transition-all">
                    <div className="flex justify-between items-start gap-4">
                      <div className="space-y-1">
                        <h4 className="font-medium text-slate-900 leading-snug">{update.title}</h4>
                        <div className="flex items-center gap-2 text-xs text-slate-500">
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {update.publish_date ? format(new Date(update.publish_date), "MMM d, yyyy") : "No date"}
                          </span>
                          <span>•</span>
                          <Badge variant="outline" className="text-[10px] h-5 px-1.5">
                            {update.risk_score} Risk
                          </Badge>
                          <span>•</span>
                          <span className="truncate max-w-[200px]">{update.domain}</span>
                        </div>
                        {update.summary && (
                          <p className="text-sm text-slate-600 line-clamp-2 mt-1.5">
                            {update.summary}
                          </p>
                        )}
                      </div>
                      {update.source_url && (
                        <a 
                          href={update.source_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:text-blue-800 p-1"
                        >
                          <ExternalLink className="h-4 w-4" />
                        </a>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          )}
        </div>
        
        <div className="pt-4 border-t text-xs text-slate-500 flex justify-between">
            <span>Total items: {updates.length}</span>
        </div>
      </DialogContent>
    </Dialog>
  );
}