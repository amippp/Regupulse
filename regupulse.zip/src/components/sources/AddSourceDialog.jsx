import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Plus, Rss, Globe, Zap, Loader2 } from "lucide-react";
import { toast } from "sonner";

const REGIONS = ["US", "EU", "UK", "Global", "Israel", "Germany", "Canada", "Australia", "Brazil", "China", "India"];
const CATEGORIES = [
  { value: "government", label: "Government Agency" },
  { value: "legal_news", label: "Legal News" },
  { value: "industry", label: "Industry Publication" },
  { value: "court", label: "Court Database" },
  { value: "enforcement", label: "Enforcement Agency" },
  { value: "custom", label: "Custom Source" }
];

export default function AddSourceDialog({ onSourceAdded }) {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [sourceType, setSourceType] = useState("rss");
  const [formData, setFormData] = useState({
    name: "",
    url: "",
    region: "US",
    category: "custom",
    scrape_selector: "",
    is_active: true,
    api_config: {
      method: "GET",
      auth_type: "none",
      data_path: ""
    }
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.ComplianceSource.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['compliance-sources'] });
      toast.success("Source added successfully");
      setOpen(false);
      resetForm();
      onSourceAdded?.();
    },
    onError: (error) => {
      toast.error("Failed to add source: " + error.message);
    }
  });

  const resetForm = () => {
    setFormData({
      name: "",
      url: "",
      region: "US",
      category: "custom",
      scrape_selector: "",
      is_active: true,
      api_config: { method: "GET", auth_type: "none", data_path: "" }
    });
    setSourceType("rss");
  };

  const validateUrl = (url, type) => {
    try {
      const parsed = new URL(url);
      if (!['http:', 'https:'].includes(parsed.protocol)) {
        return { valid: false, error: "URL must start with http:// or https://" };
      }
      // For RSS feeds, check if it looks like a valid feed URL
      if (type === "rss") {
        const feedPatterns = ['.xml', '.rss', '/feed', '/rss', 'feed.', 'rss.'];
        const looksLikeFeed = feedPatterns.some(p => url.toLowerCase().includes(p));
        if (!looksLikeFeed) {
          return { valid: true, warning: "This URL doesn't look like a typical RSS feed. Make sure it returns valid XML." };
        }
      }
      return { valid: true };
    } catch {
      return { valid: false, error: "Please enter a valid URL" };
    }
  };

  const [urlValidation, setUrlValidation] = useState({ valid: true });
  
  const handleUrlChange = (url) => {
    setFormData(prev => ({ ...prev, url }));
    if (url) {
      setUrlValidation(validateUrl(url, sourceType));
    } else {
      setUrlValidation({ valid: true });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.url) {
      toast.error("Name and URL are required");
      return;
    }
    
    const validation = validateUrl(formData.url, sourceType);
    if (!validation.valid) {
      toast.error(validation.error);
      return;
    }
    
    if (validation.warning) {
      // Show warning but allow submission
      toast.warning(validation.warning);
    }

    const sourceData = {
      ...formData,
      type: sourceType,
      api_config: sourceType === "api" ? formData.api_config : undefined,
      scrape_selector: sourceType === "scrape" ? formData.scrape_selector : undefined
    };

    createMutation.mutate(sourceData);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          Add Source
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Add Compliance Data Source</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <Tabs value={sourceType} onValueChange={setSourceType}>
            <TabsList className="grid grid-cols-3 w-full">
              <TabsTrigger value="rss" className="gap-1.5">
                <Rss className="h-3.5 w-3.5" />
                RSS Feed
              </TabsTrigger>
              <TabsTrigger value="scrape" className="gap-1.5">
                <Globe className="h-3.5 w-3.5" />
                Web Scrape
              </TabsTrigger>
              <TabsTrigger value="api" className="gap-1.5">
                <Zap className="h-3.5 w-3.5" />
                API
              </TabsTrigger>
            </TabsList>

            <div className="mt-4 space-y-4">
              {/* Common fields */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Source Name *</Label>
                  <Input
                    id="name"
                    placeholder="e.g., SEC Press Releases"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="region">Region</Label>
                  <Select 
                    value={formData.region} 
                    onValueChange={(v) => setFormData(prev => ({ ...prev, region: v }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {REGIONS.map(r => (
                        <SelectItem key={r} value={r}>{r}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="url">URL *</Label>
                <Input
                  id="url"
                  placeholder={sourceType === "rss" ? "https://example.com/feed.xml" : "https://example.com/news"}
                  value={formData.url}
                  onChange={(e) => handleUrlChange(e.target.value)}
                  className={!urlValidation.valid ? "border-red-500" : urlValidation.warning ? "border-amber-500" : ""}
                />
                {!urlValidation.valid && (
                  <p className="text-xs text-red-500">{urlValidation.error}</p>
                )}
                {urlValidation.warning && (
                  <p className="text-xs text-amber-600">{urlValidation.warning}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Select 
                  value={formData.category} 
                  onValueChange={(v) => setFormData(prev => ({ ...prev, category: v }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map(c => (
                      <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Scrape-specific fields */}
              <TabsContent value="scrape" className="mt-0 space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="selector">CSS Selector (Optional)</Label>
                  <Input
                    id="selector"
                    placeholder="e.g., article.news-item a"
                    value={formData.scrape_selector}
                    onChange={(e) => setFormData(prev => ({ ...prev, scrape_selector: e.target.value }))}
                  />
                  <p className="text-xs text-slate-500">CSS selector to extract article links from the page</p>
                </div>
              </TabsContent>

              {/* API-specific fields */}
              <TabsContent value="api" className="mt-0 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>HTTP Method</Label>
                    <Select 
                      value={formData.api_config.method} 
                      onValueChange={(v) => setFormData(prev => ({ 
                        ...prev, 
                        api_config: { ...prev.api_config, method: v } 
                      }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="GET">GET</SelectItem>
                        <SelectItem value="POST">POST</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Authentication</Label>
                    <Select 
                      value={formData.api_config.auth_type} 
                      onValueChange={(v) => setFormData(prev => ({ 
                        ...prev, 
                        api_config: { ...prev.api_config, auth_type: v } 
                      }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        <SelectItem value="api_key">API Key</SelectItem>
                        <SelectItem value="bearer">Bearer Token</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="data_path">Data Path</Label>
                  <Input
                    id="data_path"
                    placeholder="e.g., data.articles or results"
                    value={formData.api_config.data_path}
                    onChange={(e) => setFormData(prev => ({ 
                      ...prev, 
                      api_config: { ...prev.api_config, data_path: e.target.value } 
                    }))}
                  />
                  <p className="text-xs text-slate-500">JSON path to the articles array in the API response</p>
                </div>
              </TabsContent>

              {/* Active toggle */}
              <div className="flex items-center justify-between pt-2">
                <div>
                  <Label>Active</Label>
                  <p className="text-xs text-slate-500">Include this source in compliance scans</p>
                </div>
                <Switch
                  checked={formData.is_active}
                  onCheckedChange={(v) => setFormData(prev => ({ ...prev, is_active: v }))}
                />
              </div>
            </div>
          </Tabs>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={createMutation.isPending}>
              {createMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Add Source
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}