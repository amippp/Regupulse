import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Mail, FileText, Download } from "lucide-react";
import { format } from "date-fns";

export default function BriefingViewDialog({ briefing, open, onClose }) {
  if (!briefing) return null;

  const handleDownload = () => {
    const blob = new Blob([briefing.content], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${briefing.title.replace(/\s+/g, '_')}.html`;
    document.body.appendChild(a);
    a.click();
    URL.revokeObjectURL(url);
    a.remove();
  };

  const frequencyColors = {
    daily: "bg-blue-100 text-blue-700",
    weekly: "bg-violet-100 text-violet-700",
    monthly: "bg-amber-100 text-amber-700"
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-3 mb-2">
            <Badge className={frequencyColors[briefing.frequency]}>{briefing.frequency}</Badge>
            {briefing.status === "sent" && (
              <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200">
                <Mail className="h-3 w-3 mr-1" /> Sent
              </Badge>
            )}
          </div>
          <DialogTitle className="text-xl">{briefing.title}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 mt-4">
          {/* Meta Info */}
          <div className="flex flex-wrap items-center gap-4 text-sm text-slate-600 pb-4 border-b">
            <span className="flex items-center gap-1.5">
              <Calendar className="h-4 w-4" />
              {format(new Date(briefing.created_date), "MMMM d, yyyy 'at' h:mm a")}
            </span>
            <span className="flex items-center gap-1.5">
              <FileText className="h-4 w-4" />
              {briefing.updates_count || 0} updates included
            </span>
            {briefing.period_start && briefing.period_end && (
              <span>
                Period: {format(new Date(briefing.period_start), "MMM d")} - {format(new Date(briefing.period_end), "MMM d, yyyy")}
              </span>
            )}
          </div>

          {/* Domains & Risk Levels */}
          <div className="flex flex-wrap gap-2">
            {briefing.domains?.map(d => (
              <Badge key={d} variant="outline">{d}</Badge>
            ))}
            {briefing.risk_levels?.map(r => (
              <Badge key={r} variant="outline" className="bg-red-50 text-red-700 border-red-200">
                {r} Risk
              </Badge>
            ))}
          </div>

          {/* Executive Summary */}
          {briefing.summary && (
            <div className="bg-slate-50 rounded-lg p-4">
              <h4 className="font-semibold text-slate-900 mb-2">Executive Summary</h4>
              <p className="text-slate-700 text-sm leading-relaxed">{briefing.summary}</p>
            </div>
          )}

          {/* Recipients */}
          {briefing.sent_to?.length > 0 && (
            <div>
              <h4 className="font-semibold text-slate-900 mb-2">Sent To</h4>
              <div className="flex flex-wrap gap-2">
                {briefing.sent_to.map(email => (
                  <Badge key={email} variant="secondary">{email}</Badge>
                ))}
              </div>
            </div>
          )}

          {/* Full Content */}
          <div className="border rounded-lg p-4 bg-white">
            <div 
              className="prose prose-sm max-w-none"
              dangerouslySetInnerHTML={{ __html: briefing.content }}
            />
          </div>

          {/* Download Button */}
          <div className="flex justify-end pt-4 border-t">
            <Button variant="outline" onClick={handleDownload} className="gap-2">
              <Download className="h-4 w-4" />
              Download HTML
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}