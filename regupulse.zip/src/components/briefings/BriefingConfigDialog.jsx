import { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { X, Plus, Loader2 } from "lucide-react";

const DOMAINS = ["AI Law", "Privacy", "Antitrust", "Consumer Protection", "Platform Liability", "IP"];
const RISK_LEVELS = ["High", "Medium", "Low"];
const JURISDICTIONS = ["United States", "European Union", "United Kingdom", "Israel", "Global", "Germany", "Canada", "Australia"];

export default function BriefingConfigDialog({ open, onClose, config }) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    name: "",
    frequency: "weekly",
    domains: [],
    risk_levels: ["High", "Medium"],
    jurisdictions: [],
    recipients: [],
    include_executive_summary: true,
    include_action_items: true,
    is_active: true
  });
  const [newRecipient, setNewRecipient] = useState("");

  useEffect(() => {
    if (config) {
      setFormData({
        name: config.name || "",
        frequency: config.frequency || "weekly",
        domains: config.domains || [],
        risk_levels: config.risk_levels || ["High", "Medium"],
        jurisdictions: config.jurisdictions || [],
        recipients: config.recipients || [],
        include_executive_summary: config.include_executive_summary ?? true,
        include_action_items: config.include_action_items ?? true,
        is_active: config.is_active ?? true
      });
    } else {
      setFormData({
        name: "",
        frequency: "weekly",
        domains: [],
        risk_levels: ["High", "Medium"],
        jurisdictions: [],
        recipients: [],
        include_executive_summary: true,
        include_action_items: true,
        is_active: true
      });
    }
  }, [config, open]);

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      if (config) {
        return base44.entities.BriefingConfig.update(config.id, data);
      }
      return base44.entities.BriefingConfig.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['briefing-configs'] });
      onClose();
    }
  });

  const toggleArrayItem = (field, item) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].includes(item)
        ? prev[field].filter(i => i !== item)
        : [...prev[field], item]
    }));
  };

  const addRecipient = () => {
    if (newRecipient && newRecipient.includes("@") && !formData.recipients.includes(newRecipient)) {
      setFormData(prev => ({
        ...prev,
        recipients: [...prev.recipients, newRecipient]
      }));
      setNewRecipient("");
    }
  };

  const removeRecipient = (email) => {
    setFormData(prev => ({
      ...prev,
      recipients: prev.recipients.filter(r => r !== email)
    }));
  };

  const handleSave = () => {
    if (!formData.name || formData.domains.length === 0 || formData.recipients.length === 0) {
      return;
    }
    saveMutation.mutate(formData);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{config ? "Edit Briefing Configuration" : "New Briefing Configuration"}</DialogTitle>
        </DialogHeader>

        <div className="space-y-5 py-4">
          {/* Name */}
          <div className="space-y-2">
            <Label>Configuration Name *</Label>
            <Input
              placeholder="e.g., Weekly AI & Privacy Briefing"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            />
          </div>

          {/* Frequency */}
          <div className="space-y-2">
            <Label>Frequency *</Label>
            <Select value={formData.frequency} onValueChange={(v) => setFormData({ ...formData, frequency: v })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">Daily</SelectItem>
                <SelectItem value="weekly">Weekly</SelectItem>
                <SelectItem value="monthly">Monthly</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Domains */}
          <div className="space-y-2">
            <Label>Legal Domains *</Label>
            <div className="flex flex-wrap gap-2">
              {DOMAINS.map(domain => (
                <Badge
                  key={domain}
                  variant={formData.domains.includes(domain) ? "default" : "outline"}
                  className="cursor-pointer"
                  onClick={() => toggleArrayItem("domains", domain)}
                >
                  {domain}
                </Badge>
              ))}
            </div>
          </div>

          {/* Risk Levels */}
          <div className="space-y-2">
            <Label>Risk Levels *</Label>
            <div className="flex gap-4">
              {RISK_LEVELS.map(level => (
                <div key={level} className="flex items-center gap-2">
                  <Checkbox
                    id={`risk-${level}`}
                    checked={formData.risk_levels.includes(level)}
                    onCheckedChange={() => toggleArrayItem("risk_levels", level)}
                  />
                  <label htmlFor={`risk-${level}`} className="text-sm cursor-pointer">{level}</label>
                </div>
              ))}
            </div>
          </div>

          {/* Jurisdictions */}
          <div className="space-y-2">
            <Label>Jurisdictions (optional)</Label>
            <div className="flex flex-wrap gap-2">
              {JURISDICTIONS.map(jurisdiction => (
                <Badge
                  key={jurisdiction}
                  variant={formData.jurisdictions.includes(jurisdiction) ? "default" : "outline"}
                  className="cursor-pointer text-xs"
                  onClick={() => toggleArrayItem("jurisdictions", jurisdiction)}
                >
                  {jurisdiction}
                </Badge>
              ))}
            </div>
            <p className="text-xs text-slate-500">Leave empty to include all jurisdictions</p>
          </div>

          {/* Recipients */}
          <div className="space-y-2">
            <Label>Recipients *</Label>
            <div className="flex gap-2">
              <Input
                type="email"
                placeholder="email@example.com"
                value={newRecipient}
                onChange={(e) => setNewRecipient(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addRecipient())}
              />
              <Button type="button" variant="outline" onClick={addRecipient}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            {formData.recipients.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {formData.recipients.map(email => (
                  <Badge key={email} variant="secondary" className="gap-1">
                    {email}
                    <X className="h-3 w-3 cursor-pointer" onClick={() => removeRecipient(email)} />
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Options */}
          <div className="space-y-3 pt-2 border-t">
            <div className="flex items-center justify-between">
              <Label>Include Executive Summary</Label>
              <Switch
                checked={formData.include_executive_summary}
                onCheckedChange={(v) => setFormData({ ...formData, include_executive_summary: v })}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label>Include Action Items</Label>
              <Switch
                checked={formData.include_action_items}
                onCheckedChange={(v) => setFormData({ ...formData, include_action_items: v })}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label>Active</Label>
              <Switch
                checked={formData.is_active}
                onCheckedChange={(v) => setFormData({ ...formData, is_active: v })}
              />
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button 
            onClick={handleSave} 
            disabled={saveMutation.isPending || !formData.name || formData.domains.length === 0 || formData.recipients.length === 0}
          >
            {saveMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
            {config ? "Save Changes" : "Create Configuration"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}