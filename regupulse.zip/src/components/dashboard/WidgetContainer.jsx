import { useState } from "react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { Button } from "@/components/ui/button";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Settings2, GripVertical, Calendar, AlertTriangle, TrendingUp, Radar, LayoutGrid } from "lucide-react";

import DeadlinesWidget from "./widgets/DeadlinesWidget";
import HighRiskWidget from "./widgets/HighRiskWidget";
import LegalTrendsWidget from "./widgets/LegalTrendsWidget";
import ScanStatusWidget from "./widgets/ScanStatusWidget";
import StatsWidget from "./widgets/StatsWidget";

const WIDGET_DEFINITIONS = [
  { 
    id: "stats", 
    type: "stats", 
    label: "Stats Overview", 
    icon: LayoutGrid,
    description: "Key metrics: total updates, high risk, legal events",
    component: StatsWidget,
    fullWidth: true
  },
  { 
    id: "deadlines", 
    type: "deadlines", 
    label: "Upcoming Deadlines", 
    icon: Calendar,
    description: "Key compliance deadlines from your calendar",
    component: DeadlinesWidget
  },
  { 
    id: "high-risk", 
    type: "high-risk", 
    label: "High Risk Updates", 
    icon: AlertTriangle,
    description: "Critical regulatory updates requiring attention",
    component: HighRiskWidget
  },
  { 
    id: "legal-trends", 
    type: "legal-trends", 
    label: "Legal Event Trends", 
    icon: TrendingUp,
    description: "Trends in enforcement actions and rulings",
    component: LegalTrendsWidget
  },
  { 
    id: "scan-status", 
    type: "scan-status", 
    label: "Scan Status", 
    icon: Radar,
    description: "Recent AI scan results and activity",
    component: ScanStatusWidget
  }
];

const DEFAULT_WIDGETS = WIDGET_DEFINITIONS.map((w, i) => ({
  id: w.id,
  type: w.type,
  enabled: true,
  order: i
}));

export default function WidgetContainer({ updates = [], config, onConfigChange }) {
  const [dialogOpen, setDialogOpen] = useState(false);
  
  const widgets = config?.widgets?.length > 0 ? config.widgets : DEFAULT_WIDGETS;
  
  const enabledWidgets = widgets
    .filter(w => w.enabled)
    .sort((a, b) => a.order - b.order);

  const handleDragEnd = (result) => {
    if (!result.destination) return;
    
    const items = Array.from(enabledWidgets);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);
    
    const updatedWidgets = widgets.map(w => {
      const newIndex = items.findIndex(i => i.id === w.id);
      return {
        ...w,
        order: newIndex >= 0 ? newIndex : w.order
      };
    });
    
    onConfigChange({ widgets: updatedWidgets });
  };

  const toggleWidget = (widgetId) => {
    const updatedWidgets = widgets.map(w => 
      w.id === widgetId ? { ...w, enabled: !w.enabled } : w
    );
    onConfigChange({ widgets: updatedWidgets });
  };

  const getWidgetComponent = (widget) => {
    const def = WIDGET_DEFINITIONS.find(d => d.type === widget.type);
    if (!def) return null;
    const Component = def.component;
    return <Component updates={updates} />;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-slate-900">Dashboard Widgets</h2>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm" className="gap-2">
              <Settings2 className="h-4 w-4" />
              Customize
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Customize Dashboard Widgets</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              {WIDGET_DEFINITIONS.map(def => {
                const widget = widgets.find(w => w.id === def.id);
                const Icon = def.icon;
                return (
                  <div 
                    key={def.id} 
                    className="flex items-center justify-between p-4 rounded-lg border bg-slate-50"
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-white border">
                        <Icon className="h-5 w-5 text-slate-600" />
                      </div>
                      <div>
                        <Label className="font-medium">{def.label}</Label>
                        <p className="text-xs text-slate-500">{def.description}</p>
                      </div>
                    </div>
                    <Switch 
                      checked={widget?.enabled ?? true}
                      onCheckedChange={() => toggleWidget(def.id)}
                    />
                  </div>
                );
              })}
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="widgets">
          {(provided) => (
            <div 
              {...provided.droppableProps} 
              ref={provided.innerRef}
              className="grid grid-cols-1 lg:grid-cols-2 gap-4"
            >
              {enabledWidgets.map((widget, index) => {
                const def = WIDGET_DEFINITIONS.find(d => d.type === widget.type);
                const isFullWidth = def?.fullWidth;
                return (
                  <Draggable key={widget.id} draggableId={widget.id} index={index}>
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        className={`relative group ${snapshot.isDragging ? 'z-50' : ''} ${isFullWidth ? 'lg:col-span-2' : ''}`}
                      >
                        <div 
                          {...provided.dragHandleProps}
                          className="absolute top-3 right-3 p-1.5 rounded-md bg-slate-100 opacity-0 group-hover:opacity-100 transition-opacity cursor-grab active:cursor-grabbing z-10"
                        >
                          <GripVertical className="h-4 w-4 text-slate-400" />
                        </div>
                        {getWidgetComponent(widget)}
                      </div>
                    )}
                  </Draggable>
                );
              })}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>

      {enabledWidgets.length === 0 && (
        <div className="text-center py-12 bg-slate-50 rounded-xl border-2 border-dashed">
          <Settings2 className="h-10 w-10 text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500">No widgets enabled</p>
          <Button variant="link" onClick={() => setDialogOpen(true)}>
            Add widgets to your dashboard
          </Button>
        </div>
      )}
    </div>
  );
}

export { DEFAULT_WIDGETS };