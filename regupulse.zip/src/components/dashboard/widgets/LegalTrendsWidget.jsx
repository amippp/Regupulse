import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, ArrowRight, Gavel, Scale, FileWarning, Users } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";

const legalTypes = ["Enforcement", "Ruling", "Court Filing", "Class Action"];

const typeConfig = {
  "Enforcement": { color: "#ef4444", icon: FileWarning },
  "Ruling": { color: "#8b5cf6", icon: Gavel },
  "Court Filing": { color: "#3b82f6", icon: Scale },
  "Class Action": { color: "#f59e0b", icon: Users }
};

export default function LegalTrendsWidget({ updates = [] }) {
  const legalEvents = updates.filter(u => legalTypes.includes(u.update_type));
  
  // Calculate trends by type
  const trendData = legalTypes.map(type => ({
    name: type,
    count: legalEvents.filter(e => e.update_type === type).length,
    color: typeConfig[type].color
  })).filter(d => d.count > 0);

  // Calculate trends by jurisdiction
  const jurisdictionCounts = {};
  legalEvents.forEach(event => {
    jurisdictionCounts[event.jurisdiction] = (jurisdictionCounts[event.jurisdiction] || 0) + 1;
  });
  
  const topJurisdictions = Object.entries(jurisdictionCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3);

  return (
    <Card className="p-5 h-full">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-violet-100">
            <TrendingUp className="h-4 w-4 text-violet-600" />
          </div>
          <h3 className="font-semibold text-slate-900">Legal Event Trends</h3>
        </div>
        <Link to={createPageUrl("LegalEvents")}>
          <Badge variant="outline" className="gap-1 cursor-pointer hover:bg-slate-100">
            View All <ArrowRight className="h-3 w-3" />
          </Badge>
        </Link>
      </div>

      {legalEvents.length === 0 ? (
        <div className="text-center py-8">
          <Gavel className="h-8 w-8 text-slate-300 mx-auto mb-2" />
          <p className="text-sm text-slate-500">No legal events tracked</p>
        </div>
      ) : (
        <div className="space-y-4">
          {/* Mini Chart */}
          <div className="h-32">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={trendData} layout="vertical" margin={{ left: 0, right: 10 }}>
                <XAxis type="number" hide />
                <YAxis 
                  type="category" 
                  dataKey="name" 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 11, fill: '#64748b' }}
                  width={80}
                />
                <Tooltip 
                  formatter={(value) => [`${value} events`, '']}
                  contentStyle={{ 
                    background: 'white', 
                    border: '1px solid #e2e8f0',
                    borderRadius: '8px',
                    fontSize: '12px'
                  }}
                />
                <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                  {trendData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Top Jurisdictions */}
          <div className="pt-3 border-t">
            <p className="text-xs font-medium text-slate-500 mb-2">Top Jurisdictions</p>
            <div className="flex flex-wrap gap-2">
              {topJurisdictions.map(([jurisdiction, count]) => (
                <Badge 
                  key={jurisdiction} 
                  variant="outline"
                  className="bg-slate-50"
                >
                  {jurisdiction} <span className="ml-1 text-slate-400">({count})</span>
                </Badge>
              ))}
            </div>
          </div>

          {/* Summary Stats */}
          <div className="grid grid-cols-2 gap-3 pt-3 border-t">
            <div className="text-center p-2 rounded-lg bg-slate-50">
              <p className="text-2xl font-bold text-slate-900">{legalEvents.length}</p>
              <p className="text-xs text-slate-500">Total Events</p>
            </div>
            <div className="text-center p-2 rounded-lg bg-slate-50">
              <p className="text-2xl font-bold text-slate-900">{Object.keys(jurisdictionCounts).length}</p>
              <p className="text-xs text-slate-500">Jurisdictions</p>
            </div>
          </div>
        </div>
      )}
    </Card>
  );
}