import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, ArrowRight } from "lucide-react";
import { format, differenceInDays, parseISO } from "date-fns";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function DeadlinesWidget({ updates = [] }) {
  // Extract deadlines from updates
  const deadlines = [];
  const today = new Date();

  updates.forEach(update => {
    if (update.key_dates?.length > 0) {
      update.key_dates.forEach(dateStr => {
        // Try to parse various date formats
        const dateMatch = dateStr.match(/(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})|(\w+ \d{1,2},? \d{4})|(\d{4}-\d{2}-\d{2})/);
        if (dateMatch) {
          try {
            let parsedDate;
            if (dateMatch[5]) {
              parsedDate = parseISO(dateMatch[5]);
            } else if (dateMatch[4]) {
              parsedDate = new Date(dateMatch[4]);
            } else {
              parsedDate = new Date(dateStr);
            }
            
            if (!isNaN(parsedDate) && parsedDate >= today) {
              deadlines.push({
                date: parsedDate,
                label: dateStr,
                update: update
              });
            }
          } catch (e) {
            // Skip invalid dates
          }
        }
      });
    }
  });

  // Sort by date and take top 5
  const upcomingDeadlines = deadlines
    .sort((a, b) => a.date - b.date)
    .slice(0, 5);

  const getUrgencyColor = (daysUntil) => {
    if (daysUntil <= 7) return "bg-red-100 text-red-700 border-red-200";
    if (daysUntil <= 30) return "bg-amber-100 text-amber-700 border-amber-200";
    return "bg-emerald-100 text-emerald-700 border-emerald-200";
  };

  return (
    <Card className="p-5 h-full">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-blue-100">
            <Calendar className="h-4 w-4 text-blue-600" />
          </div>
          <h3 className="font-semibold text-slate-900">Upcoming Deadlines</h3>
        </div>
        <Link to={createPageUrl("ComplianceCalendar")}>
          <Badge variant="outline" className="gap-1 cursor-pointer hover:bg-slate-100">
            View All <ArrowRight className="h-3 w-3" />
          </Badge>
        </Link>
      </div>

      {upcomingDeadlines.length === 0 ? (
        <div className="text-center py-8">
          <Clock className="h-8 w-8 text-slate-300 mx-auto mb-2" />
          <p className="text-sm text-slate-500">No upcoming deadlines</p>
        </div>
      ) : (
        <div className="space-y-3">
          {upcomingDeadlines.map((deadline, i) => {
            const daysUntil = differenceInDays(deadline.date, today);
            return (
              <div 
                key={i}
                className="flex items-start gap-3 p-3 rounded-lg bg-slate-50 hover:bg-slate-100 transition-colors"
              >
                <div className={`px-2 py-1 rounded border text-xs font-medium ${getUrgencyColor(daysUntil)}`}>
                  {daysUntil === 0 ? "Today" : daysUntil === 1 ? "Tomorrow" : `${daysUntil}d`}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-900 truncate">
                    {deadline.update.title}
                  </p>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {format(deadline.date, "MMM d, yyyy")} • {deadline.update.domain}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </Card>
  );
}