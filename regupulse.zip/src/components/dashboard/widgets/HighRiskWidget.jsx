import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, ArrowRight, Shield } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";

export default function HighRiskWidget({ updates = [] }) {
  const highRiskUpdates = updates
    .filter(u => u.risk_score === "High")
    .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
    .slice(0, 5);

  const domainColors = {
    "AI Law": "bg-violet-100 text-violet-700",
    "Privacy": "bg-emerald-100 text-emerald-700",
    "Antitrust": "bg-amber-100 text-amber-700",
    "Consumer Protection": "bg-blue-100 text-blue-700",
    "Platform Liability": "bg-red-100 text-red-700",
    "IP": "bg-pink-100 text-pink-700"
  };

  return (
    <Card className="p-5 h-full">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-red-100">
            <AlertTriangle className="h-4 w-4 text-red-600" />
          </div>
          <h3 className="font-semibold text-slate-900">High Risk Updates</h3>
          {highRiskUpdates.length > 0 && (
            <Badge className="bg-red-100 text-red-700 hover:bg-red-100">
              {highRiskUpdates.length}
            </Badge>
          )}
        </div>
        <Link to={createPageUrl("Updates") + "?risk=High"}>
          <Badge variant="outline" className="gap-1 cursor-pointer hover:bg-slate-100">
            View All <ArrowRight className="h-3 w-3" />
          </Badge>
        </Link>
      </div>

      {highRiskUpdates.length === 0 ? (
        <div className="text-center py-8">
          <Shield className="h-8 w-8 text-emerald-300 mx-auto mb-2" />
          <p className="text-sm text-slate-500">No high risk updates</p>
          <p className="text-xs text-slate-400 mt-1">Your compliance is looking good!</p>
        </div>
      ) : (
        <div className="space-y-3">
          {highRiskUpdates.map((update) => (
            <div 
              key={update.id}
              className="p-3 rounded-lg bg-red-50/50 border border-red-100 hover:bg-red-50 transition-colors"
            >
              <div className="flex items-start justify-between gap-2">
                <p className="text-sm font-medium text-slate-900 line-clamp-2">
                  {update.title}
                </p>
              </div>
              <div className="flex items-center gap-2 mt-2">
                <Badge className={`text-xs ${domainColors[update.domain] || 'bg-slate-100 text-slate-700'}`}>
                  {update.domain}
                </Badge>
                <span className="text-xs text-slate-500">
                  {update.jurisdiction}
                </span>
                <span className="text-xs text-slate-400 ml-auto">
                  {format(new Date(update.created_date), "MMM d")}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}