import { Card } from "@/components/ui/card";
import { FileText, AlertTriangle, Gavel, TrendingUp } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function StatsWidget({ updates = [] }) {
  const legalTypes = ["Enforcement", "Ruling", "Court Filing", "Class Action"];
  
  const highRiskCount = updates.filter(u => u.risk_score === "High").length;
  const legalEventsCount = updates.filter(u => legalTypes.includes(u.update_type)).length;
  
  const domains = ["AI Law", "Privacy", "Antitrust", "Consumer Protection", "Platform Liability", "IP"];
  const domainsTracked = domains.filter(d => updates.some(u => u.domain === d)).length || domains.length;

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      <Card className="p-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-blue-100">
            <FileText className="h-5 w-5 text-blue-600" />
          </div>
          <div>
            <p className="text-2xl font-bold text-slate-900">{updates.length}</p>
            <p className="text-xs text-slate-500">Total Updates</p>
          </div>
        </div>
      </Card>
      
      <Card className="p-4 bg-red-50 border-red-100">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-red-100">
            <AlertTriangle className="h-5 w-5 text-red-600" />
          </div>
          <div>
            <p className="text-2xl font-bold text-red-700">{highRiskCount}</p>
            <p className="text-xs text-red-600">High Risk</p>
          </div>
        </div>
      </Card>
      
      <Link to={createPageUrl("LegalEvents")}>
        <Card className="p-4 bg-amber-50 border-amber-100 hover:shadow-md transition-shadow cursor-pointer h-full">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-100">
              <Gavel className="h-5 w-5 text-amber-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-amber-700">{legalEventsCount}</p>
              <p className="text-xs text-amber-600">Legal Events</p>
            </div>
          </div>
        </Card>
      </Link>
      
      <Card className="p-4 bg-emerald-50 border-emerald-100">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-emerald-100">
            <TrendingUp className="h-5 w-5 text-emerald-600" />
          </div>
          <div>
            <p className="text-2xl font-bold text-emerald-700">{domainsTracked}</p>
            <p className="text-xs text-emerald-600">Domains Tracked</p>
          </div>
        </div>
      </Card>
    </div>
  );
}