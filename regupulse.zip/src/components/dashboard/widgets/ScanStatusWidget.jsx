import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Radar, ArrowRight, CheckCircle2, Clock, AlertCircle, Activity } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format, differenceInHours, differenceInDays } from "date-fns";

export default function ScanStatusWidget({ updates = [] }) {
  const now = new Date();
  
  // Calculate scan stats
  const last24h = updates.filter(u => {
    const created = new Date(u.created_date);
    return differenceInHours(now, created) <= 24;
  });

  const last7d = updates.filter(u => {
    const created = new Date(u.created_date);
    return differenceInDays(now, created) <= 7;
  });

  // Get most recent scan date
  const mostRecent = updates.length > 0 
    ? new Date(Math.max(...updates.map(u => new Date(u.created_date))))
    : null;

  const hoursSinceLastScan = mostRecent ? differenceInHours(now, mostRecent) : null;

  // Determine scan health status
  const getScanHealth = () => {
    if (!mostRecent) return { status: "none", color: "text-slate-400", bg: "bg-slate-100" };
    if (hoursSinceLastScan <= 24) return { status: "healthy", color: "text-emerald-600", bg: "bg-emerald-100" };
    if (hoursSinceLastScan <= 72) return { status: "stale", color: "text-amber-600", bg: "bg-amber-100" };
    return { status: "outdated", color: "text-red-600", bg: "bg-red-100" };
  };

  const health = getScanHealth();

  // Domain breakdown from recent scans
  const domainBreakdown = {};
  last7d.forEach(u => {
    domainBreakdown[u.domain] = (domainBreakdown[u.domain] || 0) + 1;
  });

  const topDomains = Object.entries(domainBreakdown)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 4);

  return (
    <Card className="p-5 h-full">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-indigo-100">
            <Radar className="h-4 w-4 text-indigo-600" />
          </div>
          <h3 className="font-semibold text-slate-900">Scan Status</h3>
        </div>
        <Link to={createPageUrl("ScanSchedule")}>
          <Badge variant="outline" className="gap-1 cursor-pointer hover:bg-slate-100">
            Schedule <ArrowRight className="h-3 w-3" />
          </Badge>
        </Link>
      </div>

      {/* Health Status */}
      <div className={`p-4 rounded-lg ${health.bg} mb-4`}>
        <div className="flex items-center gap-3">
          {health.status === "healthy" && <CheckCircle2 className={`h-5 w-5 ${health.color}`} />}
          {health.status === "stale" && <Clock className={`h-5 w-5 ${health.color}`} />}
          {health.status === "outdated" && <AlertCircle className={`h-5 w-5 ${health.color}`} />}
          {health.status === "none" && <Activity className={`h-5 w-5 ${health.color}`} />}
          <div>
            <p className={`font-medium ${health.color}`}>
              {health.status === "healthy" && "Up to date"}
              {health.status === "stale" && "Scan recommended"}
              {health.status === "outdated" && "Scan overdue"}
              {health.status === "none" && "No scans yet"}
            </p>
            {mostRecent && (
              <p className="text-xs text-slate-600 mt-0.5">
                Last scan: {format(mostRecent, "MMM d, h:mm a")}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="p-3 rounded-lg bg-slate-50 text-center">
          <p className="text-2xl font-bold text-slate-900">{last24h.length}</p>
          <p className="text-xs text-slate-500">Last 24 Hours</p>
        </div>
        <div className="p-3 rounded-lg bg-slate-50 text-center">
          <p className="text-2xl font-bold text-slate-900">{last7d.length}</p>
          <p className="text-xs text-slate-500">Last 7 Days</p>
        </div>
      </div>

      {/* Domain Breakdown */}
      {topDomains.length > 0 && (
        <div className="pt-3 border-t">
          <p className="text-xs font-medium text-slate-500 mb-2">Recent by Domain</p>
          <div className="space-y-2">
            {topDomains.map(([domain, count]) => (
              <div key={domain} className="flex items-center justify-between">
                <span className="text-sm text-slate-700">{domain}</span>
                <Badge variant="outline" className="text-xs">{count}</Badge>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick Action */}
      <Link to={createPageUrl("Dashboard") + "?openScan=true"}>
        <div className="mt-4 p-3 rounded-lg bg-gradient-to-r from-blue-50 to-violet-50 border border-blue-100 hover:from-blue-100 hover:to-violet-100 transition-colors cursor-pointer">
          <div className="flex items-center justify-center gap-2 text-sm font-medium text-blue-700">
            <Radar className="h-4 w-4" />
            Run New Scan
          </div>
        </div>
      </Link>
    </Card>
  );
}