import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  FileText, 
  Calendar as CalendarIcon, 
  Sparkles, 
  Building2, 
  Filter, 
  Download,
  Loader2,
  CheckCircle2
} from "lucide-react";
import { format, subDays } from "date-fns";
import { cn } from "@/lib/utils";
import ComplianceReportViewer from "./ComplianceReportViewer";

const DOMAINS = ["AI Law", "Privacy", "Antitrust", "Consumer Protection", "Platform Liability", "IP"];
const RISK_LEVELS = ["High", "Medium", "Low"];
const JURISDICTIONS = ["United States", "European Union", "United Kingdom", "Israel", "Global", "Germany", "Canada", "Australia"];

const DATE_PRESETS = [
  { label: "Last 7 days", days: 7 },
  { label: "Last 14 days", days: 14 },
  { label: "Last 30 days", days: 30 },
  { label: "Last 90 days", days: 90 }
];

export default function ComplianceReportGenerator({ updates = [], triggerButton }) {
  const [open, setOpen] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [progressText, setProgressText] = useState("");
  const [generatedReport, setGeneratedReport] = useState(null);
  const [showReport, setShowReport] = useState(false);
  
  // Report configuration
  const [reportType, setReportType] = useState("period"); // "period" or "selection"
  const [selectedUpdateIds, setSelectedUpdateIds] = useState([]);
  const [dateRange, setDateRange] = useState({ from: subDays(new Date(), 14), to: new Date() });
  const [selectedDomains, setSelectedDomains] = useState([...DOMAINS]);
  const [selectedRiskLevels, setSelectedRiskLevels] = useState([...RISK_LEVELS]);
  const [selectedJurisdictions, setSelectedJurisdictions] = useState([...JURISDICTIONS]);
  const [includeExecutiveSummary, setIncludeExecutiveSummary] = useState(true);
  const [includeRiskAssessment, setIncludeRiskAssessment] = useState(true);
  const [includeActionItems, setIncludeActionItems] = useState(true);
  const [includeTrendAnalysis, setIncludeTrendAnalysis] = useState(true);
  const [customInstructions, setCustomInstructions] = useState("");

  // Fetch company profile
  const { data: companyProfiles = [] } = useQuery({
    queryKey: ['company-profile'],
    queryFn: () => base44.entities.CompanyProfile.list(),
    staleTime: 300000
  });
  const companyProfile = companyProfiles[0] || null;

  const toggleDomain = (domain) => {
    setSelectedDomains(prev => 
      prev.includes(domain) ? prev.filter(d => d !== domain) : [...prev, domain]
    );
  };

  const toggleRiskLevel = (level) => {
    setSelectedRiskLevels(prev => 
      prev.includes(level) ? prev.filter(l => l !== level) : [...prev, level]
    );
  };

  const toggleJurisdiction = (j) => {
    setSelectedJurisdictions(prev => 
      prev.includes(j) ? prev.filter(x => x !== j) : [...prev, j]
    );
  };

  const getFilteredUpdates = () => {
    return updates.filter(u => {
      if (reportType === "selection") {
        return selectedUpdateIds.includes(u.id);
      }
      
      const updateDate = new Date(u.publish_date || u.created_date);
      if (dateRange.from && updateDate < dateRange.from) return false;
      if (dateRange.to && updateDate > dateRange.to) return false;
      if (!selectedDomains.includes(u.domain)) return false;
      if (!selectedRiskLevels.includes(u.risk_score)) return false;
      if (!selectedJurisdictions.includes(u.jurisdiction)) return false;
      return true;
    });
  };

  const generateReport = async () => {
    const filteredUpdates = getFilteredUpdates();
    if (filteredUpdates.length === 0) return;

    setGenerating(true);
    setProgress(0);
    setProgressText("Preparing data...");

    try {
      // Build company context
      let companyContext = "";
      if (companyProfile) {
        companyContext = `
COMPANY CONTEXT:
- Operating Regions: ${companyProfile.operating_regions?.join(', ') || 'Not specified'}
- Key Risk Areas: ${companyProfile.key_risk_areas?.join(', ') || 'Not specified'}
- Regulatory Frameworks: ${companyProfile.regulatory_frameworks?.join(', ') || 'Not specified'}
- Data Types Processed: ${companyProfile.data_types_processed?.join(', ') || 'Not specified'}
- Uses AI/ML: ${companyProfile.uses_ai_ml ? 'Yes' : 'No'}
${companyProfile.additional_context ? `- Additional Context: ${companyProfile.additional_context}` : ''}
`;
      }

      setProgress(20);
      setProgressText("Analyzing regulatory updates...");

      // Prepare updates summary for the prompt
      const updatesSummary = filteredUpdates.map(u => `
- Title: ${u.title}
  Domain: ${u.domain} | Jurisdiction: ${u.jurisdiction} | Risk: ${u.risk_score}
  Type: ${u.update_type || 'Regulatory'}
  Summary: ${u.summary}
  ${u.compliance_actions?.length ? `Actions: ${u.compliance_actions.join('; ')}` : ''}
  ${u.is_court_decision_or_enforcement ? `Legal Event: ${u.enforcement_type || 'Yes'} | Parties: ${u.involved_parties?.join(', ') || 'N/A'}` : ''}
`).join('\n');

      setProgress(40);
      setProgressText("Generating AI analysis...");

      const sections = [];
      if (includeExecutiveSummary) sections.push("executive_summary");
      if (includeRiskAssessment) sections.push("risk_assessment");
      if (includeActionItems) sections.push("action_items");
      if (includeTrendAnalysis) sections.push("trend_analysis");

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate a comprehensive compliance report based on the following regulatory updates.
${companyContext}
${customInstructions ? `CUSTOM INSTRUCTIONS: ${customInstructions}\n` : ''}
REPORT PERIOD: ${format(dateRange.from, 'MMM d, yyyy')} - ${format(dateRange.to, 'MMM d, yyyy')}
TOTAL UPDATES: ${filteredUpdates.length}

REGULATORY UPDATES:
${updatesSummary}

Generate a professional compliance report with the following sections:
${includeExecutiveSummary ? '1. EXECUTIVE SUMMARY: A concise overview of the key regulatory developments and their overall impact on SaaS businesses.' : ''}
${includeRiskAssessment ? '2. RISK ASSESSMENT: Categorize and analyze risks by domain and jurisdiction. Highlight critical items requiring immediate attention.' : ''}
${includeActionItems ? '3. ACTION ITEMS: Specific, prioritized recommendations for compliance teams. Include deadlines where applicable.' : ''}
${includeTrendAnalysis ? '4. TREND ANALYSIS: Identify patterns across the updates. Note emerging regulatory themes and predict potential future developments.' : ''}

Make the report professional, actionable, and tailored to the company context if provided.`,
        response_json_schema: {
          type: "object",
          properties: {
            report_title: { type: "string" },
            executive_summary: { 
              type: "object",
              properties: {
                overview: { type: "string" },
                key_highlights: { type: "array", items: { type: "string" } },
                overall_risk_level: { type: "string" }
              }
            },
            risk_assessment: {
              type: "object",
              properties: {
                high_priority_items: { type: "array", items: { 
                  type: "object",
                  properties: {
                    title: { type: "string" },
                    risk_reason: { type: "string" },
                    recommended_action: { type: "string" }
                  }
                }},
                by_domain: { type: "array", items: {
                  type: "object",
                  properties: {
                    domain: { type: "string" },
                    risk_level: { type: "string" },
                    summary: { type: "string" }
                  }
                }},
                by_jurisdiction: { type: "array", items: {
                  type: "object",
                  properties: {
                    jurisdiction: { type: "string" },
                    update_count: { type: "number" },
                    key_developments: { type: "string" }
                  }
                }}
              }
            },
            action_items: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  priority: { type: "string" },
                  action: { type: "string" },
                  responsible_team: { type: "string" },
                  deadline: { type: "string" }
                }
              }
            },
            trend_analysis: {
              type: "object",
              properties: {
                emerging_themes: { type: "array", items: { type: "string" } },
                regulatory_patterns: { type: "string" },
                future_outlook: { type: "string" }
              }
            }
          }
        }
      });

      setProgress(90);
      setProgressText("Finalizing report...");

      const report = {
        ...result,
        generated_at: new Date().toISOString(),
        period: { from: dateRange.from, to: dateRange.to },
        updates_count: filteredUpdates.length,
        filters: {
          domains: selectedDomains,
          risk_levels: selectedRiskLevels,
          jurisdictions: selectedJurisdictions
        },
        included_sections: sections,
        updates: filteredUpdates
      };

      setProgress(100);
      setProgressText("Complete!");
      setGeneratedReport(report);
      
      setTimeout(() => {
        setShowReport(true);
        setOpen(false);
      }, 500);

    } catch (error) {
      console.error("Report generation failed:", error);
      setProgressText("Failed to generate report");
    } finally {
      setGenerating(false);
    }
  };

  const filteredCount = getFilteredUpdates().length;

  return (
    <>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          {triggerButton || (
            <Button className="gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700">
              <FileText className="h-4 w-4" />
              Generate Report
            </Button>
          )}
        </DialogTrigger>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-emerald-600" />
              AI Compliance Report Generator
            </DialogTitle>
          </DialogHeader>

          {generating ? (
            <div className="py-12 space-y-6">
              <div className="relative mx-auto w-16 h-16">
                <div className="absolute inset-0 rounded-full border-4 border-emerald-200"></div>
                <div className="absolute inset-0 rounded-full border-4 border-emerald-600 border-t-transparent animate-spin"></div>
                <Sparkles className="absolute inset-0 m-auto h-6 w-6 text-emerald-600" />
              </div>
              <div className="space-y-3">
                <Progress value={progress} className="h-2" />
                <p className="text-center text-sm text-slate-600">{progressText}</p>
              </div>
            </div>
          ) : (
            <Tabs defaultValue="scope" className="mt-4">
              <TabsList className="grid grid-cols-3 w-full">
                <TabsTrigger value="scope" className="gap-1.5">
                  <CalendarIcon className="h-3.5 w-3.5" />
                  Scope
                </TabsTrigger>
                <TabsTrigger value="filters" className="gap-1.5">
                  <Filter className="h-3.5 w-3.5" />
                  Filters
                </TabsTrigger>
                <TabsTrigger value="customize" className="gap-1.5">
                  <Building2 className="h-3.5 w-3.5" />
                  Customize
                </TabsTrigger>
              </TabsList>

              <TabsContent value="scope" className="space-y-4 mt-4">
                <div className="space-y-3">
                  <Label className="text-sm font-medium">Report Period</Label>
                  <div className="flex flex-wrap gap-2">
                    {DATE_PRESETS.map(preset => (
                      <Button
                        key={preset.days}
                        variant="outline"
                        size="sm"
                        onClick={() => setDateRange({ 
                          from: subDays(new Date(), preset.days), 
                          to: new Date() 
                        })}
                        className={cn(
                          "text-xs",
                          dateRange.from?.getTime() === subDays(new Date(), preset.days).setHours(0,0,0,0) && 
                          "bg-emerald-50 border-emerald-300 text-emerald-700"
                        )}
                      >
                        {preset.label}
                      </Button>
                    ))}
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" size="sm" className="gap-2">
                          <CalendarIcon className="h-3.5 w-3.5" />
                          {dateRange.from ? format(dateRange.from, 'MMM d') : 'From'}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={dateRange.from}
                          onSelect={(date) => setDateRange(prev => ({ ...prev, from: date }))}
                        />
                      </PopoverContent>
                    </Popover>
                    <span className="text-slate-400">→</span>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" size="sm" className="gap-2">
                          <CalendarIcon className="h-3.5 w-3.5" />
                          {dateRange.to ? format(dateRange.to, 'MMM d') : 'To'}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={dateRange.to}
                          onSelect={(date) => setDateRange(prev => ({ ...prev, to: date }))}
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>

                <div className="bg-slate-50 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600">Updates matching criteria:</span>
                    <span className="text-lg font-semibold text-emerald-600">{filteredCount}</span>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="filters" className="space-y-4 mt-4">
                <div className="space-y-3">
                  <Label className="text-sm font-medium">Domains</Label>
                  <div className="flex flex-wrap gap-2">
                    {DOMAINS.map(domain => (
                      <div key={domain} className="flex items-center gap-2">
                        <Checkbox
                          id={`domain-${domain}`}
                          checked={selectedDomains.includes(domain)}
                          onCheckedChange={() => toggleDomain(domain)}
                        />
                        <Label htmlFor={`domain-${domain}`} className="text-sm cursor-pointer">
                          {domain}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <Label className="text-sm font-medium">Risk Levels</Label>
                  <div className="flex flex-wrap gap-2">
                    {RISK_LEVELS.map(level => (
                      <div key={level} className="flex items-center gap-2">
                        <Checkbox
                          id={`risk-${level}`}
                          checked={selectedRiskLevels.includes(level)}
                          onCheckedChange={() => toggleRiskLevel(level)}
                        />
                        <Label htmlFor={`risk-${level}`} className="text-sm cursor-pointer">
                          {level}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <Label className="text-sm font-medium">Jurisdictions</Label>
                  <div className="flex flex-wrap gap-2 max-h-24 overflow-y-auto">
                    {JURISDICTIONS.map(j => (
                      <div key={j} className="flex items-center gap-2">
                        <Checkbox
                          id={`jur-${j}`}
                          checked={selectedJurisdictions.includes(j)}
                          onCheckedChange={() => toggleJurisdiction(j)}
                        />
                        <Label htmlFor={`jur-${j}`} className="text-sm cursor-pointer">
                          {j}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="customize" className="space-y-4 mt-4">
                <div className="space-y-3">
                  <Label className="text-sm font-medium">Report Sections</Label>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Checkbox
                        id="exec-summary"
                        checked={includeExecutiveSummary}
                        onCheckedChange={setIncludeExecutiveSummary}
                      />
                      <Label htmlFor="exec-summary" className="cursor-pointer">Executive Summary</Label>
                    </div>
                    <div className="flex items-center gap-2">
                      <Checkbox
                        id="risk-assess"
                        checked={includeRiskAssessment}
                        onCheckedChange={setIncludeRiskAssessment}
                      />
                      <Label htmlFor="risk-assess" className="cursor-pointer">Risk Assessment</Label>
                    </div>
                    <div className="flex items-center gap-2">
                      <Checkbox
                        id="action-items"
                        checked={includeActionItems}
                        onCheckedChange={setIncludeActionItems}
                      />
                      <Label htmlFor="action-items" className="cursor-pointer">Action Items</Label>
                    </div>
                    <div className="flex items-center gap-2">
                      <Checkbox
                        id="trend-analysis"
                        checked={includeTrendAnalysis}
                        onCheckedChange={setIncludeTrendAnalysis}
                      />
                      <Label htmlFor="trend-analysis" className="cursor-pointer">Trend Analysis</Label>
                    </div>
                  </div>
                </div>

                {companyProfile && (
                  <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-1">
                      <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                      <span className="text-sm font-medium text-emerald-800">Company Profile Connected</span>
                    </div>
                    <p className="text-xs text-emerald-700">
                      Report will be personalized based on your company's operating regions, risk areas, and regulatory frameworks.
                    </p>
                  </div>
                )}

                <div className="space-y-2">
                  <Label className="text-sm font-medium">Custom Instructions (Optional)</Label>
                  <Textarea
                    placeholder="Add any specific focus areas, concerns, or formatting preferences..."
                    value={customInstructions}
                    onChange={(e) => setCustomInstructions(e.target.value)}
                    className="h-20"
                  />
                </div>
              </TabsContent>
            </Tabs>
          )}

          {!generating && (
            <div className="flex justify-end gap-3 mt-6 pt-4 border-t">
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button 
                onClick={generateReport}
                disabled={filteredCount === 0}
                className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 gap-2"
              >
                <Sparkles className="h-4 w-4" />
                Generate Report ({filteredCount} updates)
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <ComplianceReportViewer 
        report={generatedReport} 
        open={showReport} 
        onClose={() => setShowReport(false)} 
      />
    </>
  );
}