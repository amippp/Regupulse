import { useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { 
  FileText, 
  Download, 
  Printer, 
  AlertTriangle, 
  CheckCircle2, 
  TrendingUp,
  Clock,
  Building2,
  Globe,
  Shield,
  Lightbulb,
  Target
} from "lucide-react";
import { format } from "date-fns";

export default function ComplianceReportViewer({ report, open, onClose }) {
  const reportRef = useRef(null);

  if (!report) return null;

  const handlePrint = () => {
    const printContent = reportRef.current?.innerHTML;
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
      <html>
        <head>
          <title>${report.report_title || 'Compliance Report'}</title>
          <style>
            body { font-family: system-ui, -apple-system, sans-serif; padding: 40px; max-width: 800px; margin: 0 auto; }
            h1 { font-size: 24px; margin-bottom: 8px; }
            h2 { font-size: 18px; margin-top: 24px; border-bottom: 2px solid #10b981; padding-bottom: 8px; }
            h3 { font-size: 14px; margin-top: 16px; }
            p { line-height: 1.6; }
            ul { padding-left: 20px; }
            li { margin-bottom: 8px; }
            .badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 12px; font-weight: 500; }
            .high { background: #fef2f2; color: #dc2626; }
            .medium { background: #fffbeb; color: #d97706; }
            .low { background: #f0fdf4; color: #16a34a; }
            .card { border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin: 12px 0; }
            .meta { color: #64748b; font-size: 14px; }
          </style>
        </head>
        <body>${printContent}</body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  };

  const getPriorityColor = (priority) => {
    switch(priority?.toLowerCase()) {
      case 'high': case 'critical': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-amber-100 text-amber-800 border-amber-200';
      default: return 'bg-green-100 text-green-800 border-green-200';
    }
  };

  const getRiskColor = (risk) => {
    switch(risk?.toLowerCase()) {
      case 'high': case 'critical': return 'text-red-600';
      case 'medium': case 'elevated': return 'text-amber-600';
      default: return 'text-green-600';
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] p-0">
        <DialogHeader className="p-6 pb-0">
          <div className="flex items-start justify-between">
            <div>
              <DialogTitle className="text-xl flex items-center gap-2">
                <FileText className="h-5 w-5 text-emerald-600" />
                {report.report_title || 'Compliance Report'}
              </DialogTitle>
              <p className="text-sm text-slate-500 mt-1">
                {format(new Date(report.period?.from), 'MMM d, yyyy')} - {format(new Date(report.period?.to), 'MMM d, yyyy')} • {report.updates_count} updates analyzed
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={handlePrint} className="gap-1.5">
                <Printer className="h-4 w-4" />
                Print
              </Button>
            </div>
          </div>
        </DialogHeader>

        <ScrollArea className="max-h-[calc(90vh-120px)]">
          <div ref={reportRef} className="p-6 space-y-6">
            
            {/* Executive Summary */}
            {report.executive_summary && (
              <section>
                <h2 className="text-lg font-semibold flex items-center gap-2 mb-4">
                  <Shield className="h-5 w-5 text-emerald-600" />
                  Executive Summary
                </h2>
                <Card className="p-4 bg-gradient-to-br from-emerald-50 to-teal-50 border-emerald-200">
                  <p className="text-slate-700 mb-4">{report.executive_summary.overview}</p>
                  
                  {report.executive_summary.overall_risk_level && (
                    <div className="flex items-center gap-2 mb-4">
                      <span className="text-sm font-medium text-slate-600">Overall Risk Level:</span>
                      <Badge className={getPriorityColor(report.executive_summary.overall_risk_level)}>
                        {report.executive_summary.overall_risk_level}
                      </Badge>
                    </div>
                  )}
                  
                  {report.executive_summary.key_highlights?.length > 0 && (
                    <div>
                      <h4 className="text-sm font-medium text-emerald-800 mb-2">Key Highlights</h4>
                      <ul className="space-y-2">
                        {report.executive_summary.key_highlights.map((highlight, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm text-slate-700">
                            <CheckCircle2 className="h-4 w-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                            <span>{highlight}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </Card>
              </section>
            )}

            {/* Risk Assessment */}
            {report.risk_assessment && (
              <section>
                <h2 className="text-lg font-semibold flex items-center gap-2 mb-4">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  Risk Assessment
                </h2>
                
                {/* High Priority Items */}
                {report.risk_assessment.high_priority_items?.length > 0 && (
                  <div className="mb-4">
                    <h3 className="text-sm font-medium text-slate-700 mb-2">High Priority Items</h3>
                    <div className="space-y-3">
                      {report.risk_assessment.high_priority_items.map((item, i) => (
                        <Card key={i} className="p-4 border-l-4 border-l-red-500">
                          <h4 className="font-medium text-slate-900 mb-1">{item.title}</h4>
                          <p className="text-sm text-slate-600 mb-2">{item.risk_reason}</p>
                          <div className="flex items-start gap-2 bg-red-50 rounded p-2">
                            <Target className="h-4 w-4 text-red-600 mt-0.5 flex-shrink-0" />
                            <span className="text-sm text-red-800">{item.recommended_action}</span>
                          </div>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}

                {/* By Domain */}
                {report.risk_assessment.by_domain?.length > 0 && (
                  <div className="mb-4">
                    <h3 className="text-sm font-medium text-slate-700 mb-2 flex items-center gap-2">
                      <Building2 className="h-4 w-4" />
                      Risk by Domain
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {report.risk_assessment.by_domain.map((item, i) => (
                        <Card key={i} className="p-3">
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-medium text-slate-900">{item.domain}</span>
                            <Badge className={getPriorityColor(item.risk_level)}>{item.risk_level}</Badge>
                          </div>
                          <p className="text-sm text-slate-600">{item.summary}</p>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}

                {/* By Jurisdiction */}
                {report.risk_assessment.by_jurisdiction?.length > 0 && (
                  <div>
                    <h3 className="text-sm font-medium text-slate-700 mb-2 flex items-center gap-2">
                      <Globe className="h-4 w-4" />
                      Risk by Jurisdiction
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {report.risk_assessment.by_jurisdiction.map((item, i) => (
                        <Card key={i} className="p-3">
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-medium text-slate-900">{item.jurisdiction}</span>
                            <Badge variant="outline">{item.update_count} updates</Badge>
                          </div>
                          <p className="text-sm text-slate-600">{item.key_developments}</p>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}
              </section>
            )}

            {/* Action Items */}
            {report.action_items?.length > 0 && (
              <section>
                <h2 className="text-lg font-semibold flex items-center gap-2 mb-4">
                  <CheckCircle2 className="h-5 w-5 text-blue-600" />
                  Action Items
                </h2>
                <div className="space-y-3">
                  {report.action_items.map((item, i) => (
                    <Card key={i} className="p-4">
                      <div className="flex items-start gap-3">
                        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-semibold text-sm">
                          {i + 1}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <Badge className={getPriorityColor(item.priority)}>{item.priority}</Badge>
                            {item.responsible_team && (
                              <Badge variant="outline">{item.responsible_team}</Badge>
                            )}
                            {item.deadline && (
                              <span className="text-xs text-slate-500 flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                {item.deadline}
                              </span>
                            )}
                          </div>
                          <p className="text-sm text-slate-700">{item.action}</p>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </section>
            )}

            {/* Trend Analysis */}
            {report.trend_analysis && (
              <section>
                <h2 className="text-lg font-semibold flex items-center gap-2 mb-4">
                  <TrendingUp className="h-5 w-5 text-violet-600" />
                  Trend Analysis
                </h2>
                <Card className="p-4 bg-gradient-to-br from-violet-50 to-indigo-50 border-violet-200">
                  {report.trend_analysis.emerging_themes?.length > 0 && (
                    <div className="mb-4">
                      <h4 className="text-sm font-medium text-violet-800 mb-2 flex items-center gap-1.5">
                        <Lightbulb className="h-4 w-4" />
                        Emerging Themes
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {report.trend_analysis.emerging_themes.map((theme, i) => (
                          <Badge key={i} variant="outline" className="bg-white border-violet-300 text-violet-700">
                            {theme}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {report.trend_analysis.regulatory_patterns && (
                    <div className="mb-4">
                      <h4 className="text-sm font-medium text-violet-800 mb-2">Regulatory Patterns</h4>
                      <p className="text-sm text-slate-700">{report.trend_analysis.regulatory_patterns}</p>
                    </div>
                  )}
                  
                  {report.trend_analysis.future_outlook && (
                    <div>
                      <h4 className="text-sm font-medium text-violet-800 mb-2">Future Outlook</h4>
                      <p className="text-sm text-slate-700">{report.trend_analysis.future_outlook}</p>
                    </div>
                  )}
                </Card>
              </section>
            )}

            {/* Report Metadata */}
            <Separator />
            <div className="text-xs text-slate-500 space-y-1">
              <p>Report generated: {format(new Date(report.generated_at), 'PPpp')}</p>
              <p>Domains: {report.filters?.domains?.join(', ')}</p>
              <p>Jurisdictions: {report.filters?.jurisdictions?.join(', ')}</p>
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}