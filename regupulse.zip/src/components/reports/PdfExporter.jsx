import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Progress } from "@/components/ui/progress";
import { FileText, Download, Sparkles, CheckCircle2, Palette } from "lucide-react";
import { format } from "date-fns";
import { jsPDF } from "jspdf";

const themes = [
  { id: "professional", name: "Professional", primary: "#1e40af", secondary: "#3b82f6", accent: "#dbeafe" },
  { id: "modern", name: "Modern Dark", primary: "#0f172a", secondary: "#6366f1", accent: "#e0e7ff" },
  { id: "elegant", name: "Elegant", primary: "#1f2937", secondary: "#10b981", accent: "#d1fae5" },
  { id: "corporate", name: "Corporate", primary: "#7c3aed", secondary: "#8b5cf6", accent: "#ede9fe" }
];

const riskColors = {
  High: { bg: "#fef2f2", text: "#dc2626", border: "#fecaca" },
  Medium: { bg: "#fffbeb", text: "#d97706", border: "#fde68a" },
  Low: { bg: "#f0fdf4", text: "#16a34a", border: "#bbf7d0" }
};

const domainColors = {
  "AI Law": "#8b5cf6",
  "Privacy": "#10b981",
  "Antitrust": "#f59e0b",
  "Consumer Protection": "#3b82f6",
  "Platform Liability": "#ef4444",
  "IP": "#ec4899"
};

export default function PdfExporter({ updates, selectedFields, open, onClose }) {
  const [generating, setGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [theme, setTheme] = useState("professional");
  const [includeHeader, setIncludeHeader] = useState(true);
  const [includeSummary, setIncludeSummary] = useState(true);
  const [includeCharts, setIncludeCharts] = useState(true);

  const selectedTheme = themes.find(t => t.id === theme);

  const generatePdf = async () => {
    setGenerating(true);
    setProgress(10);

    const doc = new jsPDF({
      orientation: "portrait",
      unit: "mm",
      format: "a4"
    });

    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 20;
    const contentWidth = pageWidth - (margin * 2);
    let y = margin;

    // Helper functions
    const addPage = () => {
      doc.addPage();
      y = margin;
    };

    const checkPageBreak = (height) => {
      if (y + height > pageHeight - 25) {
        addPage();
        return true;
      }
      return false;
    };

    const addPageFooter = (currentPage, totalPages) => {
      doc.setFontSize(9);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(120, 120, 120);
      doc.text(`Page ${currentPage} of ${totalPages}`, pageWidth / 2, pageHeight - 10, { align: "center" });
      doc.text(`Generated on ${format(new Date(), "MMMM d, yyyy 'at' h:mm a")}`, margin, pageHeight - 10);
      doc.text("ComplianceAI Report", pageWidth - margin, pageHeight - 10, { align: "right" });
    };

    // Cover page
    if (includeHeader) {
      // Background gradient effect
      doc.setFillColor(selectedTheme.primary);
      doc.rect(0, 0, pageWidth, 80, "F");
      
      // Decorative element
      doc.setFillColor(selectedTheme.secondary);
      doc.rect(0, 75, pageWidth, 8, "F");

      // Title
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(28);
      doc.setFont("helvetica", "bold");
      doc.text("Compliance Report", margin, 35);
      
      doc.setFontSize(14);
      doc.setFont("helvetica", "normal");
      doc.text("Regulatory Updates & Analysis", margin, 48);
      
      doc.setFontSize(10);
      doc.text(format(new Date(), "MMMM d, yyyy"), margin, 62);

      y = 100;
    }

    setProgress(25);

    // Executive Summary
    if (includeSummary) {
      doc.setFillColor(248, 250, 252);
      doc.roundedRect(margin, y, contentWidth, 50, 3, 3, "F");
      
      doc.setTextColor(selectedTheme.primary);
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text("Executive Summary", margin + 5, y + 10);
      
      doc.setTextColor(71, 85, 105);
      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      
      const highRisk = updates.filter(u => u.risk_score === "High").length;
      const mediumRisk = updates.filter(u => u.risk_score === "Medium").length;
      const lowRisk = updates.filter(u => u.risk_score === "Low").length;
      
      const summaryLines = [
        `This report contains ${updates.length} regulatory updates requiring attention.`,
        `Risk Distribution: ${highRisk} High Risk, ${mediumRisk} Medium Risk, ${lowRisk} Low Risk`,
        `Domains Covered: ${[...new Set(updates.map(u => u.domain))].filter(Boolean).join(", ") || "Various"}`
      ];
      
      let summaryY = y + 20;
      summaryLines.forEach(line => {
        doc.text(line, margin + 5, summaryY);
        summaryY += 7;
      });

      y += 60;
    }

    setProgress(40);

    // Risk distribution mini-chart
    if (includeCharts && updates.length > 0) {
      checkPageBreak(45);
      
      doc.setFillColor(248, 250, 252);
      doc.roundedRect(margin, y, contentWidth, 40, 3, 3, "F");
      
      doc.setTextColor(selectedTheme.primary);
      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.text("Risk Overview", margin + 5, y + 10);
      
      const riskData = [
        { label: "High", count: updates.filter(u => u.risk_score === "High").length, color: [220, 38, 38] },
        { label: "Medium", count: updates.filter(u => u.risk_score === "Medium").length, color: [217, 119, 6] },
        { label: "Low", count: updates.filter(u => u.risk_score === "Low").length, color: [22, 163, 74] }
      ];

      const total = riskData.reduce((sum, r) => sum + r.count, 0) || 1;
      let barX = margin + 5;
      const barY = y + 18;
      const barHeight = 12;
      const barMaxWidth = contentWidth - 10;

      riskData.forEach(risk => {
        const width = (risk.count / total) * barMaxWidth;
        if (width > 0) {
          doc.setFillColor(...risk.color);
          doc.roundedRect(barX, barY, width, barHeight, 2, 2, "F");
          barX += width;
        }
      });

      // Legend
      let legendX = margin + 5;
      riskData.forEach(risk => {
        doc.setFillColor(...risk.color);
        doc.circle(legendX + 3, y + 36, 2, "F");
        doc.setFontSize(8);
        doc.setTextColor(71, 85, 105);
        doc.text(`${risk.label}: ${risk.count}`, legendX + 8, y + 37);
        legendX += 45;
      });

      y += 50;
    }

    setProgress(55);

    // Updates section header
    checkPageBreak(20);
    doc.setTextColor(selectedTheme.primary);
    doc.setFontSize(16);
    doc.setFont("helvetica", "bold");
    doc.text("Regulatory Updates", margin, y + 5);
    y += 15;

    // Updates
    for (let i = 0; i < updates.length; i++) {
      const update = updates[i];
      setProgress(55 + Math.floor((i / updates.length) * 35));

      // Calculate card height
      const cardHeight = 55 + (selectedFields.includes("summary") ? 20 : 0) + 
                        (selectedFields.includes("compliance_actions") && update.compliance_actions?.length ? 25 : 0);
      
      checkPageBreak(cardHeight);

      // Card background
      const riskStyle = riskColors[update.risk_score] || riskColors.Low;
      doc.setFillColor(255, 255, 255);
      doc.setDrawColor(226, 232, 240);
      doc.roundedRect(margin, y, contentWidth, cardHeight - 5, 3, 3, "FD");

      // Risk indicator bar
      const [r, g, b] = riskStyle.text === "#dc2626" ? [220, 38, 38] : 
                        riskStyle.text === "#d97706" ? [217, 119, 6] : [22, 163, 74];
      doc.setFillColor(r, g, b);
      doc.roundedRect(margin, y, 4, cardHeight - 5, 2, 0, "F");

      // Title (clickable link if source_url exists)
      doc.setTextColor(selectedTheme.primary);
      doc.setFontSize(11);
      doc.setFont("helvetica", "bold");
      const title = update.title || "Untitled Update";
      const titleLines = doc.splitTextToSize(title, contentWidth - 15);
      const titleText = titleLines.slice(0, 2).join(" ");
      
      if (update.source_url) {
        doc.textWithLink(titleLines[0], margin + 8, y + 8, { url: update.source_url });
        if (titleLines.length > 1) {
          doc.textWithLink(titleLines[1], margin + 8, y + 13, { url: update.source_url });
        }
      } else {
        doc.text(titleLines.slice(0, 2), margin + 8, y + 8);
      }

      // Badges row
      let badgeX = margin + 8;
      let badgeY = y + (titleLines.length > 1 ? 20 : 16);

      // Domain badge
      if (selectedFields.includes("domain") && update.domain) {
        const domainColor = domainColors[update.domain] || "#6b7280";
        const [dr, dg, db] = hexToRgb(domainColor);
        doc.setFillColor(dr, dg, db, 0.1);
        doc.setTextColor(dr, dg, db);
        doc.setFontSize(7);
        const domainWidth = doc.getTextWidth(update.domain) + 6;
        doc.roundedRect(badgeX, badgeY - 4, domainWidth, 6, 1, 1, "F");
        doc.text(update.domain, badgeX + 3, badgeY);
        badgeX += domainWidth + 4;
      }

      // Jurisdiction badge
      if (selectedFields.includes("jurisdiction") && update.jurisdiction) {
        doc.setFillColor(241, 245, 249);
        doc.setTextColor(71, 85, 105);
        doc.setFontSize(7);
        const jurWidth = doc.getTextWidth(update.jurisdiction) + 6;
        doc.roundedRect(badgeX, badgeY - 4, jurWidth, 6, 1, 1, "F");
        doc.text(update.jurisdiction, badgeX + 3, badgeY);
        badgeX += jurWidth + 4;
      }

      // Risk badge
      if (selectedFields.includes("risk_score") && update.risk_score) {
        doc.setFillColor(r, g, b);
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(7);
        const riskText = `${update.risk_score} Risk`;
        const riskWidth = doc.getTextWidth(riskText) + 6;
        doc.roundedRect(badgeX, badgeY - 4, riskWidth, 6, 1, 1, "F");
        doc.text(riskText, badgeX + 3, badgeY);
      }

      // Source and date
      let infoY = badgeY + 10;
      if (selectedFields.includes("source") && update.source) {
        doc.setTextColor(100, 116, 139);
        doc.setFontSize(8);
        doc.text(`Source: ${update.source}`, margin + 8, infoY);
      }
      if (selectedFields.includes("publish_date") && update.publish_date) {
        doc.text(`Published: ${format(new Date(update.publish_date), "MMM d, yyyy")}`, margin + 80, infoY);
      }

      // Summary
      if (selectedFields.includes("summary") && update.summary) {
        infoY += 8;
        doc.setTextColor(71, 85, 105);
        doc.setFontSize(8);
        const summaryText = doc.splitTextToSize(update.summary, contentWidth - 15);
        doc.text(summaryText.slice(0, 3), margin + 8, infoY);
        infoY += Math.min(summaryText.length, 3) * 4;
      }

      // Compliance actions
      if (selectedFields.includes("compliance_actions") && update.compliance_actions?.length) {
        infoY += 4;
        doc.setTextColor(selectedTheme.primary);
        doc.setFontSize(8);
        doc.setFont("helvetica", "bold");
        doc.text("Actions Required:", margin + 8, infoY);
        doc.setFont("helvetica", "normal");
        doc.setTextColor(71, 85, 105);
        infoY += 5;
        update.compliance_actions.slice(0, 2).forEach(action => {
          doc.text(`• ${action.substring(0, 80)}${action.length > 80 ? '...' : ''}`, margin + 10, infoY);
          infoY += 4;
        });
      }

      y += cardHeight;
    }

    setProgress(95);

    // Add footer to all pages
    const totalPages = doc.internal.getNumberOfPages();
    for (let i = 1; i <= totalPages; i++) {
      doc.setPage(i);
      addPageFooter(i, totalPages);
    }

    setProgress(100);

    // Download
    doc.save(`compliance-report-${format(new Date(), "yyyy-MM-dd")}.pdf`);
    
    setTimeout(() => {
      setGenerating(false);
      setProgress(0);
      onClose();
    }, 500);
  };

  const hexToRgb = (hex) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? [
      parseInt(result[1], 16),
      parseInt(result[2], 16),
      parseInt(result[3], 16)
    ] : [107, 114, 128];
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-violet-600" />
            Export PDF Report
          </DialogTitle>
          <DialogDescription>
            Generate a professionally styled PDF report of your compliance data.
          </DialogDescription>
        </DialogHeader>

        {!generating ? (
          <div className="space-y-6 py-4">
            {/* Theme Selection */}
            <div className="space-y-3">
              <Label className="flex items-center gap-2">
                <Palette className="h-4 w-4 text-slate-500" />
                Report Theme
              </Label>
              <RadioGroup value={theme} onValueChange={setTheme} className="grid grid-cols-2 gap-3">
                {themes.map(t => (
                  <Label
                    key={t.id}
                    htmlFor={t.id}
                    className={`flex items-center gap-3 p-3 rounded-lg border-2 cursor-pointer transition-all ${
                      theme === t.id ? "border-violet-500 bg-violet-50" : "border-slate-200 hover:border-slate-300"
                    }`}
                  >
                    <RadioGroupItem value={t.id} id={t.id} className="sr-only" />
                    <div 
                      className="w-8 h-8 rounded-md shadow-sm"
                      style={{ background: `linear-gradient(135deg, ${t.primary} 0%, ${t.secondary} 100%)` }}
                    />
                    <span className="text-sm font-medium">{t.name}</span>
                  </Label>
                ))}
              </RadioGroup>
            </div>

            {/* Options */}
            <div className="space-y-4">
              <Label>Report Options</Label>
              
              <div className="flex items-center justify-between py-2">
                <div className="space-y-0.5">
                  <Label htmlFor="header" className="text-sm font-medium">Cover Header</Label>
                  <p className="text-xs text-slate-500">Include branded header with date</p>
                </div>
                <Switch id="header" checked={includeHeader} onCheckedChange={setIncludeHeader} />
              </div>
              
              <div className="flex items-center justify-between py-2">
                <div className="space-y-0.5">
                  <Label htmlFor="summary" className="text-sm font-medium">Executive Summary</Label>
                  <p className="text-xs text-slate-500">Overview of report contents</p>
                </div>
                <Switch id="summary" checked={includeSummary} onCheckedChange={setIncludeSummary} />
              </div>
              
              <div className="flex items-center justify-between py-2">
                <div className="space-y-0.5">
                  <Label htmlFor="charts" className="text-sm font-medium">Risk Chart</Label>
                  <p className="text-xs text-slate-500">Visual risk distribution</p>
                </div>
                <Switch id="charts" checked={includeCharts} onCheckedChange={setIncludeCharts} />
              </div>
            </div>

            {/* Preview info */}
            <div className="bg-gradient-to-r from-slate-50 to-violet-50 rounded-lg p-4 border">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-white shadow-sm">
                  <Sparkles className="h-5 w-5 text-violet-600" />
                </div>
                <div>
                  <p className="font-medium text-slate-900">{updates.length} updates will be exported</p>
                  <p className="text-sm text-slate-500">{selectedFields.length} fields per update</p>
                </div>
              </div>
            </div>

            <Button onClick={generatePdf} className="w-full bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700">
              <Download className="h-4 w-4 mr-2" />
              Generate PDF Report
            </Button>
          </div>
        ) : (
          <div className="py-12 space-y-6">
            <div className="relative mx-auto w-20 h-20">
              <div className="absolute inset-0 rounded-full border-4 border-violet-200"></div>
              <div className="absolute inset-0 rounded-full border-4 border-violet-600 border-t-transparent animate-spin"></div>
              {progress === 100 ? (
                <CheckCircle2 className="absolute inset-0 m-auto h-8 w-8 text-emerald-600" />
              ) : (
                <FileText className="absolute inset-0 m-auto h-8 w-8 text-violet-600" />
              )}
            </div>
            
            <div className="space-y-3">
              <Progress value={progress} className="h-2" />
              <div className="text-center">
                <p className="font-medium text-slate-900">
                  {progress < 100 ? "Generating PDF..." : "Complete!"}
                </p>
                <p className="text-sm text-slate-500 mt-1">{progress}%</p>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}