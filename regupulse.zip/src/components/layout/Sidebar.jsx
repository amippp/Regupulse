import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import {
  Shield,
  LayoutDashboard,
  FileText,
  Calendar,
  Activity,
  Settings,
  Bell,
  ChevronLeft,
  ChevronRight,
  Gavel,
  Download,
  Mail,
  Clock,
  HelpCircle,
  LogOut,
  Sparkles,
  Brain
} from "lucide-react";
import { base44 } from "@/api/base44Client";

const mainNavItems = [
  { 
    name: "Dashboard", 
    page: "Dashboard", 
    icon: LayoutDashboard,
    description: "Overview & analytics"
  },
  { 
    name: "All Updates", 
    page: "Updates", 
    icon: FileText,
    description: "Browse all regulatory updates"
  },
  { 
    name: "Legal Events", 
    page: "LegalEvents", 
    icon: Gavel,
    description: "Court decisions & enforcement"
  },
  { 
    name: "Calendar", 
    page: "ComplianceCalendar", 
    icon: Calendar,
    description: "Deadlines & key dates"
  },
  { 
    name: "Sources", 
    page: "Sources", 
    icon: Activity,
    description: "Manage RSS feeds & scrapers"
  }
];

const toolsItems = [
  { 
    name: "Briefings", 
    page: "Briefings", 
    icon: Mail,
    description: "AI-generated legal briefings"
  },
  { 
    name: "Reports", 
    page: "Reports", 
    icon: Download,
    description: "Export & generate reports"
  },
  { 
    name: "Scan Schedule", 
    page: "ScanSchedule", 
    icon: Clock,
    description: "Automated scan settings"
  },
  { 
    name: "Relevance Rules", 
    page: "RelevanceRules", 
    icon: Brain,
    description: "Manage AI filtering rules"
  },
  { 
    name: "AI Settings", 
    page: "AISettings", 
    icon: Sparkles,
    description: "Customize AI analysis"
  }
];

const bottomItems = [
  { 
    name: "Notifications", 
    page: "NotificationSettings", 
    icon: Bell,
    description: "Notification preferences"
  },
  { 
    name: "Settings", 
    page: "AppSettings", 
    icon: Settings,
    description: "App preferences"
  }
];

export default function Sidebar({ collapsed, onToggle, stats = {} }) {
  const location = useLocation();
  const currentPath = location.pathname;

  const isActive = (pageName) => {
    const pageUrl = createPageUrl(pageName);
    return currentPath === pageUrl || currentPath === pageUrl + "/";
  };

  const handleLogout = async () => {
    await base44.auth.logout();
  };

  const NavItem = ({ item, showLabel = true }) => {
    const Icon = item.icon;
    const active = isActive(item.page);
    
    const content = (
      <Link
        to={createPageUrl(item.page)}
        className={cn(
          "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 group",
          active 
            ? "bg-blue-50 text-blue-700 font-medium" 
            : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
        )}
      >
        <Icon className={cn(
          "h-5 w-5 shrink-0 transition-colors",
          active ? "text-blue-600" : "text-slate-400 group-hover:text-slate-600"
        )} />
        {showLabel && (
          <span className="text-sm truncate">{item.name}</span>
        )}
        {showLabel && item.badge && (
          <Badge className="ml-auto bg-red-100 text-red-700 hover:bg-red-100 text-xs px-1.5">
            {item.badge}
          </Badge>
        )}
      </Link>
    );

    if (!showLabel) {
      return (
        <Tooltip>
          <TooltipTrigger asChild>
            {content}
          </TooltipTrigger>
          <TooltipContent side="right" className="font-medium">
            <p>{item.name}</p>
            <p className="text-xs text-slate-400">{item.description}</p>
          </TooltipContent>
        </Tooltip>
      );
    }

    return content;
  };

  return (
    <TooltipProvider delayDuration={0}>
      <aside className={cn(
        "fixed left-0 top-0 h-full bg-white border-r border-slate-200 z-40 flex flex-col transition-all duration-300",
        collapsed ? "w-[72px]" : "w-64"
      )}>
        {/* Header */}
        <div className={cn(
          "flex items-center h-16 px-4 border-b border-slate-100",
          collapsed ? "justify-center" : "justify-between"
        )}>
          <Link to={createPageUrl("Dashboard")} className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-gradient-to-br from-blue-600 to-violet-600 shadow-lg shadow-blue-500/25">
              <Shield className="h-5 w-5 text-white" />
            </div>
            {!collapsed && (
              <div>
                <span className="font-bold text-slate-900">ComplianceAI</span>
                <span className="block text-[10px] text-slate-400 -mt-0.5">Enterprise</span>
              </div>
            )}
          </Link>
          {!collapsed && (
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8 text-slate-400 hover:text-slate-600"
              onClick={onToggle}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
          )}
        </div>

        {/* Stats Summary (collapsed mode) */}
        {collapsed && stats.highRisk > 0 && (
          <div className="px-2 mb-2">
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="bg-red-50 rounded-lg p-2 text-center">
                  <span className="text-lg font-bold text-red-600">{stats.highRisk}</span>
                </div>
              </TooltipTrigger>
              <TooltipContent side="right">
                <p>High Risk Updates</p>
              </TooltipContent>
            </Tooltip>
          </div>
        )}

        {/* Main Navigation */}
        <nav className="flex-1 overflow-y-auto px-3 py-2">
          <div className="space-y-1">
            {!collapsed && (
              <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider px-3 mb-2">
                Main
              </p>
            )}
            {mainNavItems.map(item => (
              <NavItem key={item.page} item={item} showLabel={!collapsed} />
            ))}
          </div>

          <div className="mt-6 space-y-1">
            {!collapsed && (
              <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider px-3 mb-2">
                Tools
              </p>
            )}
            {toolsItems.map(item => (
              <NavItem key={item.page} item={item} showLabel={!collapsed} />
            ))}
          </div>
        </nav>

        {/* Bottom Section */}
        <div className="border-t border-slate-100 p-3 space-y-1">
          {bottomItems.map(item => (
            <NavItem key={item.page} item={item} showLabel={!collapsed} />
          ))}
          
          {collapsed ? (
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon"
                  className="w-full text-slate-400 hover:text-slate-600"
                  onClick={onToggle}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="right">Expand sidebar</TooltipContent>
            </Tooltip>
          ) : (
            <Button 
              variant="ghost" 
              className="w-full justify-start text-slate-500 hover:text-red-600 hover:bg-red-50"
              onClick={handleLogout}
            >
              <LogOut className="h-4 w-4 mr-3" />
              <span className="text-sm">Logout</span>
            </Button>
          )}
        </div>
      </aside>
    </TooltipProvider>
  );
}