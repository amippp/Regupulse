import AISettings from './pages/AISettings';
import AppSettings from './pages/AppSettings';
import Briefings from './pages/Briefings';
import ComplianceCalendar from './pages/ComplianceCalendar';
import Dashboard from './pages/Dashboard';
import DigestSettings from './pages/DigestSettings';
import Home from './pages/Home';
import LegalEvents from './pages/LegalEvents';
import NotificationSettings from './pages/NotificationSettings';
import Notifications from './pages/Notifications';
import RelevanceRules from './pages/RelevanceRules';
import Reports from './pages/Reports';
import ScanSchedule from './pages/ScanSchedule';
import Sources from './pages/Sources';
import Updates from './pages/Updates';
import __Layout from './Layout.jsx';


export const PAGES = {
    "AISettings": AISettings,
    "AppSettings": AppSettings,
    "Briefings": Briefings,
    "ComplianceCalendar": ComplianceCalendar,
    "Dashboard": Dashboard,
    "DigestSettings": DigestSettings,
    "Home": Home,
    "LegalEvents": LegalEvents,
    "NotificationSettings": NotificationSettings,
    "Notifications": Notifications,
    "RelevanceRules": RelevanceRules,
    "Reports": Reports,
    "ScanSchedule": ScanSchedule,
    "Sources": Sources,
    "Updates": Updates,
}

export const pagesConfig = {
    mainPage: "Dashboard",
    Pages: PAGES,
    Layout: __Layout,
};