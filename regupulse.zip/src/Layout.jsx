import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import Sidebar from "@/components/layout/Sidebar";
import { cn } from "@/lib/utils";

export default function Layout({ children }) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  // Fetch stats for sidebar badges
  const { data: updates = [] } = useQuery({
    queryKey: ['sidebar-stats'],
    queryFn: () => base44.entities.RegulatoryUpdate.list(),
    staleTime: 60000
  });

  const stats = {
    total: updates.length,
    highRisk: updates.filter(u => u.risk_score === "High").length,
    newToday: updates.filter(u => {
      const created = new Date(u.created_date);
      const today = new Date();
      return created.toDateString() === today.toDateString();
    }).length
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Sidebar 
        collapsed={sidebarCollapsed} 
        onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
        stats={stats}
      />
      
      <main className={cn(
        "min-h-screen transition-all duration-300",
        sidebarCollapsed ? "ml-[72px]" : "ml-64"
      )}>
        {children}
      </main>
    </div>
  );
}