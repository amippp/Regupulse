import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Search, 
  Filter, 
  FileText, 
  ExternalLink, 
  ChevronLeft, 
  ChevronRight,
  LayoutGrid,
  LayoutList,
  SlidersHorizontal
} from "lucide-react";
import { format } from "date-fns";
import TopBar from "@/components/layout/TopBar";
import UpdateDetailModal from "@/components/compliance/UpdateDetailModal";
import RiskBadge from "@/components/compliance/RiskBadge";
import DomainBadge from "@/components/compliance/DomainBadge";
import JurisdictionBadge from "@/components/compliance/JurisdictionBadge";
import UpdateCard from "@/components/compliance/UpdateCard";

const domains = ["All Domains", "AI Law", "Privacy", "Antitrust", "Consumer Protection", "Platform Liability", "IP"];
const jurisdictions = ["All Jurisdictions", "United States", "European Union", "United Kingdom", "Israel", "Global"];
const riskLevels = ["All Risk Levels", "High", "Medium", "Low"];
const statuses = ["All Statuses", "New", "Under Review", "Action Required", "Resolved", "Monitoring"];

export default function Updates() {
  const queryClient = useQueryClient();
  const [selectedUpdate, setSelectedUpdate] = useState(null);
  const [viewMode, setViewMode] = useState("table");
  const [page, setPage] = useState(1);
  const [filters, setFilters] = useState({
    search: "",
    domain: "All Domains",
    jurisdiction: "All Jurisdictions",
    risk: "All Risk Levels",
    status: "All Statuses"
  });

  const pageSize = 20;

  const { data: rawUpdates = [], isLoading } = useQuery({
    queryKey: ['all-updates'],
    queryFn: () => base44.entities.RegulatoryUpdate.list('-publish_date')
  });

  // Remove duplicates - keep first occurrence of each unique title or URL
  const allUpdates = rawUpdates.filter((update, index, self) => {
    const normalizedTitle = update.title?.toLowerCase().trim();
    const normalizedUrl = update.source_url?.toLowerCase().trim();
    
    const firstIndex = self.findIndex(u => {
      const uTitle = u.title?.toLowerCase().trim();
      const uUrl = u.source_url?.toLowerCase().trim();
      return uTitle === normalizedTitle || 
             (normalizedUrl && uUrl && uUrl === normalizedUrl);
    });
    
    return index === firstIndex;
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, status }) => base44.entities.RegulatoryUpdate.update(id, { status }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['all-updates'] })
  });

  const handleStatusChange = (id, status) => {
    updateMutation.mutate({ id, status });
    setSelectedUpdate(prev => prev ? { ...prev, status } : null);
  };

  // Filter updates
  const filteredUpdates = allUpdates.filter(update => {
    if (filters.search && 
        !update.title?.toLowerCase().includes(filters.search.toLowerCase()) &&
        !update.summary?.toLowerCase().includes(filters.search.toLowerCase())) return false;
    if (filters.domain !== "All Domains" && update.domain !== filters.domain) return false;
    if (filters.jurisdiction !== "All Jurisdictions" && update.jurisdiction !== filters.jurisdiction) return false;
    if (filters.risk !== "All Risk Levels" && update.risk_score !== filters.risk) return false;
    if (filters.status !== "All Statuses" && update.status !== filters.status) return false;
    return true;
  });

  // Pagination
  const totalPages = Math.ceil(filteredUpdates.length / pageSize);
  const paginatedUpdates = filteredUpdates.slice((page - 1) * pageSize, page * pageSize);

  const clearFilters = () => {
    setFilters({
      search: "",
      domain: "All Domains",
      jurisdiction: "All Jurisdictions",
      risk: "All Risk Levels",
      status: "All Statuses"
    });
    setPage(1);
  };

  const hasActiveFilters = Object.entries(filters).some(([key, value]) => {
    if (key === "search") return value !== "";
    return !value.startsWith("All");
  });

  return (
    <div className="min-h-screen bg-slate-50">
      <TopBar 
        title="Regulatory Updates" 
        subtitle={`${filteredUpdates.length} total updates`}
        actions={
          <div className="flex items-center gap-2">
            <Button
              variant={viewMode === "table" ? "default" : "outline"}
              size="icon"
              onClick={() => setViewMode("table")}
            >
              <LayoutList className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === "cards" ? "default" : "outline"}
              size="icon"
              onClick={() => setViewMode("cards")}
            >
              <LayoutGrid className="h-4 w-4" />
            </Button>
          </div>
        }
      />

      <div className="p-6">
        {/* Filters */}
        <Card className="p-4 mb-6">
          <div className="flex items-center gap-2 mb-4">
            <SlidersHorizontal className="h-4 w-4 text-slate-500" />
            <span className="font-medium text-sm text-slate-700">Filters</span>
            {hasActiveFilters && (
              <Button variant="ghost" size="sm" onClick={clearFilters} className="ml-auto text-slate-500">
                Clear all
              </Button>
            )}
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <Input
                placeholder="Search..."
                value={filters.search}
                onChange={(e) => { setFilters({ ...filters, search: e.target.value }); setPage(1); }}
                className="pl-9"
              />
            </div>
            
            <Select value={filters.domain} onValueChange={(v) => { setFilters({ ...filters, domain: v }); setPage(1); }}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {domains.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
              </SelectContent>
            </Select>
            
            <Select value={filters.jurisdiction} onValueChange={(v) => { setFilters({ ...filters, jurisdiction: v }); setPage(1); }}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {jurisdictions.map(j => <SelectItem key={j} value={j}>{j}</SelectItem>)}
              </SelectContent>
            </Select>
            
            <Select value={filters.risk} onValueChange={(v) => { setFilters({ ...filters, risk: v }); setPage(1); }}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {riskLevels.map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}
              </SelectContent>
            </Select>
            
            <Select value={filters.status} onValueChange={(v) => { setFilters({ ...filters, status: v }); setPage(1); }}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {statuses.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </Card>

        {/* Content */}
        {isLoading ? (
          <div className="space-y-3">
            {Array(5).fill(0).map((_, i) => <Skeleton key={i} className="h-16 rounded-lg" />)}
          </div>
        ) : viewMode === "table" ? (
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[40%]">Title</TableHead>
                  <TableHead>Domain</TableHead>
                  <TableHead>Jurisdiction</TableHead>
                  <TableHead>Risk</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="w-10"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedUpdates.map(update => (
                  <TableRow 
                    key={update.id} 
                    className="cursor-pointer hover:bg-slate-50"
                    onClick={() => setSelectedUpdate(update)}
                  >
                    <TableCell>
                      <div className="font-medium text-slate-900 line-clamp-1">{update.title}</div>
                      <div className="text-xs text-slate-500">{update.source}</div>
                    </TableCell>
                    <TableCell><DomainBadge domain={update.domain} /></TableCell>
                    <TableCell><JurisdictionBadge jurisdiction={update.jurisdiction} /></TableCell>
                    <TableCell><RiskBadge risk={update.risk_score} /></TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-xs">
                        {update.status || "New"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-slate-500">
                      {update.publish_date ? format(new Date(update.publish_date), "MMM d") : "-"}
                    </TableCell>
                    <TableCell>
                      {update.source_url && (
                        <a href={update.source_url} target="_blank" rel="noopener noreferrer" onClick={e => e.stopPropagation()}>
                          <ExternalLink className="h-4 w-4 text-slate-400 hover:text-blue-600" />
                        </a>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {paginatedUpdates.map(update => (
              <UpdateCard 
                key={update.id} 
                update={update} 
                onClick={() => setSelectedUpdate(update)}
              />
            ))}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between mt-6">
            <p className="text-sm text-slate-500">
              Showing {(page - 1) * pageSize + 1} to {Math.min(page * pageSize, filteredUpdates.length)} of {filteredUpdates.length}
            </p>
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setPage(p => p - 1)}
                disabled={page === 1}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="text-sm text-slate-600">
                Page {page} of {totalPages}
              </span>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setPage(p => p + 1)}
                disabled={page === totalPages}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </div>

      <UpdateDetailModal
        update={selectedUpdate}
        open={!!selectedUpdate}
        onClose={() => setSelectedUpdate(null)}
        onStatusChange={handleStatusChange}
        allUpdates={allUpdates}
        onSelectUpdate={setSelectedUpdate}
      />
    </div>
  );
}