import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Calendar as CalendarIcon, 
  ChevronLeft, 
  ChevronRight, 
  Clock,
  AlertTriangle,
  Bell
} from "lucide-react";
import { 
  format, 
  startOfMonth, 
  endOfMonth, 
  eachDayOfInterval, 
  isSameMonth, 
  isSameDay, 
  addMonths, 
  subMonths, 
  isToday,
  isBefore,
  startOfWeek,
  endOfWeek,
  addDays
} from "date-fns";
import { cn } from "@/lib/utils";
import TopBar from "@/components/layout/TopBar";
import UpdateDetailModal from "@/components/compliance/UpdateDetailModal";
import RiskBadge from "@/components/compliance/RiskBadge";

function parseDeadlines(updates) {
  const deadlines = [];
  
  updates.forEach(update => {
    if (!update.key_dates || update.key_dates.length === 0) return;
    
    update.key_dates.forEach(dateStr => {
      const patterns = [
        /(\d{1,2}\/\d{1,2}\/\d{4})/,
        /(\d{4}-\d{2}-\d{2})/,
        /(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s+\d{4}/i
      ];
      
      for (const pattern of patterns) {
        const match = dateStr.match(pattern);
        if (match) {
          try {
            const date = new Date(match[0]);
            if (!isNaN(date.getTime())) {
              deadlines.push({
                date,
                description: dateStr,
                update
              });
              break;
            }
          } catch {
            continue;
          }
        }
      }
    });
  });
  
  return deadlines.sort((a, b) => a.date - b.date);
}

export default function ComplianceCalendar() {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedUpdate, setSelectedUpdate] = useState(null);
  const [selectedDate, setSelectedDate] = useState(null);

  const { data: updates = [], isLoading } = useQuery({
    queryKey: ['calendar-updates'],
    queryFn: () => base44.entities.RegulatoryUpdate.list()
  });

  const deadlines = parseDeadlines(updates);
  
  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const calendarStart = startOfWeek(monthStart);
  const calendarEnd = endOfWeek(monthEnd);
  const days = eachDayOfInterval({ start: calendarStart, end: calendarEnd });
  
  const getDeadlinesForDay = (day) => {
    return deadlines.filter(d => isSameDay(d.date, day));
  };

  const upcomingDeadlines = deadlines
    .filter(d => d.date >= new Date())
    .slice(0, 10);

  const pastDueDeadlines = deadlines
    .filter(d => isBefore(d.date, new Date()) && !isToday(d.date))
    .slice(-5)
    .reverse();

  return (
    <div className="min-h-screen bg-slate-50">
      <TopBar 
        title="Compliance Calendar" 
        subtitle="Track deadlines and key regulatory dates"
      />

      <div className="p-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Calendar */}
          <Card className="lg:col-span-2 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-slate-900">
                {format(currentMonth, "MMMM yyyy")}
              </h2>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="icon" onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm" onClick={() => setCurrentMonth(new Date())}>
                  Today
                </Button>
                <Button variant="outline" size="icon" onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Calendar Grid */}
            <div className="grid grid-cols-7 gap-1">
              {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map(day => (
                <div key={day} className="text-center text-sm font-medium text-slate-500 py-2">
                  {day}
                </div>
              ))}
              
              {days.map(day => {
                const dayDeadlines = getDeadlinesForDay(day);
                const hasDeadline = dayDeadlines.length > 0;
                const isPast = isBefore(day, new Date()) && !isToday(day);
                const isCurrentMonth = isSameMonth(day, currentMonth);
                const isSelected = selectedDate && isSameDay(day, selectedDate);
                
                return (
                  <div
                    key={day.toISOString()}
                    onClick={() => hasDeadline && setSelectedDate(day)}
                    className={cn(
                      "min-h-[80px] p-1 border rounded-lg transition-all",
                      !isCurrentMonth && "bg-slate-50 opacity-50",
                      isToday(day) && "border-blue-500 bg-blue-50",
                      hasDeadline && !isPast && "cursor-pointer hover:shadow-md",
                      isSelected && "ring-2 ring-blue-500"
                    )}
                  >
                    <div className={cn(
                      "text-sm font-medium mb-1",
                      isToday(day) ? "text-blue-600" : "text-slate-700"
                    )}>
                      {format(day, "d")}
                    </div>
                    
                    {dayDeadlines.slice(0, 2).map((dl, idx) => (
                      <div 
                        key={idx}
                        onClick={(e) => { e.stopPropagation(); setSelectedUpdate(dl.update); }}
                        className={cn(
                          "text-xs px-1.5 py-0.5 rounded truncate mb-0.5 cursor-pointer",
                          isPast ? "bg-slate-100 text-slate-500" : 
                          dl.update.risk_score === "High" ? "bg-red-100 text-red-700" :
                          dl.update.risk_score === "Medium" ? "bg-amber-100 text-amber-700" :
                          "bg-emerald-100 text-emerald-700"
                        )}
                      >
                        {dl.update.title?.substring(0, 20)}...
                      </div>
                    ))}
                    
                    {dayDeadlines.length > 2 && (
                      <div className="text-xs text-slate-500 px-1">
                        +{dayDeadlines.length - 2} more
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </Card>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Upcoming Deadlines */}
            <Card className="p-4">
              <div className="flex items-center gap-2 mb-4">
                <Clock className="h-5 w-5 text-blue-600" />
                <h3 className="font-semibold text-slate-900">Upcoming Deadlines</h3>
              </div>
              
              {upcomingDeadlines.length === 0 ? (
                <p className="text-sm text-slate-500 text-center py-4">No upcoming deadlines</p>
              ) : (
                <div className="space-y-3">
                  {upcomingDeadlines.map((dl, idx) => (
                    <div 
                      key={idx}
                      onClick={() => setSelectedUpdate(dl.update)}
                      className="flex items-start gap-3 p-2 rounded-lg hover:bg-slate-50 cursor-pointer transition-colors"
                    >
                      <div className={cn(
                        "w-2 h-2 rounded-full mt-2 shrink-0",
                        dl.update.risk_score === "High" ? "bg-red-500" :
                        dl.update.risk_score === "Medium" ? "bg-amber-500" : "bg-emerald-500"
                      )} />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-slate-900 line-clamp-1">{dl.update.title}</p>
                        <p className="text-xs text-slate-500">{format(dl.date, "MMM d, yyyy")}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>

            {/* Past Due */}
            {pastDueDeadlines.length > 0 && (
              <Card className="p-4 border-red-200 bg-red-50">
                <div className="flex items-center gap-2 mb-4">
                  <AlertTriangle className="h-5 w-5 text-red-600" />
                  <h3 className="font-semibold text-red-900">Past Due</h3>
                </div>
                
                <div className="space-y-3">
                  {pastDueDeadlines.map((dl, idx) => (
                    <div 
                      key={idx}
                      onClick={() => setSelectedUpdate(dl.update)}
                      className="flex items-start gap-3 p-2 rounded-lg hover:bg-red-100 cursor-pointer transition-colors"
                    >
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-red-900 line-clamp-1">{dl.update.title}</p>
                        <p className="text-xs text-red-600">{format(dl.date, "MMM d, yyyy")}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            )}

            {/* Selected Date Events */}
            {selectedDate && (
              <Card className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-slate-900">
                    {format(selectedDate, "MMMM d, yyyy")}
                  </h3>
                  <Button variant="ghost" size="sm" onClick={() => setSelectedDate(null)}>
                    Clear
                  </Button>
                </div>
                
                <div className="space-y-3">
                  {getDeadlinesForDay(selectedDate).map((dl, idx) => (
                    <div 
                      key={idx}
                      onClick={() => setSelectedUpdate(dl.update)}
                      className="p-3 rounded-lg bg-slate-50 hover:bg-slate-100 cursor-pointer transition-colors"
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <RiskBadge risk={dl.update.risk_score} size="sm" />
                      </div>
                      <p className="text-sm font-medium text-slate-900">{dl.update.title}</p>
                      <p className="text-xs text-slate-500 mt-1">{dl.description}</p>
                    </div>
                  ))}
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>

      <UpdateDetailModal
        update={selectedUpdate}
        open={!!selectedUpdate}
        onClose={() => setSelectedUpdate(null)}
        allUpdates={updates}
        onSelectUpdate={setSelectedUpdate}
      />
    </div>
  );
}