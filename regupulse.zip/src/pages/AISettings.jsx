import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Sparkles, 
  Globe, 
  ShieldCheck, 
  FileText, 
  Save,
  Cpu,
  Database,
  MessageSquare,
  RefreshCw,
  Info
} from "lucide-react";
import { toast } from "sonner";
import TopBar from "@/components/layout/TopBar";

const regions = [
  { id: "us", label: "United States" },
  { id: "eu", label: "European Union" },
  { id: "uk", label: "United Kingdom" },
  { id: "israel", label: "Israel" },
  { id: "canada", label: "Canada" },
  { id: "australia", label: "Australia" },
  { id: "brazil", label: "Brazil" },
  { id: "india", label: "India" },
  { id: "china", label: "China" },
  { id: "global", label: "Global" }
];

const riskAreas = [
  { id: "ai_law", label: "AI Law & Algorithmic Accountability" },
  { id: "privacy", label: "Privacy & Data Protection" },
  { id: "antitrust", label: "Antitrust & Competition" },
  { id: "consumer_protection", label: "Consumer Protection" },
  { id: "platform_liability", label: "Platform Liability" },
  { id: "ip", label: "Intellectual Property" }
];

const regulations = [
  { id: "gdpr", label: "GDPR", region: "EU" },
  { id: "ccpa", label: "CCPA/CPRA", region: "US" },
  { id: "hipaa", label: "HIPAA", region: "US" },
  { id: "eu_ai_act", label: "EU AI Act", region: "EU" },
  { id: "dsa", label: "Digital Services Act", region: "EU" },
  { id: "dma", label: "Digital Markets Act", region: "EU" },
  { id: "coppa", label: "COPPA", region: "US" },
  { id: "pci_dss", label: "PCI-DSS", region: "Global" },
  { id: "soc2", label: "SOC 2", region: "Global" },
  { id: "iso27001", label: "ISO 27001", region: "Global" },
  { id: "lgpd", label: "LGPD", region: "Brazil" },
  { id: "pdpa", label: "PDPA", region: "Singapore" },
  { id: "pipl", label: "PIPL", region: "China" }
];

const dataTypes = [
  { id: "pii", label: "Personal Identifiable Information (PII)" },
  { id: "financial", label: "Financial Data" },
  { id: "health", label: "Health/Medical Data" },
  { id: "children", label: "Children's Data" },
  { id: "biometric", label: "Biometric Data" },
  { id: "location", label: "Location Data" },
  { id: "behavioral", label: "Behavioral/Analytics Data" }
];

const DEFAULT_PROMPT = `You are a legal compliance analyst helping a technology company stay compliant.

ANALYSIS PRIORITIES:
- Focus on regulations and risk areas specified in the company profile
- Consider operating regions when assessing jurisdictional impact
- Highlight implications for the data types the company processes
- Prioritize updates with imminent deadlines or direct business impact

RISK SCORING:
- HIGH: Directly affects the company's industry, involves priority regulatory frameworks, or has imminent deadlines
- MEDIUM: Indirectly relevant, sets precedent, or affects related industries
- LOW: General regulatory news useful for awareness but no immediate impact

OUTPUT REQUIREMENTS:
- Provide concise, actionable insights
- Extract 3-5 key takeaways for compliance teams
- Generate thought-provoking questions to help understand impact
- Suggest specific compliance actions when applicable`;

export default function AISettings() {
  const queryClient = useQueryClient();
  const [saving, setSaving] = useState(false);
  const [generatingPrompt, setGeneratingPrompt] = useState(false);
  
  const [profile, setProfile] = useState({
    operating_regions: [],
    key_risk_areas: [],
    regulatory_frameworks: [],
    data_types_processed: [],
    uses_ai_ml: false,
    custom_prompt: DEFAULT_PROMPT,
    additional_context: ""
  });

  const { data: existingProfiles = [], isLoading } = useQuery({
    queryKey: ['company-profile'],
    queryFn: () => base44.entities.CompanyProfile.list()
  });

  useEffect(() => {
    if (existingProfiles.length > 0) {
      const existing = existingProfiles[0];
      setProfile({
        operating_regions: existing.operating_regions || [],
        key_risk_areas: existing.key_risk_areas || [],
        regulatory_frameworks: existing.regulatory_frameworks || [],
        data_types_processed: existing.data_types_processed || [],
        uses_ai_ml: existing.uses_ai_ml || false,
        custom_prompt: existing.custom_prompt || DEFAULT_PROMPT,
        additional_context: existing.additional_context || ""
      });
    }
  }, [existingProfiles]);

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      if (existingProfiles.length > 0) {
        return base44.entities.CompanyProfile.update(existingProfiles[0].id, data);
      } else {
        return base44.entities.CompanyProfile.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['company-profile'] });
      toast.success("AI settings saved successfully");
      setSaving(false);
    },
    onError: () => {
      toast.error("Failed to save settings");
      setSaving(false);
    }
  });

  const handleSave = () => {
    setSaving(true);
    saveMutation.mutate(profile);
  };

  const toggleArrayItem = (field, item) => {
    setProfile(prev => ({
      ...prev,
      [field]: prev[field].includes(item)
        ? prev[field].filter(i => i !== item)
        : [...prev[field], item]
    }));
  };

  const optimizePrompt = async () => {
    setGeneratingPrompt(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert at crafting AI prompts for regulatory compliance analysis.

Current user settings:
- Operating Regions: ${profile.operating_regions.join(', ') || 'Not specified'}
- Key Risk Areas: ${profile.key_risk_areas.join(', ') || 'Not specified'}
- Regulatory Frameworks: ${profile.regulatory_frameworks.join(', ') || 'Not specified'}
- Data Types Processed: ${profile.data_types_processed.join(', ') || 'Not specified'}
- Uses AI/ML: ${profile.uses_ai_ml ? 'Yes' : 'No'}
- Additional Context: ${profile.additional_context || 'None'}

Current prompt:
${profile.custom_prompt}

Generate an optimized version of this prompt that:
1. Is tailored to the user's specific settings and compliance needs
2. Maintains the core analysis structure but improves clarity
3. Adds specific guidance based on their regulatory frameworks and risk areas
4. Keeps the prompt concise but comprehensive

Return ONLY the optimized prompt text, no explanations.`,
        response_json_schema: {
          type: "object",
          properties: {
            optimized_prompt: { type: "string" }
          },
          required: ["optimized_prompt"]
        }
      });
      
      setProfile(prev => ({ ...prev, custom_prompt: result.optimized_prompt }));
      toast.success("Prompt optimized based on your settings");
    } catch (err) {
      toast.error("Failed to optimize prompt");
    } finally {
      setGeneratingPrompt(false);
    }
  };

  const resetPrompt = () => {
    setProfile(prev => ({ ...prev, custom_prompt: DEFAULT_PROMPT }));
    toast.info("Prompt reset to default");
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50">
        <TopBar title="AI Settings" subtitle="Configure AI analysis preferences" />
        <div className="p-6 max-w-4xl mx-auto">
          <Card className="p-8 animate-pulse">
            <div className="h-8 bg-slate-200 rounded w-1/3 mb-6" />
            <div className="space-y-4">
              <div className="h-10 bg-slate-200 rounded" />
              <div className="h-10 bg-slate-200 rounded" />
              <div className="h-10 bg-slate-200 rounded" />
            </div>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <TopBar 
        title="AI Settings" 
        subtitle="Customize AI analysis for your company's compliance needs"
        actions={
          <Button onClick={handleSave} disabled={saving}>
            <Save className="h-4 w-4 mr-2" />
            {saving ? "Saving..." : "Save Settings"}
          </Button>
        }
      />

      <div className="p-6 max-w-4xl mx-auto space-y-6">
        {/* Info Banner */}
        <Card className="p-4 bg-gradient-to-r from-violet-50 to-indigo-50 border-violet-200">
          <div className="flex items-start gap-3">
            <div className="p-2 bg-violet-100 rounded-lg">
              <Sparkles className="h-5 w-5 text-violet-600" />
            </div>
            <div>
              <h3 className="font-semibold text-violet-900">Personalized AI Analysis</h3>
              <p className="text-sm text-violet-700 mt-1">
                Configure your compliance profile and customize the AI prompt to receive tailored 
                regulatory insights specific to your operations.
              </p>
            </div>
          </div>
        </Card>

        {/* Custom AI Prompt */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-slate-600" />
              <h3 className="font-semibold text-slate-900">AI Analysis Prompt</h3>
            </div>
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={resetPrompt}
              >
                Reset to Default
              </Button>
              <Button 
                size="sm" 
                onClick={optimizePrompt}
                disabled={generatingPrompt}
                className="bg-violet-600 hover:bg-violet-700"
              >
                {generatingPrompt ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    Optimizing...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4 mr-2" />
                    Optimize with AI
                  </>
                )}
              </Button>
            </div>
          </div>
          <p className="text-sm text-slate-500 mb-4">
            Customize how the AI analyzes regulatory updates. Click "Optimize with AI" to automatically 
            tailor the prompt based on your settings below.
          </p>
          
          <Textarea
            value={profile.custom_prompt}
            onChange={(e) => setProfile({ ...profile, custom_prompt: e.target.value })}
            placeholder="Enter your custom AI analysis prompt..."
            className="min-h-[250px] font-mono text-sm"
          />
        </Card>

        {/* AI/ML Toggle */}
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Cpu className="h-5 w-5 text-slate-500" />
              <div>
                <Label className="font-medium">Uses AI/ML in Products</Label>
                <p className="text-sm text-slate-500">Enable for AI-specific regulatory tracking (EU AI Act, etc.)</p>
              </div>
            </div>
            <Switch 
              checked={profile.uses_ai_ml}
              onCheckedChange={(checked) => setProfile({ ...profile, uses_ai_ml: checked })}
            />
          </div>
        </Card>

        {/* Operating Regions */}
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <Globe className="h-5 w-5 text-slate-600" />
            <h3 className="font-semibold text-slate-900">Operating Regions</h3>
          </div>
          <p className="text-sm text-slate-500 mb-4">Select regions where your company operates or serves customers</p>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
            {regions.map(region => (
              <div
                key={region.id}
                onClick={() => toggleArrayItem('operating_regions', region.label)}
                className={`p-3 rounded-lg border cursor-pointer transition-all text-center ${
                  profile.operating_regions.includes(region.label)
                    ? 'bg-blue-50 border-blue-300 text-blue-700'
                    : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                }`}
              >
                <span className="text-sm font-medium">{region.label}</span>
              </div>
            ))}
          </div>
        </Card>

        {/* Key Risk Areas */}
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <ShieldCheck className="h-5 w-5 text-slate-600" />
            <h3 className="font-semibold text-slate-900">Key Risk Areas</h3>
          </div>
          <p className="text-sm text-slate-500 mb-4">Select compliance domains most relevant to your business</p>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {riskAreas.map(area => (
              <div
                key={area.id}
                onClick={() => toggleArrayItem('key_risk_areas', area.label)}
                className={`p-4 rounded-lg border cursor-pointer transition-all ${
                  profile.key_risk_areas.includes(area.label)
                    ? 'bg-violet-50 border-violet-300'
                    : 'bg-white border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Checkbox checked={profile.key_risk_areas.includes(area.label)} />
                  <span className={`font-medium ${profile.key_risk_areas.includes(area.label) ? 'text-violet-700' : 'text-slate-700'}`}>
                    {area.label}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Regulatory Frameworks */}
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <FileText className="h-5 w-5 text-slate-600" />
            <h3 className="font-semibold text-slate-900">Regulatory Frameworks</h3>
          </div>
          <p className="text-sm text-slate-500 mb-4">Select specific regulations your company needs to comply with</p>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {regulations.map(reg => (
              <div
                key={reg.id}
                onClick={() => toggleArrayItem('regulatory_frameworks', reg.label)}
                className={`p-3 rounded-lg border cursor-pointer transition-all ${
                  profile.regulatory_frameworks.includes(reg.label)
                    ? 'bg-emerald-50 border-emerald-300'
                    : 'bg-white border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className={`font-medium text-sm ${profile.regulatory_frameworks.includes(reg.label) ? 'text-emerald-700' : 'text-slate-700'}`}>
                    {reg.label}
                  </span>
                  <Badge variant="outline" className="text-xs">{reg.region}</Badge>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Data Types Processed */}
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <Database className="h-5 w-5 text-slate-600" />
            <h3 className="font-semibold text-slate-900">Data Types Processed</h3>
          </div>
          <p className="text-sm text-slate-500 mb-4">Select types of data your company collects or processes</p>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {dataTypes.map(dt => (
              <div
                key={dt.id}
                onClick={() => toggleArrayItem('data_types_processed', dt.label)}
                className={`p-4 rounded-lg border cursor-pointer transition-all ${
                  profile.data_types_processed.includes(dt.label)
                    ? 'bg-amber-50 border-amber-300'
                    : 'bg-white border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Checkbox checked={profile.data_types_processed.includes(dt.label)} />
                  <span className={`font-medium ${profile.data_types_processed.includes(dt.label) ? 'text-amber-700' : 'text-slate-700'}`}>
                    {dt.label}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Additional Context */}
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <Info className="h-5 w-5 text-slate-600" />
            <h3 className="font-semibold text-slate-900">Additional Context</h3>
          </div>
          <p className="text-sm text-slate-500 mb-4">Provide any additional information to help tailor AI analysis</p>
          
          <Textarea
            value={profile.additional_context}
            onChange={(e) => setProfile({ ...profile, additional_context: e.target.value })}
            placeholder="E.g., We're planning to expand to the EU market next year, we process payment data for merchants, we're subject to specific industry certifications..."
            className="min-h-[100px]"
          />
        </Card>

        {/* Save Button */}
        <div className="flex justify-end">
          <Button onClick={handleSave} disabled={saving} size="lg">
            <Save className="h-4 w-4 mr-2" />
            {saving ? "Saving..." : "Save AI Settings"}
          </Button>
        </div>
      </div>
    </div>
  );
}