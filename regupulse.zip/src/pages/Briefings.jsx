import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  FileText, Plus, Settings, Clock, Mail, Calendar,
  ChevronRight, Loader2, CheckCircle2, AlertCircle
} from "lucide-react";
import { format } from "date-fns";
import TopBar from "@/components/layout/TopBar";
import BriefingConfigDialog from "@/components/briefings/BriefingConfigDialog";
import BriefingViewDialog from "@/components/briefings/BriefingViewDialog";

export default function Briefings() {
  const queryClient = useQueryClient();
  const [configDialogOpen, setConfigDialogOpen] = useState(false);
  const [editingConfig, setEditingConfig] = useState(null);
  const [viewingBriefing, setViewingBriefing] = useState(null);

  const { data: configs = [], isLoading: configsLoading } = useQuery({
    queryKey: ['briefing-configs'],
    queryFn: () => base44.entities.BriefingConfig.list()
  });

  const { data: briefings = [], isLoading: briefingsLoading } = useQuery({
    queryKey: ['briefings'],
    queryFn: () => base44.entities.Briefing.list('-created_date', 50)
  });

  const generateMutation = useMutation({
    mutationFn: async (configId) => {
      return base44.functions.invoke('generateBriefing', { configId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['briefings'] });
      queryClient.invalidateQueries({ queryKey: ['briefing-configs'] });
    }
  });

  const deleteConfigMutation = useMutation({
    mutationFn: (id) => base44.entities.BriefingConfig.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['briefing-configs'] })
  });

  const frequencyColors = {
    daily: "bg-blue-100 text-blue-700",
    weekly: "bg-violet-100 text-violet-700",
    monthly: "bg-amber-100 text-amber-700"
  };

  const statusIcons = {
    generated: <CheckCircle2 className="h-4 w-4 text-emerald-500" />,
    sent: <Mail className="h-4 w-4 text-blue-500" />,
    failed: <AlertCircle className="h-4 w-4 text-red-500" />
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <TopBar 
        title="Legal Briefings" 
        subtitle="AI-generated compliance briefings delivered to your inbox"
        actions={
          <Button onClick={() => { setEditingConfig(null); setConfigDialogOpen(true); }} className="gap-2">
            <Plus className="h-4 w-4" />
            New Briefing Config
          </Button>
        }
      />

      <div className="p-6">
        <Tabs defaultValue="configs" className="space-y-6">
          <TabsList>
            <TabsTrigger value="configs" className="gap-2">
              <Settings className="h-4 w-4" />
              Configurations
            </TabsTrigger>
            <TabsTrigger value="archive" className="gap-2">
              <FileText className="h-4 w-4" />
              Archive ({briefings.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="configs">
            {configsLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-slate-400" />
              </div>
            ) : configs.length === 0 ? (
              <Card className="p-12 text-center">
                <Mail className="h-12 w-12 text-slate-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-slate-900 mb-2">No briefing configurations</h3>
                <p className="text-slate-500 mb-4">Create a briefing configuration to receive automated legal briefings.</p>
                <Button onClick={() => setConfigDialogOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Create Configuration
                </Button>
              </Card>
            ) : (
              <div className="grid gap-4">
                {configs.map(config => (
                  <Card key={config.id} className="p-5">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="font-semibold text-slate-900">{config.name}</h3>
                          <Badge className={frequencyColors[config.frequency]}>
                            {config.frequency}
                          </Badge>
                          {!config.is_active && (
                            <Badge variant="outline" className="text-slate-500">Paused</Badge>
                          )}
                        </div>
                        
                        <div className="flex flex-wrap gap-2 mb-3">
                          {config.domains?.map(d => (
                            <Badge key={d} variant="outline" className="text-xs">{d}</Badge>
                          ))}
                          {config.risk_levels?.map(r => (
                            <Badge key={r} variant="outline" className="text-xs bg-red-50 text-red-700 border-red-200">
                              {r} Risk
                            </Badge>
                          ))}
                        </div>

                        <div className="flex items-center gap-4 text-sm text-slate-500">
                          <span className="flex items-center gap-1">
                            <Mail className="h-3.5 w-3.5" />
                            {config.recipients?.length || 0} recipients
                          </span>
                          {config.last_generated && (
                            <span className="flex items-center gap-1">
                              <Clock className="h-3.5 w-3.5" />
                              Last: {format(new Date(config.last_generated), "MMM d, h:mm a")}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => generateMutation.mutate(config.id)}
                          disabled={generateMutation.isPending}
                        >
                          {generateMutation.isPending ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <>Generate Now</>
                          )}
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => { setEditingConfig(config); setConfigDialogOpen(true); }}
                        >
                          Edit
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                          onClick={() => {
                            if (confirm("Delete this briefing configuration?")) {
                              deleteConfigMutation.mutate(config.id);
                            }
                          }}
                        >
                          Delete
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="archive">
            {briefingsLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-slate-400" />
              </div>
            ) : briefings.length === 0 ? (
              <Card className="p-12 text-center">
                <FileText className="h-12 w-12 text-slate-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-slate-900 mb-2">No briefings yet</h3>
                <p className="text-slate-500">Generated briefings will appear here.</p>
              </Card>
            ) : (
              <div className="space-y-3">
                {briefings.map(briefing => (
                  <Card 
                    key={briefing.id} 
                    className="p-4 hover:shadow-md transition-shadow cursor-pointer"
                    onClick={() => setViewingBriefing(briefing)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        {statusIcons[briefing.status]}
                        <div>
                          <h4 className="font-medium text-slate-900">{briefing.title}</h4>
                          <div className="flex items-center gap-3 text-sm text-slate-500 mt-1">
                            <span className="flex items-center gap-1">
                              <Calendar className="h-3.5 w-3.5" />
                              {format(new Date(briefing.created_date), "MMM d, yyyy")}
                            </span>
                            <Badge className={frequencyColors[briefing.frequency]} variant="outline">
                              {briefing.frequency}
                            </Badge>
                            <span>{briefing.updates_count || 0} updates</span>
                          </div>
                        </div>
                      </div>
                      <ChevronRight className="h-5 w-5 text-slate-400" />
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      <BriefingConfigDialog
        open={configDialogOpen}
        onClose={() => { setConfigDialogOpen(false); setEditingConfig(null); }}
        config={editingConfig}
      />

      <BriefingViewDialog
        briefing={viewingBriefing}
        open={!!viewingBriefing}
        onClose={() => setViewingBriefing(null)}
      />
    </div>
  );
}