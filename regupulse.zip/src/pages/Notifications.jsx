import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Bell, 
  AlertTriangle, 
  Activity, 
  Calendar, 
  FileText, 
  Settings,
  CheckCheck,
  Trash2,
  ExternalLink
} from "lucide-react";
import { formatDistanceToNow, format } from "date-fns";
import { cn } from "@/lib/utils";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import TopBar from "@/components/layout/TopBar";
import { toast } from "sonner";

const typeConfig = {
  high_risk_update: { icon: AlertTriangle, label: "High Risk", color: "text-red-600", bg: "bg-red-100" },
  source_health: { icon: Activity, label: "Source Health", color: "text-amber-600", bg: "bg-amber-100" },
  deadline: { icon: Calendar, label: "Deadline", color: "text-blue-600", bg: "bg-blue-100" },
  new_regulation: { icon: FileText, label: "New Regulation", color: "text-violet-600", bg: "bg-violet-100" },
  system: { icon: Settings, label: "System", color: "text-slate-600", bg: "bg-slate-100" }
};

const priorityColors = {
  critical: "border-l-red-500 bg-red-50/50",
  high: "border-l-orange-500 bg-orange-50/30",
  medium: "border-l-blue-500",
  low: "border-l-slate-300"
};

export default function Notifications() {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("all");

  const { data: user } = useQuery({
    queryKey: ['current-user'],
    queryFn: () => base44.auth.me()
  });

  const { data: notifications = [], isLoading } = useQuery({
    queryKey: ['all-notifications', user?.email],
    queryFn: () => base44.entities.Notification.filter(
      { recipient_email: user?.email },
      '-created_date',
      100
    ),
    enabled: !!user?.email
  });

  const markReadMutation = useMutation({
    mutationFn: (id) => base44.entities.Notification.update(id, { is_read: true }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['all-notifications'] })
  });

  const markAllReadMutation = useMutation({
    mutationFn: async () => {
      const unread = notifications.filter(n => !n.is_read);
      await Promise.all(unread.map(n => 
        base44.entities.Notification.update(n.id, { is_read: true })
      ));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-notifications'] });
      toast.success("All notifications marked as read");
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Notification.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-notifications'] });
      toast.success("Notification deleted");
    }
  });

  const clearAllMutation = useMutation({
    mutationFn: async () => {
      const readNotifications = notifications.filter(n => n.is_read);
      await Promise.all(readNotifications.map(n => 
        base44.entities.Notification.delete(n.id)
      ));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-notifications'] });
      toast.success("Cleared read notifications");
    }
  });

  const filteredNotifications = notifications.filter(n => {
    if (activeTab === "unread") return !n.is_read;
    if (activeTab === "critical") return n.priority === "critical" || n.priority === "high";
    return true;
  });

  const unreadCount = notifications.filter(n => !n.is_read).length;

  // Group by date
  const groupedNotifications = filteredNotifications.reduce((groups, notification) => {
    const date = format(new Date(notification.created_date), 'yyyy-MM-dd');
    const today = format(new Date(), 'yyyy-MM-dd');
    const yesterday = format(new Date(Date.now() - 86400000), 'yyyy-MM-dd');
    
    let label = format(new Date(notification.created_date), 'MMMM d, yyyy');
    if (date === today) label = "Today";
    else if (date === yesterday) label = "Yesterday";
    
    if (!groups[label]) groups[label] = [];
    groups[label].push(notification);
    return groups;
  }, {});

  return (
    <div className="min-h-screen bg-slate-50">
      <TopBar 
        title="Notifications" 
        subtitle={`${unreadCount} unread notification${unreadCount !== 1 ? 's' : ''}`}
        actions={
          <Link to={createPageUrl("NotificationSettings")}>
            <Button variant="outline" className="gap-2">
              <Settings className="h-4 w-4" />
              Settings
            </Button>
          </Link>
        }
      />

      <div className="p-6 max-w-4xl mx-auto">
        {/* Filters & Actions */}
        <div className="flex flex-col sm:flex-row justify-between gap-4 mb-6">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="all">All ({notifications.length})</TabsTrigger>
              <TabsTrigger value="unread">Unread ({unreadCount})</TabsTrigger>
              <TabsTrigger value="critical">Critical</TabsTrigger>
            </TabsList>
          </Tabs>

          <div className="flex gap-2">
            {unreadCount > 0 && (
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => markAllReadMutation.mutate()}
                disabled={markAllReadMutation.isPending}
              >
                <CheckCheck className="h-4 w-4 mr-1" />
                Mark all read
              </Button>
            )}
            {notifications.some(n => n.is_read) && (
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => clearAllMutation.mutate()}
                disabled={clearAllMutation.isPending}
              >
                <Trash2 className="h-4 w-4 mr-1" />
                Clear read
              </Button>
            )}
          </div>
        </div>

        {/* Notifications List */}
        {isLoading ? (
          <div className="space-y-3">
            {Array(5).fill(0).map((_, i) => <Skeleton key={i} className="h-24 rounded-xl" />)}
          </div>
        ) : filteredNotifications.length === 0 ? (
          <Card className="p-12 text-center">
            <Bell className="h-12 w-12 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-slate-900 mb-2">No notifications</h3>
            <p className="text-slate-500">
              {activeTab === "unread" 
                ? "You've read all your notifications"
                : activeTab === "critical"
                ? "No critical notifications"
                : "You're all caught up!"}
            </p>
          </Card>
        ) : (
          <div className="space-y-6">
            {Object.entries(groupedNotifications).map(([dateLabel, dateNotifications]) => (
              <div key={dateLabel}>
                <h3 className="text-sm font-medium text-slate-500 mb-3">{dateLabel}</h3>
                <div className="space-y-2">
                  {dateNotifications.map(notification => {
                    const config = typeConfig[notification.type] || typeConfig.system;
                    const Icon = config.icon;
                    
                    return (
                      <Card 
                        key={notification.id}
                        className={cn(
                          "p-4 border-l-4 transition-all hover:shadow-md",
                          priorityColors[notification.priority],
                          !notification.is_read && "ring-1 ring-blue-200"
                        )}
                      >
                        <div className="flex gap-4">
                          <div className={cn("p-3 rounded-xl shrink-0 h-fit", config.bg)}>
                            <Icon className={cn("h-5 w-5", config.color)} />
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-2 mb-1">
                              <div className="flex items-center gap-2">
                                <h4 className={cn(
                                  "font-medium",
                                  !notification.is_read ? "text-slate-900" : "text-slate-700"
                                )}>
                                  {notification.title}
                                </h4>
                                {!notification.is_read && (
                                  <Badge className="bg-blue-500 text-white text-xs">New</Badge>
                                )}
                                <Badge variant="outline" className="text-xs">
                                  {config.label}
                                </Badge>
                              </div>
                              <span className="text-xs text-slate-400 shrink-0">
                                {formatDistanceToNow(new Date(notification.created_date), { addSuffix: true })}
                              </span>
                            </div>
                            
                            <p className="text-sm text-slate-600 mb-3">
                              {notification.message}
                            </p>
                            
                            <div className="flex items-center gap-2">
                              {notification.action_url && (
                                <Link to={notification.action_url}>
                                  <Button variant="outline" size="sm" className="h-7 text-xs">
                                    <ExternalLink className="h-3 w-3 mr-1" />
                                    View Details
                                  </Button>
                                </Link>
                              )}
                              {!notification.is_read && (
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  className="h-7 text-xs"
                                  onClick={() => markReadMutation.mutate(notification.id)}
                                >
                                  Mark as read
                                </Button>
                              )}
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="h-7 text-xs text-red-600 hover:text-red-700 hover:bg-red-50"
                                onClick={() => deleteMutation.mutate(notification.id)}
                              >
                                Delete
                              </Button>
                            </div>
                          </div>
                        </div>
                      </Card>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}