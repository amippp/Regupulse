import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  User, 
  Bell, 
  Shield, 
  Palette,
  Save,
  CheckCircle2
} from "lucide-react";
import { toast } from "sonner";
import TopBar from "@/components/layout/TopBar";

export default function AppSettings() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [notifications, setNotifications] = useState({
    email_alerts: true,
    high_risk_only: false,
    weekly_digest: true
  });

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (err) {
        console.error("Failed to fetch user");
      } finally {
        setLoading(false);
      }
    };
    fetchUser();
  }, []);

  const handleSaveNotifications = () => {
    setSaving(true);
    setTimeout(() => {
      setSaving(false);
      toast.success("Settings saved successfully");
    }, 500);
  };

  const initials = user?.full_name
    ?.split(" ")
    .map(n => n[0])
    .join("")
    .toUpperCase() || "U";

  return (
    <div className="min-h-screen bg-slate-50">
      <TopBar 
        title="Settings" 
        subtitle="Manage your account and preferences"
      />

      <div className="p-6 max-w-4xl mx-auto">
        <Tabs defaultValue="profile" className="space-y-6">
          <TabsList>
            <TabsTrigger value="profile" className="flex items-center gap-2">
              <User className="h-4 w-4" />
              Profile
            </TabsTrigger>
            <TabsTrigger value="notifications" className="flex items-center gap-2">
              <Bell className="h-4 w-4" />
              Notifications
            </TabsTrigger>
            <TabsTrigger value="security" className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              Security
            </TabsTrigger>
          </TabsList>

          {/* Profile Tab */}
          <TabsContent value="profile">
            <Card className="p-6">
              <h3 className="font-semibold text-slate-900 mb-6">Profile Information</h3>
              
              <div className="flex items-start gap-6 mb-6">
                <Avatar className="h-20 w-20">
                  <AvatarFallback className="bg-gradient-to-br from-blue-500 to-violet-500 text-white text-xl">
                    {initials}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <h4 className="font-medium text-slate-900">{user?.full_name || "User"}</h4>
                  <p className="text-sm text-slate-500">{user?.email || ""}</p>
                  <p className="text-xs text-slate-400 mt-1 capitalize">{user?.role || "user"}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Full Name</Label>
                  <Input value={user?.full_name || ""} disabled />
                </div>
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input value={user?.email || ""} disabled />
                </div>
              </div>

              <p className="text-sm text-slate-500 mt-4">
                Contact your administrator to update profile information.
              </p>
            </Card>
          </TabsContent>

          {/* Notifications Tab */}
          <TabsContent value="notifications">
            <Card className="p-6">
              <h3 className="font-semibold text-slate-900 mb-6">Notification Preferences</h3>
              
              <div className="space-y-6">
                <div className="flex items-center justify-between p-4 rounded-lg bg-slate-50">
                  <div>
                    <Label className="font-medium">Email Alerts</Label>
                    <p className="text-sm text-slate-500">Receive alerts for new regulatory updates</p>
                  </div>
                  <Switch 
                    checked={notifications.email_alerts}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, email_alerts: checked })}
                  />
                </div>

                <div className="flex items-center justify-between p-4 rounded-lg bg-slate-50">
                  <div>
                    <Label className="font-medium">High Risk Only</Label>
                    <p className="text-sm text-slate-500">Only notify for high-risk updates</p>
                  </div>
                  <Switch 
                    checked={notifications.high_risk_only}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, high_risk_only: checked })}
                  />
                </div>

                <div className="flex items-center justify-between p-4 rounded-lg bg-slate-50">
                  <div>
                    <Label className="font-medium">Weekly Digest</Label>
                    <p className="text-sm text-slate-500">Receive a weekly summary email</p>
                  </div>
                  <Switch 
                    checked={notifications.weekly_digest}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, weekly_digest: checked })}
                  />
                </div>

                <Button onClick={handleSaveNotifications} disabled={saving}>
                  <Save className="h-4 w-4 mr-2" />
                  {saving ? "Saving..." : "Save Preferences"}
                </Button>
              </div>
            </Card>
          </TabsContent>

          {/* Security Tab */}
          <TabsContent value="security">
            <Card className="p-6">
              <h3 className="font-semibold text-slate-900 mb-6">Security Settings</h3>
              
              <div className="space-y-6">
                <div className="p-4 rounded-lg bg-emerald-50 border border-emerald-100">
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="h-5 w-5 text-emerald-600" />
                    <div>
                      <p className="font-medium text-emerald-900">Account Secured</p>
                      <p className="text-sm text-emerald-700">Your account is protected with enterprise authentication.</p>
                    </div>
                  </div>
                </div>

                <div className="border-t pt-6">
                  <h4 className="font-medium text-slate-900 mb-4">Session Information</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-slate-600">Last Login</span>
                      <span className="text-slate-900">Today</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-600">Browser</span>
                      <span className="text-slate-900">{navigator.userAgent.split(" ").slice(-1)[0].split("/")[0]}</span>
                    </div>
                  </div>
                </div>

                <Button 
                  variant="destructive" 
                  onClick={() => base44.auth.logout()}
                >
                  Sign Out
                </Button>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}