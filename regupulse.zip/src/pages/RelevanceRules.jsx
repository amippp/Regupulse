import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import TopBar from "@/components/layout/TopBar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Brain, Plus, Trash2, Edit2, CheckCircle2, XCircle, 
  Filter, Target, AlertTriangle, TrendingUp, Search
} from "lucide-react";
import { toast } from "sonner";

const RULE_TYPES = [
  { value: "exclude_keyword", label: "Exclude Keyword", icon: XCircle, color: "text-red-600" },
  { value: "exclude_topic", label: "Exclude Topic", icon: XCircle, color: "text-red-600" },
  { value: "exclude_title_pattern", label: "Exclude Title Pattern", icon: XCircle, color: "text-red-600" },
  { value: "exclude_source_pattern", label: "Exclude Source Pattern", icon: XCircle, color: "text-red-600" },
  { value: "include_keyword", label: "Include Keyword", icon: CheckCircle2, color: "text-emerald-600" },
  { value: "include_topic", label: "Include Topic", icon: CheckCircle2, color: "text-emerald-600" }
];

const DOMAINS = ["AI Law", "Privacy", "Antitrust", "Consumer Protection", "Platform Liability", "IP"];

export default function RelevanceRules() {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("all");
  const [search, setSearch] = useState("");
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [editingRule, setEditingRule] = useState(null);
  const [newRule, setNewRule] = useState({
    rule_type: "exclude_keyword",
    pattern: "",
    domain: "",
    source_name: "",
    reason: ""
  });

  const { data: rules = [], isLoading } = useQuery({
    queryKey: ['relevance-rules'],
    queryFn: () => base44.entities.RelevanceRule.list()
  });

  const createMutation = useMutation({
    mutationFn: (rule) => base44.entities.RelevanceRule.create(rule),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['relevance-rules'] });
      toast.success("Rule created");
      setAddDialogOpen(false);
      resetNewRule();
    },
    onError: (err) => toast.error("Failed to create rule: " + err.message)
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.RelevanceRule.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['relevance-rules'] });
      toast.success("Rule updated");
      setEditingRule(null);
    },
    onError: (err) => toast.error("Failed to update rule: " + err.message)
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.RelevanceRule.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['relevance-rules'] });
      toast.success("Rule deleted");
    },
    onError: (err) => toast.error("Failed to delete rule: " + err.message)
  });

  const resetNewRule = () => {
    setNewRule({ rule_type: "exclude_keyword", pattern: "", domain: "", source_name: "", reason: "" });
  };

  const handleCreateRule = () => {
    if (!newRule.pattern.trim()) {
      toast.error("Pattern is required");
      return;
    }
    createMutation.mutate({
      ...newRule,
      pattern: newRule.pattern.toLowerCase().trim(),
      is_active: true,
      derived_from_feedback_count: 0,
      times_applied: 0,
      accuracy_score: 1.0
    });
  };

  const toggleRuleActive = (rule) => {
    updateMutation.mutate({ id: rule.id, data: { is_active: !rule.is_active } });
  };

  const filteredRules = rules.filter(rule => {
    if (activeTab === "include" && !rule.rule_type.startsWith("include")) return false;
    if (activeTab === "exclude" && !rule.rule_type.startsWith("exclude")) return false;
    if (search && !rule.pattern.toLowerCase().includes(search.toLowerCase()) && 
        !rule.reason?.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const includeCount = rules.filter(r => r.rule_type.startsWith("include")).length;
  const excludeCount = rules.filter(r => r.rule_type.startsWith("exclude")).length;
  const activeCount = rules.filter(r => r.is_active).length;

  const getRuleTypeConfig = (type) => RULE_TYPES.find(t => t.value === type) || RULE_TYPES[0];

  return (
    <div className="min-h-screen bg-slate-50">
      <TopBar 
        title="Relevance Rules" 
        actions={
          <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Add Rule
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5 text-violet-600" />
                  Create Custom Rule
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label>Rule Type</Label>
                  <Select value={newRule.rule_type} onValueChange={(v) => setNewRule({...newRule, rule_type: v})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {RULE_TYPES.map(type => {
                        const Icon = type.icon;
                        return (
                          <SelectItem key={type.value} value={type.value}>
                            <div className="flex items-center gap-2">
                              <Icon className={`h-4 w-4 ${type.color}`} />
                              {type.label}
                            </div>
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Pattern *</Label>
                  <Input 
                    placeholder="e.g., grocery merger, healthcare, etc."
                    value={newRule.pattern}
                    onChange={(e) => setNewRule({...newRule, pattern: e.target.value})}
                  />
                  <p className="text-xs text-slate-500">
                    {newRule.rule_type.startsWith("include") 
                      ? "Articles containing this pattern will be prioritized"
                      : "Articles containing this pattern will be filtered out"}
                  </p>
                </div>

                <div className="space-y-2">
                  <Label>Domain (optional)</Label>
                  <Select value={newRule.domain} onValueChange={(v) => setNewRule({...newRule, domain: v === "all" ? "" : v})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Apply to all domains" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Domains</SelectItem>
                      {DOMAINS.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Source (optional)</Label>
                  <Input 
                    placeholder="e.g., FTC, Law360"
                    value={newRule.source_name}
                    onChange={(e) => setNewRule({...newRule, source_name: e.target.value})}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Reason (optional)</Label>
                  <Input 
                    placeholder="Why is this rule needed?"
                    value={newRule.reason}
                    onChange={(e) => setNewRule({...newRule, reason: e.target.value})}
                  />
                </div>

                <div className="flex gap-3 pt-2">
                  <Button variant="outline" className="flex-1" onClick={() => setAddDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button className="flex-1" onClick={handleCreateRule} disabled={createMutation.isPending}>
                    Create Rule
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        }
      />

      <div className="p-6">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-violet-100">
                <Brain className="h-5 w-5 text-violet-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{rules.length}</p>
                <p className="text-sm text-slate-500">Total Rules</p>
              </div>
            </div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-100">
                <CheckCircle2 className="h-5 w-5 text-emerald-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{includeCount}</p>
                <p className="text-sm text-slate-500">Include Rules</p>
              </div>
            </div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-red-100">
                <XCircle className="h-5 w-5 text-red-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{excludeCount}</p>
                <p className="text-sm text-slate-500">Exclude Rules</p>
              </div>
            </div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-100">
                <TrendingUp className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{activeCount}</p>
                <p className="text-sm text-slate-500">Active Rules</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <Input 
              placeholder="Search rules..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="all">All ({rules.length})</TabsTrigger>
              <TabsTrigger value="include">Include ({includeCount})</TabsTrigger>
              <TabsTrigger value="exclude">Exclude ({excludeCount})</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {/* Rules List */}
        {isLoading ? (
          <div className="space-y-3">
            {[1,2,3].map(i => <Skeleton key={i} className="h-20" />)}
          </div>
        ) : filteredRules.length === 0 ? (
          <Card className="p-12 text-center">
            <Filter className="h-12 w-12 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-slate-900 mb-2">No rules found</h3>
            <p className="text-slate-500 mb-4">
              {rules.length === 0 
                ? "Train the AI by marking articles as relevant or irrelevant, or add custom rules."
                : "Try adjusting your search or filters."}
            </p>
            <Button onClick={() => setAddDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Add Custom Rule
            </Button>
          </Card>
        ) : (
          <div className="space-y-3">
            {filteredRules.map(rule => {
              const typeConfig = getRuleTypeConfig(rule.rule_type);
              const Icon = typeConfig.icon;
              return (
                <Card key={rule.id} className={`p-4 ${!rule.is_active ? 'opacity-60' : ''}`}>
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3 flex-1 min-w-0">
                      <div className={`p-2 rounded-lg ${rule.rule_type.startsWith('include') ? 'bg-emerald-100' : 'bg-red-100'}`}>
                        <Icon className={`h-4 w-4 ${typeConfig.color}`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-medium text-slate-900">"{rule.pattern}"</span>
                          <Badge variant="outline" className="text-xs">{typeConfig.label}</Badge>
                          {rule.domain && <Badge variant="secondary" className="text-xs">{rule.domain}</Badge>}
                          {rule.source_name && <Badge variant="secondary" className="text-xs">{rule.source_name}</Badge>}
                        </div>
                        {rule.reason && (
                          <p className="text-sm text-slate-500 mt-1 truncate">{rule.reason}</p>
                        )}
                        <div className="flex items-center gap-4 mt-2 text-xs text-slate-400">
                          <span>Applied {rule.times_applied || 0} times</span>
                          {rule.derived_from_feedback_count > 0 && (
                            <span>From {rule.derived_from_feedback_count} feedback(s)</span>
                          )}
                          {rule.accuracy_score && (
                            <span>Confidence: {Math.round(rule.accuracy_score * 100)}%</span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch 
                        checked={rule.is_active} 
                        onCheckedChange={() => toggleRuleActive(rule)}
                      />
                      <Button 
                        variant="ghost" 
                        size="icon"
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        onClick={() => {
                          if (confirm("Delete this rule?")) {
                            deleteMutation.mutate(rule.id);
                          }
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}