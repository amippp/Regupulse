import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Gavel, 
  Scale, 
  Building2, 
  TrendingUp, 
  Search, 
  ChevronRight,
  AlertTriangle,
  FileText
} from "lucide-react";
import { format } from "date-fns";
import TopBar from "@/components/layout/TopBar";
import UpdateDetailModal from "@/components/compliance/UpdateDetailModal";
import DomainBadge from "@/components/compliance/DomainBadge";
import JurisdictionBadge from "@/components/compliance/JurisdictionBadge";

const legalTypes = ["Enforcement", "Ruling", "Court Filing", "Class Action"];

export default function LegalEvents() {
  const queryClient = useQueryClient();
  const [selectedUpdate, setSelectedUpdate] = useState(null);
  const [activeTab, setActiveTab] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const { data: updates = [], isLoading } = useQuery({
    queryKey: ['legal-events'],
    queryFn: async () => {
      const all = await base44.entities.RegulatoryUpdate.list('-publish_date');
      return all.filter(u => legalTypes.includes(u.update_type));
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, status }) => base44.entities.RegulatoryUpdate.update(id, { status }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['legal-events'] })
  });

  const handleStatusChange = (id, status) => {
    updateMutation.mutate({ id, status });
    setSelectedUpdate(prev => prev ? { ...prev, status } : null);
  };

  const filteredEvents = updates.filter(event => {
    if (activeTab !== "all" && event.update_type !== activeTab) return false;
    if (searchQuery && 
        !event.title?.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !event.involved_parties?.some(p => p.toLowerCase().includes(searchQuery.toLowerCase()))) return false;
    return true;
  });

  const typeCounts = {
    all: updates.length,
    Enforcement: updates.filter(u => u.update_type === "Enforcement").length,
    Ruling: updates.filter(u => u.update_type === "Ruling").length,
    "Court Filing": updates.filter(u => u.update_type === "Court Filing").length,
    "Class Action": updates.filter(u => u.update_type === "Class Action").length
  };

  const getTypeStyles = (type) => {
    switch (type) {
      case "Enforcement": return "bg-red-100 text-red-700 border-red-200";
      case "Ruling": return "bg-amber-100 text-amber-700 border-amber-200";
      case "Court Filing": return "bg-purple-100 text-purple-700 border-purple-200";
      case "Class Action": return "bg-blue-100 text-blue-700 border-blue-200";
      default: return "bg-slate-100 text-slate-700";
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <TopBar 
        title="Legal Events" 
        subtitle="Court decisions, enforcement actions & class actions"
      />

      <div className="p-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card className="p-4 bg-red-50 border-red-100">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-red-100">
                <AlertTriangle className="h-5 w-5 text-red-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-red-700">{typeCounts.Enforcement}</p>
                <p className="text-xs text-red-600">Enforcement</p>
              </div>
            </div>
          </Card>
          <Card className="p-4 bg-amber-50 border-amber-100">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-100">
                <Gavel className="h-5 w-5 text-amber-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-amber-700">{typeCounts.Ruling}</p>
                <p className="text-xs text-amber-600">Rulings</p>
              </div>
            </div>
          </Card>
          <Card className="p-4 bg-purple-50 border-purple-100">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-100">
                <FileText className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-purple-700">{typeCounts["Court Filing"]}</p>
                <p className="text-xs text-purple-600">Court Filings</p>
              </div>
            </div>
          </Card>
          <Card className="p-4 bg-blue-50 border-blue-100">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-100">
                <Scale className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-blue-700">{typeCounts["Class Action"]}</p>
                <p className="text-xs text-blue-600">Class Actions</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <Input
              placeholder="Search events or parties..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="all">All ({typeCounts.all})</TabsTrigger>
              <TabsTrigger value="Enforcement">Enforcement</TabsTrigger>
              <TabsTrigger value="Ruling">Rulings</TabsTrigger>
              <TabsTrigger value="Court Filing">Filings</TabsTrigger>
              <TabsTrigger value="Class Action">Class Actions</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {/* Events List */}
        {isLoading ? (
          <div className="space-y-4">
            {Array(5).fill(0).map((_, i) => <Skeleton key={i} className="h-32 rounded-xl" />)}
          </div>
        ) : filteredEvents.length === 0 ? (
          <Card className="p-12 text-center">
            <Gavel className="h-12 w-12 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-slate-900 mb-2">No legal events found</h3>
            <p className="text-slate-500">Run a compliance scan to discover enforcement actions and court decisions.</p>
          </Card>
        ) : (
          <div className="space-y-4">
            {filteredEvents.map(event => (
              <Card 
                key={event.id}
                onClick={() => setSelectedUpdate(event)}
                className="p-5 border-l-4 hover:shadow-lg transition-all cursor-pointer group bg-white"
                style={{ borderLeftColor: getTypeStyles(event.update_type).includes("red") ? "#ef4444" : 
                         getTypeStyles(event.update_type).includes("amber") ? "#f59e0b" :
                         getTypeStyles(event.update_type).includes("purple") ? "#8b5cf6" : "#3b82f6" }}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-3">
                      <Badge variant="outline" className={getTypeStyles(event.update_type)}>
                        <Scale className="h-3 w-3 mr-1" />
                        {event.update_type}
                      </Badge>
                      <DomainBadge domain={event.domain} />
                      <JurisdictionBadge jurisdiction={event.jurisdiction} />
                      {event.is_court_decision_or_enforcement && (
                        <Badge className="bg-amber-500 text-white">Deep Analysis</Badge>
                      )}
                    </div>

                    <h3 className="font-semibold text-slate-900 group-hover:text-blue-700 transition-colors line-clamp-2 mb-2 text-lg">
                      {event.title}
                    </h3>

                    {event.involved_parties?.length > 0 && (
                      <div className="flex items-center gap-2 text-sm text-slate-600 mb-3">
                        <Building2 className="h-4 w-4 text-slate-400 shrink-0" />
                        <span className="line-clamp-1">{event.involved_parties.join(' • ')}</span>
                      </div>
                    )}

                    <div className="flex flex-wrap gap-2 mb-3">
                      {event.enforcement_type && (
                        <Badge variant="outline" className="text-xs">{event.enforcement_type}</Badge>
                      )}
                      {event.legal_field && (
                        <Badge variant="outline" className="text-xs">{event.legal_field}</Badge>
                      )}
                    </div>

                    {event.possible_implications && (
                      <p className="text-sm text-slate-600 line-clamp-2 mb-3">
                        <span className="font-medium text-slate-700">SaaS Impact:</span> {event.possible_implications}
                      </p>
                    )}

                    {event.trend_analysis && (
                      <div className="flex items-start gap-2 text-xs text-slate-500 bg-slate-50 rounded-lg p-2">
                        <TrendingUp className="h-3.5 w-3.5 mt-0.5 shrink-0 text-blue-500" />
                        <span className="line-clamp-2">{event.trend_analysis}</span>
                      </div>
                    )}

                    <div className="flex items-center gap-4 mt-3 text-xs text-slate-500">
                      <span>{event.source}</span>
                      {event.publish_date && (
                        <span>{format(new Date(event.publish_date), "MMMM d, yyyy")}</span>
                      )}
                    </div>
                  </div>

                  <ChevronRight className="h-5 w-5 text-slate-400 group-hover:text-blue-600 transition-colors shrink-0 mt-2" />
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      <UpdateDetailModal
        update={selectedUpdate}
        open={!!selectedUpdate}
        onClose={() => setSelectedUpdate(null)}
        onStatusChange={handleStatusChange}
        allUpdates={updates}
        onSelectUpdate={setSelectedUpdate}
      />
    </div>
  );
}