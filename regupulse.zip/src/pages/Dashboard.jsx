import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { FileText, Sparkles } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

import TopBar from "@/components/layout/TopBar";
import DeadlineCalendar from "@/components/compliance/DeadlineCalendar";
import FilterBar from "@/components/compliance/FilterBar";
import UpdateCard from "@/components/compliance/UpdateCard";
import UpdateDetailModal from "@/components/compliance/UpdateDetailModal";
import RelevanceFeedbackDialog from "@/components/compliance/RelevanceFeedbackDialog";
import ScanButton from "@/components/compliance/ScanButton";
import ScanActivityPanel from "@/components/compliance/ScanActivityPanel";
import WidgetContainer, { DEFAULT_WIDGETS } from "@/components/dashboard/WidgetContainer";
import ComplianceReportGenerator from "@/components/reports/ComplianceReportGenerator";
import UserPreferencesDialog from "@/components/settings/UserPreferencesDialog";

export default function Dashboard() {
  const queryClient = useQueryClient();
  const [selectedUpdate, setSelectedUpdate] = useState(null);
  const [relevanceUpdate, setRelevanceUpdate] = useState(null);
  const [filters, setFilters] = useState({
    search: "",
    domain: "All Domains",
    jurisdiction: "All Jurisdictions",
    updateType: "All Types",
    dateFrom: null
  });
  const [lastScanInfo, setLastScanInfo] = useState(null);
  
  // Fetch current user for personalization
  const { data: currentUser, refetch: refetchUser } = useQuery({
    queryKey: ['current-user'],
    queryFn: () => base44.auth.me()
  });
  
  // Check for openScan URL parameter
  const urlParams = new URLSearchParams(window.location.search);
  const shouldAutoOpenScan = urlParams.get('openScan') === 'true';
  
  useEffect(() => {
    if (shouldAutoOpenScan) {
      // Clean up URL after reading param
      window.history.replaceState({}, '', window.location.pathname);
    }
  }, []);

  // Fetch dashboard config
  const { data: dashboardConfigs = [] } = useQuery({
    queryKey: ['dashboard-config'],
    queryFn: () => base44.entities.DashboardConfig.list()
  });

  const dashboardConfig = dashboardConfigs[0] || { widgets: DEFAULT_WIDGETS };

  const saveConfigMutation = useMutation({
    mutationFn: async (config) => {
      if (dashboardConfigs.length > 0) {
        return base44.entities.DashboardConfig.update(dashboardConfigs[0].id, config);
      } else {
        return base44.entities.DashboardConfig.create(config);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dashboard-config'] });
    }
  });

  const handleConfigChange = (config) => {
    saveConfigMutation.mutate(config);
  };

  const { data: rawUpdates = [], isLoading } = useQuery({
    queryKey: ['regulatory-updates'],
    queryFn: async () => {
      const allUpdates = await base44.entities.RegulatoryUpdate.list();
      const now = new Date();
      const sevenDaysAgoFromNow = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

      const filtered = allUpdates.filter(update => {
        const publishDate = update.publish_date ? new Date(update.publish_date) : null;
        const scanDate = update.scan_date ? new Date(update.scan_date) : null;

        if (publishDate && scanDate) {
          const sevenDaysBeforeScan = new Date(scanDate);
          sevenDaysBeforeScan.setDate(scanDate.getDate() - 7);
          return publishDate >= sevenDaysBeforeScan && publishDate <= scanDate;
        } else if (publishDate) {
          return publishDate >= sevenDaysAgoFromNow;
        }
        return false;
      });

      return filtered.sort((a, b) => {
        const dateA = a.publish_date ? new Date(a.publish_date) : new Date(0);
        const dateB = b.publish_date ? new Date(b.publish_date) : new Date(0);
        return dateB - dateA;
      });
    }
  });

  // Remove duplicates - keep first occurrence of each unique title or URL
  const updates = rawUpdates.filter((update, index, self) => {
    const normalizedTitle = update.title?.toLowerCase().trim();
    const normalizedUrl = update.source_url?.toLowerCase().trim();
    
    // Find first index where title OR url matches
    const firstIndex = self.findIndex(u => {
      const uTitle = u.title?.toLowerCase().trim();
      const uUrl = u.source_url?.toLowerCase().trim();
      // Match if titles are same, OR if both have URLs and they're same
      return uTitle === normalizedTitle || 
             (normalizedUrl && uUrl && uUrl === normalizedUrl);
    });
    
    return index === firstIndex;
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, status }) => base44.entities.RegulatoryUpdate.update(id, { status }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['regulatory-updates'] })
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.RegulatoryUpdate.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['regulatory-updates'] })
  });

  const handleDelete = (id) => {
    if (window.confirm("Remove this update from the dashboard?")) {
      deleteMutation.mutate(id);
    }
  };

  const handleStatusChange = (id, status) => {
    updateMutation.mutate({ id, status });
    setSelectedUpdate(prev => prev ? { ...prev, status } : null);
  };

  const legalTypes = ["Enforcement", "Ruling", "Court Filing", "Class Action"];
  
  // Apply user personalization preferences
  const applyPersonalization = (updatesList) => {
    if (!currentUser || currentUser.dashboard_view !== "personalized") {
      return updatesList;
    }
    
    return updatesList.filter(update => {
      // Filter by preferred jurisdictions
      if (currentUser.preferred_jurisdictions?.length > 0) {
        if (!currentUser.preferred_jurisdictions.includes(update.jurisdiction)) {
          return false;
        }
      }
      
      // Filter by preferred domains
      if (currentUser.preferred_domains?.length > 0) {
        if (!currentUser.preferred_domains.includes(update.domain)) {
          return false;
        }
      }
      
      // Filter by risk threshold
      if (currentUser.risk_threshold === "high_only" && update.risk_score !== "High") {
        return false;
      }
      if (currentUser.risk_threshold === "medium_high" && update.risk_score === "Low") {
        return false;
      }
      
      return true;
    });
  };
  
  const personalizedUpdates = applyPersonalization(updates);
  
  const filteredUpdates = personalizedUpdates.filter(update => {
    if (filters.search && !update.title.toLowerCase().includes(filters.search.toLowerCase()) &&
        !update.summary?.toLowerCase().includes(filters.search.toLowerCase())) return false;
    if (filters.domain !== "All Domains" && update.domain !== filters.domain) return false;
    if (filters.jurisdiction !== "All Jurisdictions" && update.jurisdiction !== filters.jurisdiction) return false;
    if (filters.dateFrom) {
      const updateDate = new Date(update.publish_date || update.created_date);
      if (updateDate < filters.dateFrom) return false;
    }
    if (filters.updateType !== "All Types") {
      if (update.update_type !== filters.updateType) return false;
    } else {
      if (legalTypes.includes(update.update_type)) return false;
    }
    return true;
  });

  return (
    <div className="min-h-screen bg-slate-50">
      <TopBar 
        title="Dashboard" 
        subtitle="AI-powered regulatory monitoring for global SaaS compliance"
        actions={
                        <div className="flex items-center gap-2">
                          <UserPreferencesDialog user={currentUser} onUpdate={refetchUser} />
                          <ComplianceReportGenerator updates={updates} />
                          <ScanButton 
                            autoOpen={shouldAutoOpenScan}
                            onScanComplete={(result) => {
                              setLastScanInfo(result);
                              queryClient.invalidateQueries({ queryKey: ['regulatory-updates'] });
                            }} 
                          />
                        </div>
                      }
      />

      <div className="p-6">
        {/* Customizable Widgets */}
        <div className="mb-6">
          <WidgetContainer 
            updates={personalizedUpdates} 
            config={dashboardConfig}
            onConfigChange={handleConfigChange}
          />
        </div>

        {/* Calendar */}
        {personalizedUpdates.length > 0 && (
          <div className="mb-6">
            <DeadlineCalendar updates={personalizedUpdates} onSelectUpdate={setSelectedUpdate} />
          </div>
        )}

        {/* Filters & Updates */}
        <FilterBar filters={filters} setFilters={setFilters} />

        <div className="mt-6 space-y-4">
          {isLoading ? (
            Array(3).fill(0).map((_, i) => (
              <Skeleton key={i} className="h-32 rounded-xl" />
            ))
          ) : filteredUpdates.length === 0 ? (
            <Card className="p-12 text-center">
              <FileText className="h-12 w-12 text-slate-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-slate-900 mb-2">
                {updates.length === 0 ? "No regulatory updates yet" : "No matching updates"}
              </h3>
              <p className="text-slate-500 max-w-md mx-auto">
                {updates.length === 0 
                  ? "Run a compliance scan to fetch the latest regulatory updates."
                  : "Try adjusting your filters to see more results."}
              </p>
            </Card>
          ) : (
            <>
              <div className="flex items-center justify-between">
                <p className="text-sm text-slate-500">
                  Showing {filteredUpdates.length} of {personalizedUpdates.length} updates
                  {currentUser?.dashboard_view === "personalized" && (
                    <span className="ml-2 text-blue-600">(Personalized)</span>
                  )}
                </p>
                <Link to={createPageUrl("Updates")}>
                  <Button variant="outline" size="sm">View All</Button>
                </Link>
              </div>
              {filteredUpdates.slice(0, 10).map(update => (
                  <UpdateCard 
                    key={update.id} 
                    update={update} 
                    onClick={() => setSelectedUpdate(update)}
                    onDelete={handleDelete}
                    onMarkRelevance={(u) => setRelevanceUpdate(u)}
                  />
                ))}
              {filteredUpdates.length > 10 && (
                <div className="text-center pt-4">
                  <Link to={createPageUrl("Updates")}>
                    <Button variant="outline">
                      View all {filteredUpdates.length} updates
                    </Button>
                  </Link>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      <UpdateDetailModal
                update={selectedUpdate}
                open={!!selectedUpdate}
                onClose={() => setSelectedUpdate(null)}
                onStatusChange={handleStatusChange}
                allUpdates={updates}
                onSelectUpdate={setSelectedUpdate}
              />

              <RelevanceFeedbackDialog
                update={relevanceUpdate}
                open={!!relevanceUpdate}
                onClose={() => setRelevanceUpdate(null)}
              />
            </div>
          );
        }