import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Download, 
  FileText, 
  FileSpreadsheet, 
  FileJson, 
  Calendar,
  Filter,
  CheckCircle2,
  FileType
} from "lucide-react";
import PdfExporter from "@/components/reports/PdfExporter";
import { format, subDays } from "date-fns";
import { toast } from "sonner";
import TopBar from "@/components/layout/TopBar";

const exportFields = [
  { id: "title", label: "Title", default: true },
  { id: "source", label: "Source", default: true },
  { id: "domain", label: "Domain", default: true },
  { id: "jurisdiction", label: "Jurisdiction", default: true },
  { id: "risk_score", label: "Risk Score", default: true },
  { id: "update_type", label: "Update Type", default: true },
  { id: "status", label: "Status", default: true },
  { id: "summary", label: "Summary", default: true },
  { id: "compliance_actions", label: "Compliance Actions", default: false },
  { id: "key_dates", label: "Key Dates", default: false },
  { id: "affected_areas", label: "Affected Areas", default: false },
  { id: "publish_date", label: "Publish Date", default: true },
  { id: "source_url", label: "Source URL", default: false }
];

const dateRanges = [
  { value: "7", label: "Last 7 days" },
  { value: "30", label: "Last 30 days" },
  { value: "90", label: "Last 90 days" },
  { value: "all", label: "All time" }
];

export default function Reports() {
  const [selectedFields, setSelectedFields] = useState(
    exportFields.filter(f => f.default).map(f => f.id)
  );
  const [exportFormat, setExportFormat] = useState("csv");
  const [dateRange, setDateRange] = useState("30");
  const [filterDomain, setFilterDomain] = useState("all");
  const [filterRisk, setFilterRisk] = useState("all");
  const [pdfDialogOpen, setPdfDialogOpen] = useState(false);

  const { data: updates = [], isLoading } = useQuery({
    queryKey: ['export-updates'],
    queryFn: () => base44.entities.RegulatoryUpdate.list('-publish_date')
  });

  // Filter updates based on criteria
  const filteredUpdates = updates.filter(update => {
    // Date filter
    if (dateRange !== "all") {
      const cutoff = subDays(new Date(), parseInt(dateRange));
      const updateDate = new Date(update.publish_date || update.created_date);
      if (updateDate < cutoff) return false;
    }
    
    // Domain filter
    if (filterDomain !== "all" && update.domain !== filterDomain) return false;
    
    // Risk filter
    if (filterRisk !== "all" && update.risk_score !== filterRisk) return false;
    
    return true;
  });

  const toggleField = (fieldId) => {
    setSelectedFields(prev => 
      prev.includes(fieldId) 
        ? prev.filter(f => f !== fieldId)
        : [...prev, fieldId]
    );
  };

  const selectAllFields = () => setSelectedFields(exportFields.map(f => f.id));
  const deselectAllFields = () => setSelectedFields([]);

  const handleExport = () => {
    if (selectedFields.length === 0) {
      toast.error("Please select at least one field to export");
      return;
    }

    const data = filteredUpdates.map(update => {
      const row = {};
      selectedFields.forEach(field => {
        let value = update[field];
        if (Array.isArray(value)) {
          value = value.join("; ");
        }
        row[field] = value || "";
      });
      return row;
    });

    if (exportFormat === "csv") {
      const headers = selectedFields.join(",");
      const rows = data.map(row => 
        selectedFields.map(field => {
          let val = row[field] || "";
          if (typeof val === "string" && (val.includes(",") || val.includes('"') || val.includes("\n"))) {
            val = `"${val.replace(/"/g, '""')}"`;
          }
          return val;
        }).join(",")
      );
      const csv = [headers, ...rows].join("\n");
      downloadFile(csv, `compliance-report-${format(new Date(), "yyyy-MM-dd")}.csv`, "text/csv");
    } else {
      const json = JSON.stringify(data, null, 2);
      downloadFile(json, `compliance-report-${format(new Date(), "yyyy-MM-dd")}.json`, "application/json");
    }

    toast.success(`Exported ${data.length} updates as ${exportFormat.toUpperCase()}`);
  };

  const downloadFile = (content, filename, mimeType) => {
    const blob = new Blob([content], { type: mimeType });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <TopBar 
        title="Reports & Export" 
        subtitle="Generate and download compliance reports"
      />

      <div className="p-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Export Config */}
          <div className="lg:col-span-2 space-y-6">
            {/* Format Selection */}
            <Card className="p-6">
              <h3 className="font-semibold text-slate-900 mb-4">Export Format</h3>
              <Tabs value={exportFormat} onValueChange={setExportFormat}>
                <TabsList className="grid grid-cols-3 w-full max-w-md">
                  <TabsTrigger value="csv" className="flex items-center gap-2">
                    <FileSpreadsheet className="h-4 w-4" />
                    CSV
                  </TabsTrigger>
                  <TabsTrigger value="json" className="flex items-center gap-2">
                    <FileJson className="h-4 w-4" />
                    JSON
                  </TabsTrigger>
                  <TabsTrigger value="pdf" className="flex items-center gap-2">
                    <FileType className="h-4 w-4" />
                    PDF
                  </TabsTrigger>
                </TabsList>
              </Tabs>
              {exportFormat === "pdf" && (
                <p className="text-sm text-slate-500 mt-3">
                  PDF exports include professional styling, executive summary, and visual charts.
                </p>
              )}
            </Card>

            {/* Filters */}
            <Card className="p-6">
              <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
                <Filter className="h-4 w-4" />
                Filters
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <Label className="text-sm text-slate-600 mb-2 block">Date Range</Label>
                  <Select value={dateRange} onValueChange={setDateRange}>
                    <SelectTrigger>
                      <Calendar className="h-4 w-4 mr-2" />
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {dateRanges.map(r => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label className="text-sm text-slate-600 mb-2 block">Domain</Label>
                  <Select value={filterDomain} onValueChange={setFilterDomain}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Domains</SelectItem>
                      <SelectItem value="AI Law">AI Law</SelectItem>
                      <SelectItem value="Privacy">Privacy</SelectItem>
                      <SelectItem value="Antitrust">Antitrust</SelectItem>
                      <SelectItem value="Consumer Protection">Consumer Protection</SelectItem>
                      <SelectItem value="Platform Liability">Platform Liability</SelectItem>
                      <SelectItem value="IP">IP</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label className="text-sm text-slate-600 mb-2 block">Risk Level</Label>
                  <Select value={filterRisk} onValueChange={setFilterRisk}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Risk Levels</SelectItem>
                      <SelectItem value="High">High</SelectItem>
                      <SelectItem value="Medium">Medium</SelectItem>
                      <SelectItem value="Low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </Card>

            {/* Field Selection */}
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-slate-900">Fields to Export</h3>
                <div className="flex gap-2">
                  <Button variant="ghost" size="sm" onClick={selectAllFields}>Select All</Button>
                  <Button variant="ghost" size="sm" onClick={deselectAllFields}>Clear All</Button>
                </div>
              </div>
              
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {exportFields.map(field => (
                  <div key={field.id} className="flex items-center space-x-2">
                    <Checkbox 
                      id={field.id}
                      checked={selectedFields.includes(field.id)}
                      onCheckedChange={() => toggleField(field.id)}
                    />
                    <Label htmlFor={field.id} className="text-sm cursor-pointer">
                      {field.label}
                    </Label>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Preview & Export */}
          <div className="space-y-6">
            <Card className="p-6">
              <h3 className="font-semibold text-slate-900 mb-4">Export Summary</h3>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between py-2 border-b">
                  <span className="text-sm text-slate-600">Format</span>
                  <Badge variant="outline">{exportFormat.toUpperCase()}</Badge>
                </div>
                
                <div className="flex items-center justify-between py-2 border-b">
                  <span className="text-sm text-slate-600">Updates to export</span>
                  <span className="font-semibold text-slate-900">{filteredUpdates.length}</span>
                </div>
                
                <div className="flex items-center justify-between py-2 border-b">
                  <span className="text-sm text-slate-600">Fields selected</span>
                  <span className="font-semibold text-slate-900">{selectedFields.length}</span>
                </div>
                
                <div className="flex items-center justify-between py-2">
                  <span className="text-sm text-slate-600">Date range</span>
                  <span className="text-sm text-slate-900">
                    {dateRanges.find(r => r.value === dateRange)?.label}
                  </span>
                </div>
              </div>
              
              <Button 
                className="w-full mt-6 bg-gradient-to-r from-blue-600 to-violet-600"
                onClick={exportFormat === "pdf" ? () => setPdfDialogOpen(true) : handleExport}
                disabled={filteredUpdates.length === 0 || selectedFields.length === 0}
              >
                <Download className="h-4 w-4 mr-2" />
                {exportFormat === "pdf" ? "Configure PDF Export" : "Export Report"}
              </Button>
            </Card>

            {/* Quick Stats */}
            <Card className="p-6 bg-gradient-to-br from-blue-50 to-violet-50 border-blue-100">
              <h3 className="font-semibold text-slate-900 mb-3">Data Overview</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-600">High Risk</span>
                  <span className="font-medium text-red-600">
                    {filteredUpdates.filter(u => u.risk_score === "High").length}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Medium Risk</span>
                  <span className="font-medium text-amber-600">
                    {filteredUpdates.filter(u => u.risk_score === "Medium").length}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Low Risk</span>
                  <span className="font-medium text-emerald-600">
                    {filteredUpdates.filter(u => u.risk_score === "Low").length}
                  </span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>

      <PdfExporter 
        updates={filteredUpdates}
        selectedFields={selectedFields}
        open={pdfDialogOpen}
        onClose={() => setPdfDialogOpen(false)}
      />
    </div>
  );
}