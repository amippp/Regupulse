import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Mail, 
  Plus, 
  X, 
  Send,
  Users,
  Calendar,
  CheckCircle2
} from "lucide-react";
import { toast } from "sonner";
import TopBar from "@/components/layout/TopBar";

const daysOfWeek = [
  { value: "monday", label: "Monday" },
  { value: "tuesday", label: "Tuesday" },
  { value: "wednesday", label: "Wednesday" },
  { value: "thursday", label: "Thursday" },
  { value: "friday", label: "Friday" }
];

export default function DigestSettings() {
  const queryClient = useQueryClient();
  const [newEmail, setNewEmail] = useState("");
  
  const { data: schedules = [], isLoading } = useQuery({
    queryKey: ['digest-settings'],
    queryFn: () => base44.entities.ScanSchedule.list()
  });

  const schedule = schedules[0] || null;

  const [settings, setSettings] = useState({
    digest_enabled: false,
    day_of_week: "monday",
    digest_emails: []
  });

  useEffect(() => {
    if (schedule) {
      setSettings({
        digest_enabled: schedule.digest_enabled ?? false,
        day_of_week: schedule.day_of_week || "monday",
        digest_emails: schedule.digest_emails || []
      });
    }
  }, [schedule]);

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      if (schedule) {
        return base44.entities.ScanSchedule.update(schedule.id, data);
      } else {
        return base44.entities.ScanSchedule.create({ ...data, frequency: "weekly" });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['digest-settings'] });
      toast.success("Digest settings saved");
    }
  });

  const addEmail = () => {
    if (!newEmail || !newEmail.includes("@")) {
      toast.error("Please enter a valid email");
      return;
    }
    if (settings.digest_emails.includes(newEmail)) {
      toast.error("Email already added");
      return;
    }
    setSettings({ ...settings, digest_emails: [...settings.digest_emails, newEmail] });
    setNewEmail("");
  };

  const removeEmail = (email) => {
    setSettings({ 
      ...settings, 
      digest_emails: settings.digest_emails.filter(e => e !== email) 
    });
  };

  const handleSave = () => {
    if (settings.digest_enabled && settings.digest_emails.length === 0) {
      toast.error("Please add at least one recipient email");
      return;
    }
    saveMutation.mutate(settings);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <TopBar 
        title="Weekly Digest" 
        subtitle="Configure email digest settings"
      />

      <div className="p-6 max-w-4xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Configuration */}
          <Card className="p-6">
            <h3 className="font-semibold text-slate-900 mb-6 flex items-center gap-2">
              <Mail className="h-5 w-5 text-blue-600" />
              Digest Configuration
            </h3>

            <div className="space-y-6">
              {/* Enable Toggle */}
              <div className="flex items-center justify-between p-4 rounded-lg bg-slate-50">
                <div>
                  <Label className="font-medium">Enable Weekly Digest</Label>
                  <p className="text-sm text-slate-500">Send a summary of updates via email</p>
                </div>
                <Switch 
                  checked={settings.digest_enabled}
                  onCheckedChange={(checked) => setSettings({ ...settings, digest_enabled: checked })}
                />
              </div>

              {/* Day of Week */}
              <div className="space-y-2">
                <Label>Send On</Label>
                <Select 
                  value={settings.day_of_week} 
                  onValueChange={(v) => setSettings({ ...settings, day_of_week: v })}
                  disabled={!settings.digest_enabled}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {daysOfWeek.map(day => (
                      <SelectItem key={day.value} value={day.value}>{day.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Recipients */}
              <div className="space-y-3">
                <Label>Recipients</Label>
                <div className="flex gap-2">
                  <Input 
                    placeholder="Enter email address"
                    value={newEmail}
                    onChange={(e) => setNewEmail(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && addEmail()}
                    disabled={!settings.digest_enabled}
                  />
                  <Button 
                    onClick={addEmail} 
                    disabled={!settings.digest_enabled}
                    variant="outline"
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>

                {settings.digest_emails.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-3">
                    {settings.digest_emails.map(email => (
                      <Badge 
                        key={email} 
                        variant="secondary"
                        className="flex items-center gap-1 py-1.5 px-3"
                      >
                        {email}
                        <X 
                          className="h-3 w-3 ml-1 cursor-pointer hover:text-red-600" 
                          onClick={() => removeEmail(email)}
                        />
                      </Badge>
                    ))}
                  </div>
                )}
              </div>

              <Button 
                onClick={handleSave} 
                className="w-full"
                disabled={saveMutation.isPending}
              >
                {saveMutation.isPending ? "Saving..." : "Save Settings"}
              </Button>
            </div>
          </Card>

          {/* Preview */}
          <div className="space-y-6">
            <Card className="p-6">
              <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
                <Send className="h-5 w-5 text-blue-600" />
                Digest Status
              </h3>

              <div className="space-y-4">
                <div className="flex items-center justify-between py-3 border-b">
                  <span className="text-slate-600">Status</span>
                  <Badge className={settings.digest_enabled ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-700"}>
                    {settings.digest_enabled ? "Enabled" : "Disabled"}
                  </Badge>
                </div>

                <div className="flex items-center justify-between py-3 border-b">
                  <span className="text-slate-600">Send Day</span>
                  <span className="font-medium text-slate-900 capitalize">{settings.day_of_week}</span>
                </div>

                <div className="flex items-center justify-between py-3">
                  <span className="text-slate-600">Recipients</span>
                  <span className="font-medium text-slate-900">{settings.digest_emails.length}</span>
                </div>
              </div>
            </Card>

            {/* What's Included */}
            <Card className="p-6 bg-gradient-to-br from-blue-50 to-violet-50 border-blue-100">
              <h3 className="font-semibold text-slate-900 mb-4">What's Included</h3>
              <ul className="space-y-2 text-sm text-slate-600">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                  New regulatory updates from the past week
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                  High-risk alerts and action items
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                  Upcoming compliance deadlines
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                  Legal events and enforcement actions
                </li>
              </ul>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}