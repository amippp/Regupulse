import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { 
  Activity, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  RefreshCw, 
  Rss, 
  Globe,
  RotateCcw,
  Search,
  ExternalLink,
  Clock,
  Zap,
  Trash2,
  Settings2
} from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import TopBar from "@/components/layout/TopBar";
import AddSourceDialog from "@/components/sources/AddSourceDialog";
import EditSourceDialog from "@/components/sources/EditSourceDialog";
import SourceItemsModal from "@/components/sources/SourceItemsModal";
import SourceLibrary from "@/components/sources/SourceLibrary";

export default function Sources() {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("all");
  const [viewMode, setViewMode] = useState("health"); // "health" or "configured"
  const [retryingSource, setRetryingSource] = useState(null);
  const [viewItems, setViewItems] = useState(null); // name of source to view items for

  const { data: sources = [], isLoading, refetch } = useQuery({
    queryKey: ['sources'],
    queryFn: () => base44.entities.SourceHealth.list('-last_check')
  });

  const { data: configuredSources = [], isLoading: loadingConfigured } = useQuery({
    queryKey: ['compliance-sources'],
    queryFn: () => base44.entities.ComplianceSource.list()
  });

  const toggleSourceMutation = useMutation({
    mutationFn: ({ id, is_active }) => base44.entities.ComplianceSource.update(id, { is_active }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['compliance-sources'] });
      toast.success("Source updated");
    }
  });

  const deleteSourceMutation = useMutation({
    mutationFn: (id) => base44.entities.ComplianceSource.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['compliance-sources'] });
      toast.success("Source removed");
    }
  });

  const healthyCount = sources.filter(s => s.status === "healthy").length;
  const degradedCount = sources.filter(s => s.status === "degraded").length;
  const failingCount = sources.filter(s => s.status === "failing").length;

  const handleRetrySource = async (source) => {
    setRetryingSource(source.id);
    try {
      const response = await base44.functions.invoke('scanRssFeeds');
      if (response.data.success) {
        toast.success("Sources re-scanned successfully");
        queryClient.invalidateQueries({ queryKey: ['sources'] });
      } else {
        toast.error("Retry failed");
      }
    } catch (error) {
      toast.error("Failed to retry: " + error.message);
    } finally {
      setRetryingSource(null);
    }
  };

  const filteredSources = sources.filter(source => {
    if (searchQuery && !source.source_name?.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    if (activeTab === "healthy" && source.status !== "healthy") return false;
    if (activeTab === "degraded" && source.status !== "degraded") return false;
    if (activeTab === "failing" && source.status !== "failing") return false;
    return true;
  });

  const statusConfig = {
    healthy: { icon: CheckCircle2, color: "text-emerald-600", bg: "bg-emerald-100", borderColor: "border-emerald-200" },
    degraded: { icon: AlertTriangle, color: "text-amber-600", bg: "bg-amber-100", borderColor: "border-amber-200" },
    failing: { icon: XCircle, color: "text-red-600", bg: "bg-red-100", borderColor: "border-red-200" }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <TopBar 
        title="Source Management" 
        subtitle="Monitor and manage compliance data sources"
        actions={
          <div className="flex items-center gap-2">
            <SourceLibrary existingSources={configuredSources} onSourcesAdded={() => refetch()} />
            <AddSourceDialog onSourceAdded={() => refetch()} />
            <Button onClick={() => refetch()} variant="outline">
              <RefreshCw className={cn("h-4 w-4 mr-2", isLoading && "animate-spin")} />
              Refresh
            </Button>
          </div>
        }
      />

      <div className="p-6">
        {/* View Mode Toggle */}
        <div className="flex gap-2 mb-6">
          <Button 
            variant={viewMode === "health" ? "default" : "outline"}
            onClick={() => setViewMode("health")}
            className="gap-2"
          >
            <Activity className="h-4 w-4" />
            Source Health
          </Button>
          <Button 
            variant={viewMode === "configured" ? "default" : "outline"}
            onClick={() => setViewMode("configured")}
            className="gap-2"
          >
            <Settings2 className="h-4 w-4" />
            Configured Sources ({configuredSources.length})
          </Button>
        </div>

        {viewMode === "health" ? (
          <>
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-slate-100">
                <Activity className="h-5 w-5 text-slate-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-slate-900">{sources.length}</p>
                <p className="text-xs text-slate-500">Total Sources</p>
              </div>
            </div>
          </Card>
          <Card className="p-4 bg-emerald-50 border-emerald-100">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-100">
                <CheckCircle2 className="h-5 w-5 text-emerald-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-emerald-700">{healthyCount}</p>
                <p className="text-xs text-emerald-600">Healthy</p>
              </div>
            </div>
          </Card>
          <Card className="p-4 bg-amber-50 border-amber-100">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-100">
                <AlertTriangle className="h-5 w-5 text-amber-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-amber-700">{degradedCount}</p>
                <p className="text-xs text-amber-600">Degraded</p>
              </div>
            </div>
          </Card>
          <Card className="p-4 bg-red-50 border-red-100">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-red-100">
                <XCircle className="h-5 w-5 text-red-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-red-700">{failingCount}</p>
                <p className="text-xs text-red-600">Failing</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <Input
              placeholder="Search sources..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="all">All ({sources.length})</TabsTrigger>
              <TabsTrigger value="healthy">Healthy</TabsTrigger>
              <TabsTrigger value="degraded">Degraded</TabsTrigger>
              <TabsTrigger value="failing">Failing</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {/* Sources List */}
        {isLoading ? (
          <div className="space-y-3">
            {Array(5).fill(0).map((_, i) => <Skeleton key={i} className="h-24 rounded-xl" />)}
          </div>
        ) : filteredSources.length === 0 ? (
          <Card className="p-12 text-center">
            <Activity className="h-12 w-12 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-slate-900 mb-2">No sources found</h3>
            <p className="text-slate-500">Run a compliance scan to populate source health data.</p>
          </Card>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {filteredSources.map(source => {
              const config = statusConfig[source.status] || statusConfig.healthy;
              const Icon = config.icon;
              const isRetrying = retryingSource === source.id;
              
              return (
                <Card 
                  key={source.id}
                  className={cn(
                    "p-4 transition-all hover:shadow-md",
                    source.status === "failing" && "border-red-200 bg-red-50/50",
                    source.status === "degraded" && "border-amber-200 bg-amber-50/50"
                  )}
                >
                  <div className="flex items-start gap-4">
                    <div className={cn("p-3 rounded-xl", config.bg)}>
                      {source.source_type === "rss" ? (
                        <Rss className={cn("h-6 w-6", config.color)} />
                      ) : (
                        <Globe className={cn("h-6 w-6", config.color)} />
                      )}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-slate-900">{source.source_name}</h3>
                        <Badge variant="outline" className={cn(config.color, "border-current text-xs")}>
                          {source.status}
                        </Badge>
                      </div>
                      
                      <a 
                        href={source.source_url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-sm text-blue-600 hover:underline flex items-center gap-1 mb-2"
                      >
                        {source.source_url?.substring(0, 50)}...
                        <ExternalLink className="h-3 w-3" />
                      </a>
                      
                      {source.error_message && (
                        <div className="bg-red-100 text-red-700 text-xs px-2 py-1 rounded mb-2">
                          {source.error_message}
                        </div>
                      )}
                      
                      <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500">
                        {source.last_check && (
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            Checked {formatDistanceToNow(new Date(source.last_check), { addSuffix: true })}
                          </span>
                        )}
                        {source.items_fetched > 0 && (
                          <button 
                            className="flex items-center gap-1 hover:text-blue-600 hover:underline cursor-pointer"
                            onClick={() => setViewItems(source.source_name)}
                          >
                            <Zap className="h-3 w-3" />
                            {source.items_fetched} items fetched
                          </button>
                        )}
                        {source.consecutive_failures > 0 && (
                          <span className="text-red-600">
                            {source.consecutive_failures} consecutive failures
                          </span>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex flex-col gap-2">
                        {(source.status === "failing" || source.status === "degraded") && (
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleRetrySource(source)}
                            disabled={isRetrying}
                        >
                            <RotateCcw className={cn("h-4 w-4 mr-1", isRetrying && "animate-spin")} />
                            Retry
                        </Button>
                        )}
                         <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setViewItems(source.source_name)}
                            className="text-xs text-slate-500"
                        >
                            View Items
                        </Button>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
        </>
        ) : (
          /* Configured Sources View */
          <div className="space-y-4">
            {loadingConfigured ? (
              <div className="space-y-3">
                {Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-20 rounded-xl" />)}
              </div>
            ) : configuredSources.length === 0 ? (
              <Card className="p-12 text-center">
                <Settings2 className="h-12 w-12 text-slate-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-slate-900 mb-2">No custom sources configured</h3>
                <p className="text-slate-500 mb-4">Add sources from the library or create custom ones.</p>
                <div className="flex justify-center gap-2">
                  <SourceLibrary existingSources={configuredSources} />
                  <AddSourceDialog />
                </div>
              </Card>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {configuredSources.map(source => (
                  <Card key={source.id} className={cn("p-4", !source.is_active && "opacity-60")}>
                    <div className="flex items-start gap-4">
                      <div className={cn(
                        "p-3 rounded-xl",
                        source.type === "rss" ? "bg-blue-100" : 
                        source.type === "api" ? "bg-violet-100" : "bg-emerald-100"
                      )}>
                        {source.type === "rss" ? <Rss className="h-5 w-5 text-blue-600" /> :
                         source.type === "api" ? <Zap className="h-5 w-5 text-violet-600" /> :
                         <Globe className="h-5 w-5 text-emerald-600" />}
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold text-slate-900">{source.name}</h3>
                          <Badge variant="outline">{source.region || "Global"}</Badge>
                          <Badge variant="secondary" className="text-xs">{source.type}</Badge>
                        </div>
                        
                        <a 
                          href={source.url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-sm text-blue-600 hover:underline flex items-center gap-1 mb-2"
                        >
                          {source.url?.substring(0, 45)}...
                          <ExternalLink className="h-3 w-3" />
                        </a>
                        
                        <div className="flex items-center gap-4 text-xs text-slate-500">
                          {source.category && (
                            <Badge variant="outline" className="text-xs">{source.category}</Badge>
                          )}
                          {source.fetch_count > 0 && (
                            <span>{source.fetch_count} items fetched</span>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={source.is_active}
                          onCheckedChange={(checked) => toggleSourceMutation.mutate({ id: source.id, is_active: checked })}
                        />
                        <EditSourceDialog source={source} onSourceUpdated={() => refetch()} />
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-red-500 hover:text-red-600 hover:bg-red-50"
                          onClick={() => {
                            if (confirm("Remove this source?")) {
                              deleteSourceMutation.mutate(source.id);
                            }
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      <SourceItemsModal 
        sourceName={viewItems} 
        open={!!viewItems} 
        onClose={() => setViewItems(null)} 
      />
    </div>
  );
}