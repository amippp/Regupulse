import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Bell, 
  Mail, 
  AlertTriangle, 
  Activity, 
  Calendar, 
  FileText,
  Clock,
  Save,
  Loader2
} from "lucide-react";
import { toast } from "sonner";
import TopBar from "@/components/layout/TopBar";

export default function NotificationSettings() {
  const queryClient = useQueryClient();
  
  const { data: user } = useQuery({
    queryKey: ['current-user'],
    queryFn: () => base44.auth.me()
  });

  const { data: preferences, isLoading } = useQuery({
    queryKey: ['notification-preferences', user?.email],
    queryFn: async () => {
      const prefs = await base44.entities.NotificationPreferences.filter({ user_email: user?.email });
      return prefs[0] || null;
    },
    enabled: !!user?.email
  });

  const [settings, setSettings] = useState({
    email_enabled: true,
    in_app_enabled: true,
    high_risk_updates: true,
    source_health_alerts: true,
    deadline_reminders: true,
    new_regulations: false,
    email_frequency: "immediate",
    quiet_hours_start: null,
    quiet_hours_end: null
  });

  useEffect(() => {
    if (preferences) {
      setSettings({
        email_enabled: preferences.email_enabled ?? true,
        in_app_enabled: preferences.in_app_enabled ?? true,
        high_risk_updates: preferences.high_risk_updates ?? true,
        source_health_alerts: preferences.source_health_alerts ?? true,
        deadline_reminders: preferences.deadline_reminders ?? true,
        new_regulations: preferences.new_regulations ?? false,
        email_frequency: preferences.email_frequency || "immediate",
        quiet_hours_start: preferences.quiet_hours_start,
        quiet_hours_end: preferences.quiet_hours_end
      });
    }
  }, [preferences]);

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      if (preferences?.id) {
        return base44.entities.NotificationPreferences.update(preferences.id, data);
      } else {
        return base44.entities.NotificationPreferences.create({
          ...data,
          user_email: user.email
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notification-preferences'] });
      toast.success("Notification preferences saved");
    },
    onError: (error) => {
      toast.error("Failed to save preferences: " + error.message);
    }
  });

  const handleSave = () => {
    saveMutation.mutate(settings);
  };

  const updateSetting = (key, value) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const notificationTypes = [
    { 
      key: "high_risk_updates", 
      label: "High-Risk Updates", 
      description: "Get notified when new high-risk regulatory updates are detected",
      icon: AlertTriangle,
      color: "text-red-600"
    },
    { 
      key: "source_health_alerts", 
      label: "Source Health Alerts", 
      description: "Get notified when compliance sources fail or become degraded",
      icon: Activity,
      color: "text-amber-600"
    },
    { 
      key: "deadline_reminders", 
      label: "Deadline Reminders", 
      description: "Get reminded about upcoming compliance deadlines",
      icon: Calendar,
      color: "text-blue-600"
    },
    { 
      key: "new_regulations", 
      label: "All New Regulations", 
      description: "Get notified about all new regulatory updates (can be noisy)",
      icon: FileText,
      color: "text-violet-600"
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <TopBar 
        title="Notification Settings" 
        subtitle="Customize how and when you receive alerts"
      />

      <div className="p-6 max-w-3xl mx-auto space-y-6">
        {isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-48 rounded-xl" />
            <Skeleton className="h-64 rounded-xl" />
          </div>
        ) : (
          <>
            {/* Delivery Channels */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="h-5 w-5" />
                  Notification Channels
                </CardTitle>
                <CardDescription>Choose how you want to receive notifications</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-blue-100">
                      <Bell className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <Label className="text-base">In-App Notifications</Label>
                      <p className="text-sm text-slate-500">Show notifications in the app</p>
                    </div>
                  </div>
                  <Switch 
                    checked={settings.in_app_enabled}
                    onCheckedChange={(v) => updateSetting("in_app_enabled", v)}
                  />
                </div>

                <Separator />

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-emerald-100">
                      <Mail className="h-5 w-5 text-emerald-600" />
                    </div>
                    <div>
                      <Label className="text-base">Email Notifications</Label>
                      <p className="text-sm text-slate-500">Receive notifications via email</p>
                    </div>
                  </div>
                  <Switch 
                    checked={settings.email_enabled}
                    onCheckedChange={(v) => updateSetting("email_enabled", v)}
                  />
                </div>

                {settings.email_enabled && (
                  <div className="ml-12 space-y-4">
                    <div className="space-y-2">
                      <Label>Email Frequency</Label>
                      <Select 
                        value={settings.email_frequency}
                        onValueChange={(v) => updateSetting("email_frequency", v)}
                      >
                        <SelectTrigger className="w-48">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="immediate">Immediate</SelectItem>
                          <SelectItem value="daily_digest">Daily Digest</SelectItem>
                          <SelectItem value="weekly_digest">Weekly Digest</SelectItem>
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-slate-500">
                        {settings.email_frequency === "immediate" 
                          ? "You'll receive emails as events occur"
                          : settings.email_frequency === "daily_digest"
                          ? "You'll receive a summary email once per day"
                          : "You'll receive a summary email once per week"}
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Notification Types */}
            <Card>
              <CardHeader>
                <CardTitle>Notification Types</CardTitle>
                <CardDescription>Select which events you want to be notified about</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {notificationTypes.map((type, index) => {
                  const Icon = type.icon;
                  return (
                    <div key={type.key}>
                      <div className="flex items-center justify-between py-2">
                        <div className="flex items-center gap-3">
                          <div className="p-2 rounded-lg bg-slate-100">
                            <Icon className={`h-5 w-5 ${type.color}`} />
                          </div>
                          <div>
                            <Label className="text-base">{type.label}</Label>
                            <p className="text-sm text-slate-500">{type.description}</p>
                          </div>
                        </div>
                        <Switch 
                          checked={settings[type.key]}
                          onCheckedChange={(v) => updateSetting(type.key, v)}
                        />
                      </div>
                      {index < notificationTypes.length - 1 && <Separator />}
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            {/* Quiet Hours */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Quiet Hours
                </CardTitle>
                <CardDescription>Set times when you don't want to receive notifications</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4">
                  <div className="space-y-2">
                    <Label>Start</Label>
                    <Select 
                      value={settings.quiet_hours_start?.toString() || "none"}
                      onValueChange={(v) => updateSetting("quiet_hours_start", v === "none" ? null : parseInt(v))}
                    >
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder="None" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        {Array.from({ length: 24 }, (_, i) => (
                          <SelectItem key={i} value={i.toString()}>
                            {i.toString().padStart(2, '0')}:00
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <span className="text-slate-400 mt-6">to</span>
                  <div className="space-y-2">
                    <Label>End</Label>
                    <Select 
                      value={settings.quiet_hours_end?.toString() || "none"}
                      onValueChange={(v) => updateSetting("quiet_hours_end", v === "none" ? null : parseInt(v))}
                    >
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder="None" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        {Array.from({ length: 24 }, (_, i) => (
                          <SelectItem key={i} value={i.toString()}>
                            {i.toString().padStart(2, '0')}:00
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <p className="text-xs text-slate-500 mt-2">
                  During quiet hours, notifications will be queued and delivered afterward
                </p>
              </CardContent>
            </Card>

            {/* Save Button */}
            <div className="flex justify-end">
              <Button onClick={handleSave} disabled={saveMutation.isPending} className="gap-2">
                {saveMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Save className="h-4 w-4" />
                )}
                Save Preferences
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}